/**
 * The frame around the groups: the status summary on top (with the warnings dialog) and the save bar at the bottom.
 *
 * The Host's `SettingsForm` offers one save button below the controls. This card needs the bar to stay in view while a long
 * page scrolls, to say how many edits are waiting, and to offer "Discard", so the frame is built here; the behaviors a
 * settings form has are kept: it says so when the settings are not served or read-only, and it drops the staged edits when
 * the page is left.
 * @module web-search-pro/client/card-frame
 */
import { type ReactNode } from 'react';
import { type ChainInput } from '../default-chain.ts';
import { type Card } from './field-rows.tsx';
import type { WebSearchCardState } from './form.ts';
/** What the default chain rule reads from the staged settings: the list, the preferences, the ready common sources, the policy. */
export declare function chainInputOf(snapshot: Pick<WebSearchCardState, 'fields' | 'credentials'>): ChainInput;
/** The chain a plain search would try, from the staged settings; undefined when the draft leaves nothing to try. */
export declare function chainOf(snapshot: Pick<WebSearchCardState, 'fields' | 'credentials'>): string[] | undefined;
/**
 * The chain a plain search tries once the agent's changes (engines, priority, disabled of the overlay) are on top of the staged settings,
 * by the same rule; undefined while the agent changed none of the three, an empty list when it would leave nothing to try.
 */
export declare function agentChainOf(snapshot: Pick<WebSearchCardState, 'fields' | 'credentials' | 'server'>): string[] | undefined;
/** Everything the warnings badge counts: what the validation says about a field, and the rubric problems. */
export declare function warningsOf(snapshot: WebSearchCardState, t: Card['t']): string[];
export declare function SummaryBar({ card }: {
    card: Card;
}): import("react").JSX.Element;
export declare function SaveBar({ card }: {
    card: Card;
}): import("react").JSX.Element;
/** The page frame: nothing but a notice while the settings are not served; the staged edits are dropped when the page is left. */
export declare function Frame({ card, children }: {
    card: Card;
    children: ReactNode;
}): import("react").JSX.Element;
