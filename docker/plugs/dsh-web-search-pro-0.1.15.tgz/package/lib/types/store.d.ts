/**
 * SQLite persistence for web-search-pro (node:sqlite, zero dependencies).
 * Stores search queries + results, fetched page snapshots, and user-extended
 * extraction rules (userscript-style). All methods are synchronous; writes are
 * small and batched per call.
 * @module web-search-pro/store
 */
export type QueryKind = 'search' | 'fetch' | 'platform' | 'snapshot';
export interface QueryRecord {
    id: string;
    kind: QueryKind;
    query?: string;
    engine?: string;
    platform?: string;
    url?: string;
    status: string;
    ts: string;
    detail?: string;
    cacheKey?: string;
}
export interface SourceRow {
    id: string;
    queryId: string;
    rank: number;
    url: string;
    title?: string;
    snippet?: string;
    published?: string;
    engine?: string;
    extra?: string;
}
export interface PageRecord {
    id: string;
    queryId?: string;
    url: string;
    title?: string;
    text?: string;
    htmlPath?: string;
    screenshotPath?: string;
    status?: number;
    fetchedAt: string;
    source?: string;
}
export interface RuleRecord {
    hostname: string;
    content: string;
    remove?: string;
    createdAt: string;
    updatedAt: string;
}
export declare class Store {
    readonly dbPath: string;
    private db;
    constructor(dbPath: string, opts?: {
        currentSearchCacheKeyPrefix?: string;
    });
    close(): void;
    /** Record one operation (search / fetch / platform / snapshot). Returns its id. */
    recordQuery(input: Omit<QueryRecord, 'id' | 'ts'> & {
        id?: string;
    }): string;
    /** Look up a fresh cached operation by kind and its complete input fingerprint. */
    getCachedQuery(kind: QueryKind, cacheKey: string, ttlSeconds: number): {
        id: string;
        detail?: string;
    } | undefined;
    recordResults(queryId: string, sources: {
        url: string;
        title?: string;
        snippet?: string;
        publishedAt?: string;
        extra?: string;
    }[], engine: string): void;
    resultsForQuery(queryId: string): SourceRow[];
    queryById(id: string): QueryRecord | undefined;
    /** Fresh page snapshot by URL and, when requested, its exact backend source. */
    getPage(url: string, ttlSeconds: number, source?: string): PageRecord | undefined;
    savePage(input: Omit<PageRecord, 'id' | 'fetchedAt'>): void;
    /** Exact persisted fetch/snapshot for a history query; legacy rows fall back by URL. */
    pageForQuery(queryId: string): PageRecord | undefined;
    listQueries(opts: {
        kind?: QueryKind;
        query?: string;
        engine?: string;
        platform?: string;
        limit?: number;
    }): QueryRecord[];
    clearCache(opts: {
        olderThanDays?: number;
        engine?: string;
    }): {
        queries: number;
        results: number;
        pages: number;
    };
    /**
     * Purge search rows minted with an older cache-key version (e.g. ddg results
     * saved before the snippet-regex fix). Called once at startup so stale
     * titles-only rows are never replayed from the persistent cache.
     */
    cleanupLegacySearchCache(currentPrefix: string): {
        queries: number;
        results: number;
    };
    private removeQuery;
    /** Delete one query and its linked rows; returns exact counts when it existed. */
    deleteQuery(id: string): {
        queries: number;
        results: number;
        pages: number;
    } | undefined;
    /** Most-used engines, desc. */
    topEngines(limit?: number): {
        engine: string;
        count: number;
    }[];
    /** Most-frequent queries, desc. */
    topQueries(limit?: number): {
        query: string;
        count: number;
    }[];
    /** Per-kind record counts. */
    kindCounts(): {
        kind: string;
        count: number;
    }[];
    stats(): {
        dbSizeBytes: number;
        queries: number;
        results: number;
        pages: number;
        rules: number;
    };
    listRules(): RuleRecord[];
    upsertRule(hostname: string, content: string, remove?: string): void;
    removeRule(hostname: string): boolean;
}
