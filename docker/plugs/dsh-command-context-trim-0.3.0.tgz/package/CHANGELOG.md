# Changelog

All notable changes to this project are documented here. This project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.3.0] - 2026-09-26

### Added

- **`/trim preset` — generate a compaction-tuned agent preset from the live routes.** Compaction reads its policy at
  composition time, inside an agent-preset isolate realm that a host-plane plugin cannot reach, so the honest way to move
  the threshold is to contribute a preset row (an ordinary patch row since 0.1.7). The command clones the preset the
  session is using, replaces only `compaction-basic`'s config, and reports what it did:
  - `/trim preset check` prints the generated row and writes nothing;
  - `/trim preset list` shows every routable provider/model with its window, output reserve and the trigger it would get;
  - `/trim preset <provider>:<model>` generates using that route as the summarizer for this run.
  The clone is taken at generation time through `agentPresets.readDocument()`, which is what keeps a generated preset
  current: a hand-copied preset rots the moment dsh changes its own composition (exactly how one production preset died
  on the 0.1.7 upgrade).
- **`compactionTargetRatio` (default 0.8)** — the fraction of each routed model's window at which the generated preset
  makes compaction fire. It writes `thresholdRatio` **and** a per-route `headroomTokens` computed so the ratio actually
  decides: dsh's own default headroom (65536) otherwise caps a 131072-token route at 37.5 %.
- **`compactionRoute` (optional `{provider, model}`)** — the route the generated preset's summarization call runs on;
  validated as an all-or-nothing pair, mirroring dsh's rule for `summarizationProvider`/`summarizationModel`.
- `scripts/verify-preset-artifact.mjs` — proves a generated row against a real installation: it clones the shipped
  `standard` preset's plugin list, generates the row, and parses the result with the harness's own YAML stack.

- **Emergency trim.** When the plugin cannot trim and compaction cannot recover either, the turn used to die with the
  original request error. The plugin now wraps compaction by calling `next()`, inspects whether anything downstream
  acted, and if not takes one last-resort trim (at most one per overflow episode) in which the head-protected nodes —
  the original task statement — may be elided. The newest human instruction is still never crossed. `emergencyTrim`
  (default true) restores the old behaviour when off.

- **Settings card.** The Plugins page gains a **Context trim** card for `compactionTargetRatio` and `compactionRoute`.
  The Host half marks exactly those two fields `.volatile()` (which is what makes the loader entry a settings namespace
  at all) and re-reads its configuration per invocation, because a volatile field arrives as a live handle. The client
  half is a classic-script bundle that registers into `plugins.item` behind `configForms.whileServed([entryId])`,
  renders only the shared `SettingsForm` body, and returns the row's one-line summary. A web host without `configForms`
  gets no registration instead of a broken page.
  **Found by the isolated real-boot check:** a client half must register itself through
  `window.__ModuleLoader__.load({ id, factory })`; a plain ES module is fetched and then rejected with "loaded without
  registering … via __ModuleLoader__.load", which took the whole plugin's entry down with it. The card now follows the
  in-box bundle format, and a test asserts it.

### Notes

- **Auto tune verified end to end.** In a fresh isolated `DSH_HOME` with the plugin installed as a bundle and
  `autoTuneCompaction: true`, a headless session discovered the route through the adapter, computed the per-route
  headroom and wrote the tuned `compaction-basic` row into the profile patch **while the session ran** (observed row:
  `thresholdRatio 0.8`, `headroomTokens 0`, `modelPolicies: [{mock/mock-model, headroomTokens 9012}]` for a backend
  declaring 65536/4096). The session exited 0, and the plugin activates in a headless profile.
- **`/trim tune` retunes a live process.** Compaction is an ordinary plugin row wherever the profile composes
  it on the profile plane (`dsh-base`: headless, tui), and cordis applies a config change by restarting the
  fiber — `Fiber.update()` resolves the new config and calls `restart()`, dispose plus a fresh apply, with no
  "hot-reloadable only" restriction (read from the loader source). The command therefore reads the routes from
  the adapter (`ctx.llm.resolveModelInfo`, the same source compaction uses), computes the tuning, and writes it
  onto the `compaction-basic` row; the write is skipped when nothing changes and refused with an explanation
  where it cannot reach — a web profile keeps compaction inside each session's agent-preset isolate realm, and a
  session's preset is locked once it starts. `autoTuneCompaction` (default `false`) does the same once per
  process, the first time the agent goes idle, so the restart cannot cancel an in-flight compaction.
- **The generator no longer guesses a window.** `scripts/make-preset-patch.mjs` resolves the route capacity
  from, in order: `--routes`, `--dump <file>` (a `dsh … --dump-config` output, parsed for `llm-pi-ai`'s
  provider table and `agent-default-model`; the script never spawns dsh), and the
  `--context-window`/`--max-tokens`/`--model` **override** for the numbers a backend really serves (a card
  that answers with 40k while the profile claims 128k, or a fresh instance that declares no backend yet):
  the named route — else the active one — takes exactly those numbers, a route the base does not declare is
  added, and only the numbers passed are replaced. With none of them it **errors** instead of emitting a threshold that silently depends on an assumed
  window; `--window-agnostic` is the explicit ratio-only overlay. `--summarizer-max-tokens` is now the
  compaction call's own cap, kept distinct from a route's output reserve. `lib/dump-routes.js` holds the
  parser and the resolution order, both covered by tests over a realistic dump fixture.
- **`docs/headless-compaction-tuning.md`** is the hand-off document for a fresh environment: prerequisites, the
  one-line overlay generation, the boot command, the assertions a test script can make, the optional per-route
  policy form, why a preset does not apply to a headless run, the four failure signatures hit while building it,
  and what remains unverified. The drill needs Node only (no python3, no iproute2).
- **Headless automation takes the profile plane, not a preset.** `scripts/make-preset-patch.mjs` turns a
  route inventory into either a preset row plus `agent-preset-registry` default (the web/session-API route) or,
  with `--mode host`, a row override for the profile's own `compaction-basic` — because a headless profile
  composes compaction itself and never resolves a session preset. Verified in a clean `DSH_HOME`: three
  headless runs (no overlay / generated preset / that preset with a tool row deleted) produced an identical
  24-tool request surface, while the host-plane overlay lands the tuned config on the composed
  `compaction-basic` row and a session under it exits 0.
  `fixtures/headless-tuned-preset/` carries the route inventory, a mock provider patch, the drill script and
  the notes on what cannot be asserted (the picker label is draft state; `agent-preset/selected` is absent
  when a session is created with the default).
- **The preset choice is per session, and locked once a session starts.** `agentPresets.select()` refuses with
  `agent-preset/locked` ("This session has already started") as soon as a turn is open or one has completed, because a
  switch recomposes the preset's isolate realm. The command's completion message now says so instead of pointing at the
  preset menu as if a running session could switch, and `/trim preset default` was added for the case it describes:
  it writes `agent-preset-registry.selectedDefault` through the same settings path the official picker uses — but only
  after the generated preset shows up as a healthy registration, since the new-session path resolves the default and an
  unknown id would break it (`agent-preset/not-found`).
- Store-facing metadata, added without changing the version: an explicit **Permissions and failure bounds** section in
  the README (the runtime's only file-system touch is the `/trim preset` patch write; no network, no command execution,
  no credential access), a `dsh.compatibility.dshReleases` map declaring exactly the harness lines this repository has
  evidence for, and the overflow-check server moved from `scripts/` to `fixtures/` so a scan of *runtime* source sees
  `lib/` only. That files capability is deliberate and cannot be removed: it *is* the preset generation. Under the
  catalog's own model a legitimate plugin with file capability belongs in `user-reviewed`, not `source-verified`.
- The generated row lands in the profile patch inside marker comments
  (`# >>> dsh-command-context-trim: preset-<id> … >>>`), so it is idempotent, reviewable and removable by deleting the
  block. One rolling backup (`cordis.patch.yml.bak-trim-preset`) is kept.
- Nothing here changes trimming: the trigger ratio only shapes the preset.
- Verified on 0.1.7-rc.2, in an isolated instance and never in production:
  - the artifact parses with the harness's YAML stack, and a profile that carries the generated row composes cleanly
    (1,447-line dump, `compaction` group with its isolate realm intact, threshold and policies present);
  - a generated row appended to a live profile patch appears in the preset menu as "Standard (tuned 75%)" after a client
    reload — no runtime registration and no dsh restart — and selecting it works;
  - the settings card renders in the Plugins page (summary line under Official, both fields, staged edit, Save), and the
    save lands as a `context-trim` row in the profile patch with the value typed in the GUI.
- Compatibility, caught by the matrix: `.volatile()` needs schemastery 3.18.4, and a harness that predates it (0.1.5 and
  earlier) failed to import the plugin at all until the field marking became a capability probe. On such a host the two
  fields stay plain — the plugin loads and works, it just shows no card, which is right because its web UI has no
  `configForms`. The client manifest likewise declares only `platform: web`: naming 0.1.7-only client packages in
  `dsh.client.inject` would have asked a 0.1.5 host for packages it does not have, and the real requirement (slots,
  locale, configForms) is gated by cordis in the browser plugin's own `inject` list.
- Not done, because the framework does not support it: a provider/model **dropdown**. dsh 0.1.7's shared settings form
  exports only `settingsNumberField` and `settingsTextField`, and a hand-drawn control would break the staged-form
  contract. `/trim preset list` covers the need by printing the live route inventory.


## [0.2.3] - 2026-09-22

### Fixed

- **Harness 0.1.7 compatibility.** 0.1.7 flattens tool-result messages: up to 0.1.5 the content was a single
  `tool-result` wrapper block, from 0.1.7 the blocks sit directly on the message (`{role:'tool', toolCallId,
  content:[…]}`), and sessions gained a `deriveEventMessage()` method that the official pruner now uses instead of
  reading `event.data.message`. The in-place slim read the wrapper unconditionally, so on 0.1.7 it threw
  `blocks is not iterable` inside the overflow handler — the automatic path then declined and handed every wall hit to
  compaction without trimming anything. It now reads and rebuilds both shapes and takes the message from
  `session.deriveEventMessage()` when the session offers it. An unrecognised shape is skipped rather than thrown: this
  path must never be the reason an overflow recovery is abandoned.
- Suite is green on the pinned floor (0.1.2-rc.1), 0.1.5-rc.3 and 0.1.7-rc.2 — 72 tests on each. CI gained a fixed
  0.1.5 leg so the middle line stays covered while `next` moves forward.


## [0.2.2] - 2026-09-22

### Added

- **Cheap reduction first: oversized tool results are slimmed in place before any span is elided.** On the wall the
  plugin now performs the same head/marker/tail transform DSH's own pruner performs — keeping the node, its tool call and
  the prefix up to it — and only elides a whole span when that is not enough. It delegates to the official
  `toolResultPruner` service when that service is reachable from the plugin's context (0.1.2; a 0.1.5 headless profile
  where compaction stays on the host plane) and performs the identical transform itself when it is not (a 0.1.5 web
  profile hides the pruner inside an agent-preset isolate realm). New configuration: `preferInPlacePrune` (default true)
  and `pruneThresholdChars` / `pruneHeadChars` / `pruneTailChars` (8192 / 4096 / 1024, mirroring DSH's defaults).
- The in-place marker is `[... tool result middle trimmed to fit the context window ...]`, deliberately distinct from
  DSH's `[... tool result middle pruned ...]`, so a session log shows which producer slimmed a node.

### Notes

- Verified end to end in the real `dsh-container` image (0.1.5-rc.2, isolated home, mock backend): a request of 23,429
  tokens was refused, the plugin delegated to the official pruner, the retry came back at 19,995 tokens, the turn
  completed, and the session log shows **no `compaction/start`** and **no span elided** — the pruner's `tool/result`
  replacement kept `callId` and the step. The earlier span path was verified the same way (33,373 → 18,431 tokens).
  The inline fallback (used only where the service is unreachable, i.e. a 0.1.5 web profile) is unit-tested against the
  same semantics but not yet exercised end to end.
- `scripts/mock-overflow-server.mjs` gained `TOOL_COMMAND` / `TOOL_DESCRIPTION`: a bash tool call without a `description`
  fails argument validation, which silently produced tiny error results instead of real tool output during testing.


## [0.2.1] - 2026-09-22

### Fixed

- **A wall hit is no longer a one-shot.** Reported from a 32k backend while `settings.yaml` declared `contextWindow:
  90000`: the first automatic trim targeted `(90000 - 8192) * 0.9 ~= 73.6k`, the retry was rejected again, and with
  `maxAutoTrimRetries: 1` spent the recovery fell through to compaction — whose summarisation request is itself over the
  real limit, so the turn died. The plugin now adapts instead of trusting a declaration it has just seen contradicted:
  - the **first** attempt still trusts the declared window (cheap, and correct when the window is honest);
  - every **later** attempt inside the same episode retargets to `failingRequestTokens * (1 - autoTrimShrink)`, i.e. it
    halves the request that was just rejected — a geometric descent that converges however wrong the declared window is;
  - a repeat attempt also logs an actionable warning: the routed model's `contextWindow` is larger than the backend
    actually serves, fix it in `settings.yaml` (and the server's own context flag).
- Defaults changed accordingly: `maxAutoTrimRetries` **1 → 3**, and a new `autoTrimShrink` (**0.5**).

- **Automatic-trim decisions now log at `warn`.** An unattended rewrite of the user's context has to be visible in the
  host log: a test run recorded the trim in the session log while the app log showed nothing, because `info` is filtered
  at the default level.
- The README now explains how to tell this plugin's `compaction/prune` from DSH's tool-result pruner in a session log
  (producer of the following event, and pre-step vs in-step position) and the two `usage` accounting traps.

### Notes

- The honest fix for a mismatched backend is still the setting itself: with `contextWindow: 32768` the very first trim
  targets ~22k and succeeds without the adaptive path. The adaptive path exists so a wrong declaration degrades into
  "more trimming than necessary" rather than a dead turn.
- Nothing else changed: the event, its gating (`CONTEXT_WINDOW_EXCEEDED` only), the elision preference tiers and the
  newest-user-message barrier are untouched.


## [0.2.0] - 2026-09-16

### Added

- **Automatic trimming on the context wall.** A `prepend`ed `agent/request-error` listener reacts to
  `CONTEXT_WINDOW_EXCEEDED`, frees space with no model call, and asks the loop to retry. Only when it cannot free
  anything does the waterfall continue into DSH's own recovery (prune + summarize) — so a session that hits the wall
  is repaired by *dropping* the oldest span first and only pays for summarization when dropping cannot help.
  This is the unattended form of `/trim`; it is the same execution, invoked by the harness instead of a human.
- Configuration `autoTrim` (default `true`) and `maxAutoTrimRetries` (default `1`, per overflow episode).
- **The elided span is chosen by explicit preference tiers.** Elision always starts at the oldest balanced cut, and the
  search is graded: (1) stay outside the retained tail and keep the final message, with the configured retention relaxed
  step by step only if the fit otherwise fails; (2) reach into the retained tail, still keeping the final message;
  (3) last resort — include the final message, typically the current step's assistant tool-call plus its tool result,
  which can only be removed as a pair. `allowTailTrim: false` ends the list after tier 1. The plan and every rendered
  result state when the last-resort tier was used.
- **Planner anchor changed: the newest `user/message` is protected, the final node is not.** The previous rule
  ("never elide the final surface node") deadlocked the most common overflow shape — one large assistant tool-call whose
  tool result is the last node could not be removed as a pair, so only a handful of tokens were freeable while the
  request stayed over the wall (observed live: "largest balanced span frees ~4 of the ~4631 tokens needed"). The newest
  human instruction is now a **barrier** (never elided, never crossed) and everything after it stays eligible, tool
  pairing still enforced on both cut edges.

### Notes

- **Scope: the context wall only.** The listener fires exclusively for `CONTEXT_WINDOW_EXCEEDED`. Ordinary
  threshold compaction (`agent/pre-step` pressure), `/compact`, and the tool-result pruner are untouched — this is
  asserted by a test that pins the registered listener set.
- Why `prepend` is required: `agent/request-error` is a Cordis waterfall and compaction registers its summarization
  recovery on the same event. Cordis stores listeners in registration order and `{ prepend: true }` unshifts, so this
  listener runs first even when compaction is mounted later inside an agent-preset isolate realm (as it is in a web
  profile). Returning `{ kind: 'retry' }` without calling `next()` vetoes summarization for that attempt.
- The per-episode budget resets when a completed assistant message lands or the agent goes idle, mirroring
  compaction's own overflow accounting.
- Trade-off, stated plainly: an automatic trim **drops** the oldest span rather than summarizing it. That is the
  point on a small local window — the summarizer must fit the region it is condensing and frequently cannot — but it
  does mean the dropped text is replaced by a marker instead of a summary. `/compact` remains available, and the full
  text stays in the durable session log.


## [0.1.1] - 2026-09-15

### Fixed

- **DeepSeek Harness 0.1.5 compatibility.** 0.1.5 renamed the positional replacement marker
  (`{op: 'replace', start, end}` → `{op: 'replace', startSeq, endSeq}`), so every trim failed with
  `session event "user/message" carries an invalid replace surfaceOp`. The plugin now probes the accepted shape
  once against the harness actually installed and writes that one, so the same build works on the 0.1.2 and
  0.1.5 lines without a version check.
- **The system prompt is never trimmed — and no longer eats head protection.** 0.1.5 moved the system prompt
  from the request header onto the surface as node 0 (`system/message`). A position-only "protect the first
  node" rule would have protected the *system prompt* and exposed the **user's original request** as the first
  elidable message. System nodes are now barriers: never elided and never crossed, and `protectHeadNodes` counts
  only non-barrier nodes, so it keeps protecting the task statement.

### Notes

- No configuration changes. The only user-visible difference is the "fixed request overhead" refusal, which now
  says "tool schemas and other non-surface request data": on 0.1.5 the system prompt is surface content rather
  than header content.
- Verified on harness 0.1.2-rc.1 and 0.1.5-rc.2 (40 tests each, same build).


### Added

- Integration tests against the **real** `ctx.tokenMeter` (bare cordis context + stub projection registry): a trim's
  measured saving equals the `compaction/prune` shadow price it claims minus the replacement marker, and a *fresh* meter
  folding the replayed log reaches the identical total — the replay property the claim exists for.

## [0.1.0] - 2026-09-15

### Added

- **`/trim` — model-free context trimming.** Drops the oldest tool-pairing-balanced span of the model-visible surface so a
  session built against a large-window cloud model can keep running on a smaller local model. It makes no model call at
  all, which is the case `/compact` cannot rescue: compaction summarizes, so its summarizer must fit the very region it is
  condensing in the now-smaller window.
- Forms: `/trim` (fit the active or pending model window), `/trim check` (plan only, change nothing),
  `/trim 32k` (explicit budget), `/trim provider:model` (fit another route's declared window).
- Protected context: the leading task statement (`protectHeadNodes`), the most recent messages (`retainRatio` /
  `minTailTokens`), and the final surface node. Within those bounds the policy is oldest-first and frees only what the
  budget requires; retention is relaxed only when the fit is otherwise impossible, and the result says so.
- Configuration: `targetRatio`, `reserveOutputTokens`, `retainRatio` / `retainTokens`, `minTailTokens`,
  `protectHeadNodes`, `allowTailTrim`, `markerSlackTokens`.
- Every refusal (fixed request overhead already over budget, no balanced cut point, not enough freeable) explains itself
  and writes nothing to the session.

### Notes

- One trim appends exactly two events: a `compaction/prune` shadow-price claim for the meter's O(1) projections, then a
  `user/message` positional replacement citing every shadowed node. `user/message` is the only surface-eligible event an
  idle command may append — `assistant/message` needs an open step and a `tool/result` replacement needs an open turn.
- Nothing is lost: replacements are model-only (the human transcript reads append-origin events) and the full original
  content stays in the durable session log. v1 has no `/untrim`.
- Requires a harness that exposes `ctx.commands`, `ctx.tokenMeter`, and `ctx.llm` (DeepSeek Harness 0.1.2-rc.1 or later).

[Unreleased]: https://github.com/snailium/dsh-command-context-trim/compare/v0.3.0...HEAD
[0.3.0]: https://github.com/snailium/dsh-command-context-trim/compare/v0.2.3...v0.3.0
[0.2.3]: https://github.com/snailium/dsh-command-context-trim/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/snailium/dsh-command-context-trim/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/snailium/dsh-command-context-trim/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/snailium/dsh-command-context-trim/compare/v0.1.1...v0.2.0
[0.1.1]: https://github.com/snailium/dsh-command-context-trim/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/snailium/dsh-command-context-trim/releases/tag/v0.1.0
