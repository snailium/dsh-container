/**
 * dsh-repeat-tool-breaker — repeat detection with escalation, not just a wall.
 *
 * A local, dependency-free DSH plugin (pure ESM, no schemastery/cordis imports).
 * It registers ONE synchronous monotonic gate through the public
 * `ctx.tools.guard` API, which runs after every `tools/pre-execute` listener and
 * before the tool body:
 *
 *   ToolGuard = (execution) => string | undefined
 *   - a string => FINAL denial; the body never runs and the model receives an
 *     `isError` result whose text is that string.
 *   - undefined => leave the call allowed (a guard can never flip a denial back
 *     to allowed by ordering).
 *
 * ## Two escalating tracks, one gate
 *
 * Repeating a MEASURE (a fingerprint identity — `exact:`, `cmd:`, `net:`,
 * `host:`, `sink:`, …) inside the same human turn escalates:
 *
 *   1. `warnAt` (7)      — a light advisory: you are repeating; consider another route
 *   2. `summarizeAt` (11)— a demand: summarise progress; list untried alternatives
 *   3. `limits` (12)     — the gate: ask the operator (`onLimit: ask`) or deny
 *                          (`host` is 16: the coarser measure needs more evidence)
 *
 * Failing the same measure repeatedly escalates on a SECOND, much tighter scale,
 * because failure carries information that repetition does not:
 *
 *   1. `failWarnAt` (3)  — the target keeps failing; read the error, stop guessing
 *   2. `failLimit` (5)   — the gate, subject to the same `onLimit` policy
 *
 * The failure track blocks only the fingerprints that hit: a call that does not carry
 * them (reading the error log, grepping the code, another endpoint) is allowed, since
 * blocking the recovery action wedges the model. Both tracks share the measure set, the
 * exemptions and the refusal set — see `lib/failure.js` and `lib/window.js`.
 *
 * The three move together. `lib/defaults.js` is the ground truth for the numbers and
 * `docs/issue-b-thresholds.md` for the measurement behind them; the short version is
 * that the gate fires before the advisory, so a stage at or above every cap can never
 * be delivered.
 *
 * Stages 1 and 2 are ADVISORY and cannot be delivered from the guard, which
 * returns `string | undefined` and nothing else. They ride `tools/post-execute`
 * as `additionalContexts`, the same channel `@deepseek-ai/dsh-repeat-tool-reminder`
 * uses, stamped `source.kind: 'plugin'` (an unlabeled context renders as a user
 * prompt in derived history).
 *
 * ## Why the ask lives in two hooks
 *
 * `tools/pre-execute` can ask but cannot deny; `ctx.tools.guard` can deny but
 * cannot ask. The pipeline makes the two halves distinguishable (dsh-tools
 * `prepareExecution`): a REJECTED ask never reaches the guard, while an APPROVED
 * ask does. So `pendingAsk` carries the conversation — an entry consumed by the
 * guard means "approved", an entry still present in `post-execute` means
 * "declined".
 *
 * ## Counting lives in the guard and nowhere else
 *
 * The guard commits a call on BOTH outcomes — every fingerprint when the call
 * ran, only the fingerprints that hit when it did not — which keeps a model
 * hammering a denied call from resetting its own budget, stops two calls racing
 * in one step from both seeing an empty window, and stops a denied call from
 * spending budget on a resource it never touched. `tools/post-execute` only
 * records the settled result text and settles the fate of a declined ask.
 *
 * Configuration is merged from the patch's `config:` and validated fail-loud in
 * `apply`; there is no schemastery schema export, which `cordis.resolveConfig`
 * tolerates.
 */

import {
  blockingHits,
  compileTracked,
  isShell,
  isTracked,
  fingerprints,
  limitFor,
} from './lib/fingerprints.js'
import {
  askMessage,
  denyMessage,
  failWarnMessage,
  renderResult,
  shellHttpBlockedMessage,
  summarizeMessage,
  warnMessage,
} from './lib/message.js'
import { classifyFailure } from './lib/failure.js'
import { FETCH_FILE_DEFAULTS, createFetchFileState, fetchFileToolState, registerFetchFileTool } from './lib/fetch-file.js'
import { createTracker, hasUserMessage } from './lib/window.js'
import { DEFAULTS, mergeDefaults, validateCfg } from './lib/defaults.js'
import { blockShellHttp } from './lib/block-policy.js'

import z from '@deepseek-ai/schemastery'

/**
 * Fields `Config` declares as `union([number, const(null)])`, so an unset one means the
 * documented off-switch rather than a missing value.
 *
 * Spelled out because the resolved handle does not carry its own nullability, and the
 * alternative — inferring it — is what produced the mismatch this list fixes. A unit test
 * asserts that every name here is declared nullable in `Config`, so the two cannot drift.
 */
const NULLABLE_SETTINGS = ['summarizeAt', 'failLimit', 'convergeAfter']

/**
 * Resolve a config field to its plain value.
 *
 * A `volatile()` field (see `Config`) is delivered as a live handle with `.get()`; every
 * other field is already plain. One wrinkle is worth spelling out: a union field whose
 * `.default(null)` is inherited resolves to `undefined` rather than `null`, so an unset
 * off-switch would arrive as `undefined` — and `undefined` does NOT disable a stage the way
 * the documented `null` does. {@link plainConfig} normalises exactly the fields listed in
 * {@link NULLABLE_SETTINGS}, which keeps the documented contract.
 *
 * @param value - a resolved config field.
 * @returns the plain value.
 */
function plainField(value) {
  return value !== null && typeof value === 'object' && typeof value.get === 'function'
    ? value.get()
    : value
}

/** Every field of a resolved config, with volatile handles resolved. */
function plainConfig(config) {
  if (config === null || typeof config !== 'object') return {}
  return Object.fromEntries(
    Object.entries(config).map(([key, value]) => {
      const plain = plainField(value)
      return [key, NULLABLE_SETTINGS.includes(key) && plain === undefined ? null : plain]
    }),
  )
}

/**
 * The producer-owned message source kind for session format 4 (dsh 0.1.7), which replaced
 * the retired `kind: 'plugin'` wrapper. Exported so the test suite asserts against it
 * rather than a copied literal.
 */
export const SOURCE_KIND = 'plugin:dsh-repeat-tool-breaker'

/** Stable plugin identifier. */
export const name = 'repeat-tool-breaker'

/**
 * The plugin's configuration schema — and, since dsh 0.1.7, the SETTINGS FORM.
 *
 * In 0.1.5 a plugin registered a settings namespace imperatively
 * (`ctx.settings.register(name, schema, { base })`) and this exported schema was only the
 * deployment surface for the patch layer. 0.1.7 removed that call: `SettingsForms.schema()`
 * reads `entry.fiber.runtime.Config`, so the schema below is what the Plugins page renders.
 * One declaration now serves both layers, and the imperative registration is gone.
 *
 * `volatile()` is what makes a field appear at all. `volatileForm()` keeps only fields whose
 * nearest volatile ancestor is marked, and an entry with no such field is SKIPPED — so a
 * schema without `volatile()` is a schema with no form. Volatile also means "editable
 * without remounting", which is why the resolved value arrives as a live handle and is read
 * with `.get()` rather than snapshotted (see `readCfg`).
 *
 * `cordis.resolveConfig` still fills the defaults and keeps every key this schema does not
 * mention, so a PARTIAL schema is safe: the `limits` table, `ignoreArgs`, `hostAliases`,
 * `window` and the rest keep reaching `apply` from the patch layer.
 *
 * The four stage thresholds accept `null` as their documented off-switch, so they are
 * declared as a union rather than a bare number — a plain `z.number()` would reject the
 * null and turn a supported setting into a boot failure.
 */
export const Config = z.object({
  blockShellHttp: z
    .boolean()
    .default(DEFAULTS.blockShellHttp)
    .description('Refuse HTTP fetches made from the shell and send the model to web_fetch_file.')
    .volatile(),
  blockLocalHttp: z
    .boolean()
    .default(DEFAULTS.blockLocalHttp)
    .description(
      'Also refuse local (loopback/RFC1918) fetches. Off by default: a local fetch is ordinary ' +
        'work, and with the default curl backend `web_fetch_file` reaches local addresses too, so ' +
        'the block would only remove the shell route to something the tool already allows.',
    )
    .volatile(),
  shellHttpBlock: z
    .array(z.string())
    .default([...DEFAULTS.shellHttpBlock])
    .description(
      'Commands the block REFUSES. The block is a blacklist: a command is refused when its verb is on this list, or when an interpreter program names a request API. Defaults are the raw HTTP clients plus the file/streaming downloaders, which all have web_fetch_file as a replacement.',
    )
    .volatile(),
  warnAt: z
    .number()
    .default(DEFAULTS.warnAt)
    .description('Occurrence stage 1: repeats of one call before the light advisory. 0, negative or null disables it.')
    .volatile(),
  summarizeAt: z
    .union([z.number(), z.const(null)])
    .default(DEFAULTS.summarizeAt)
    .description('Occurrence stage 2: repeats before the call must summarize its progress. null disables it.')
    .volatile(),
  failWarnAt: z
    .number()
    .default(DEFAULTS.failWarnAt)
    .description('Failure stage 1: consecutive failures before the advisory. 0, negative or null disables it.')
    .volatile(),
  failLimit: z
    .union([z.number(), z.const(null)])
    .default(DEFAULTS.failLimit)
    .description('Failure gate: consecutive failures before the call is refused. null keeps the advisory and drops the gate.')
    .volatile(),
  convergeAfter: z
    .union([z.number(), z.const(null)])
    .default(DEFAULTS.convergeAfter)
    .description('Convergence: ACCUMULATED refusals of one target before the span that keeps retrying it is compacted away. A released call does not reset the count — coming back after being let through is the signal. null disables.')
    .volatile(),
  convergeRelief: z
    .number()
    .default(DEFAULTS.convergeRelief)
    .description('How much the convergence window shrinks after each round, as a ratio in (0, 1]. 0.5 turns 10 into 10, 5, 3, 2, 2…')
    .volatile(),
  convergeFloor: z
    .number()
    .default(DEFAULTS.convergeFloor)
    .description('The floor the convergence window never shrinks below, so the escalation stays predictable.')
    .volatile(),
})

/** Injected cordis services required before `apply` runs. */
export const inject = ['tools']

/**
 * Pull the call's identity out of a pipeline execution, tolerating the shapes
 * seen across `tools/*` hooks.
 * @param exec - a tool execution.
 * @returns `{ name, args, agent }`.
 */
function parts(exec) {
  return {
    name: exec?.name ?? exec?.toolName ?? exec?.tool?.name ?? '',
    args: exec?.arguments ?? exec?.args ?? {},
    agent: exec?.agent ?? exec?.exec?.agent ?? null,
  }
}

/** A fresh message identity, without pulling in a uuid dependency. */
function messageId() {
  const uuid = globalThis.crypto?.randomUUID?.()
  if (typeof uuid === 'string') return `${name}-${uuid}`
  return `${name}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`
}

/**
 * Which measure to NAME when several cross the same stage at the same count.
 *
 * Lower is preferred. A target-scoped measure is the actionable one — "you have
 * called `api.example.com` six times" tells the model something it can act on,
 * whereas `exact:` quotes a truncated command line, and `site:` lumps unrelated
 * services together. Nothing about the escalation changes; only which identity the
 * message names.
 */
const MEASURE_PREFERENCE = ['host', 'net', 'site', 'sink', 'cmd', 'exact']

/**
 * Rank one fingerprint for the tie-break above.
 * @param fp - the fingerprint.
 * @returns its preference index; unknown kinds sort last.
 */
function measureRank(fp) {
  const index = MEASURE_PREFERENCE.indexOf(fp.split(':')[0])
  return index === -1 ? MEASURE_PREFERENCE.length : index
}

/**
 * Build the message object an `additionalContexts` entry must be. Mirrors
 * `createUserMessage` from the sibling reminder plugin: user-role content plus a
 * `source` the harness can label with, frozen before publication.
 * @param text - the advisory text.
 * @param summary - a one-line summary for derived history.
 * @returns a frozen message.
 */
function noticeMessage(text, summary) {
  return Object.freeze({
    id: messageId(),
    role: 'user',
    content: Object.freeze([Object.freeze({ type: 'text', text })]),
    // SESSION FORMAT 4 (dsh 0.1.7) producer-owned source. Format 3 wanted
    // `{ kind: 'plugin', plugin: <package> }` and format 4 REJECTS that shape, so the two
    // are mutually exclusive and this release targets one generation rather than probing:
    // 0.8.x is the dsh 0.1.7 line, 0.7.x remains the 0.1.5 line.
    source: Object.freeze({ kind: SOURCE_KIND, form: 'notice', summary }),
  })
}

/**
 * Install the breaker.
 * @param ctx - plugin context (must expose `tools`).
 * @param config - raw configuration from the patch.
 * @returns a teardown function.
 */
export function apply(ctx, config = {}) {
  // The config is a SNAPSHOT of values but must not be a snapshot of the SETTINGS: a
  // volatile field resolves to a live handle, and the operator can change it while this
  // instance is running. So the same object is refreshed in place from `config` before
  // every hook reads it — mutating rather than replacing keeps the identity the tracker
  // and the compiled matchers closed over.
  const cfg = validateCfg(mergeDefaults(plainConfig(config)))
  function refresh() {
    const next = validateCfg(mergeDefaults(plainConfig(config)))
    for (const key of Object.keys(next)) cfg[key] = next[key]
  }

  const tracker = createTracker(cfg)
  const tracked = compileTracked(cfg)
  /**
   * Executions this plugin has asked about, mapped to what it would have denied.
   * See the module docstring: the guard consuming an entry means the operator
   * approved; the entry surviving into `post-execute` means they declined.
   */
  /** This context's fetch-file registration. Per-apply, so contexts cannot contaminate. */
  const fetchFile = createFetchFileState()
  const pendingAsk = new WeakMap()
  /**
   * The advisory text owed to one execution, computed in the guard (the only
   * place that sees the counts) and attached in `post-execute` (the only place
   * that can add context).
   */
  const advisoryFor = new WeakMap()
  /**
   * Executions THIS plugin stopped. A denial is not the model's failure, and
   * counting it as one would make the guard feed itself: deny a call, the streak
   * grows, the next call is denied one step earlier. Rejected asks land here too
   * (the call never ran), and they are recorded where the ask is settled.
   */
  const deniedByUs = new WeakSet()
  /**
   * Targets that have just crossed `convergeAfter` refusals, waiting for a hook that can await.
   *
   * The guard is synchronous by contract — it must never await, resolve DNS or touch the disk —
   * and compaction is a network round trip. So the guard only RECORDS the crossing here, and the
   * pre-step hook performs it, one step later, where an await is allowed.
   */
  const convergenceQueue = []
  /** Disposers of everything this plugin registered, run by the returned teardown. */
  const teardown = []

  /**
   * Decide the fate of one call: its fingerprints, the hits, and what still
   * blocks once this turn's exemptions are taken into account.
   * @param exec - the pending tool execution.
   * @param agent - the calling agent.
   */
  const evaluate = (exec, agent) => {
    const { fps, local } = fingerprints(exec, cfg)
    // Two tracks, one gate. The failure hits come first because they are the more
    // actionable of the two, and both go through the same exemption/refusal path
    // below -- a second gate would need a second ask, a second refusal set and a
    // second way to get stuck.
    const hits = [
      ...tracker.failureHits(agent, fps),
      ...tracker.wouldExceed(agent, fps).map((hit) => ({ ...hit, kind: 'repeat' })),
    ]
    return { fps, local, hits, blocking: blockingHits(hits, tracker.exemptSet(agent)) }
  }

  /**
   * Whether this shell call is an HTTP fetch that the block covers.
   *
   * The test is SEMANTIC and destination-based, so it does not care how the request
   * is made: `curl`, `wget`, a `python3 -c` one-liner, a `node -e`, an absolute
   * `/usr/bin/curl`, or a script run by name all carry the destination in the
   * command text. Enumerating downloader names would have missed the interpreters
   * and been defeated by an absolute path.
   *
   * `host:` is the non-local-target marker: with the shipped `includeLocal: false`
   * it is emitted ONLY for a non-local host, so a call carrying one is fetching
   * something remote. `family:http-fetch` covers an HTTP verb with no URL in the
   * text (`curl --config …`). A purely local call carries neither, which is what
   * keeps localhost usable -- see `blockLocalHttp` for why that matters.
   *
   * @param fps - the call's fingerprints.
   * @param local - whether every URL in the call was local.
   * @returns whether the call is a covered HTTP fetch.
   */
  const isBlockedShellHttp = (fps, local, command) => {
    if (cfg.blockShellHttp !== true) return false
    // FAIL-SAFE: never refuse a fetch when the replacement tool is not registered.
    // Checked across both local context state and shared component state.
    if (fetchFile.registered !== true && fetchFileToolState.registered !== true) return false
    return blockShellHttp(command, cfg)
  }

  /**
   * Which advisory stage, if any, this call reaches — read BEFORE the call is
   * committed, so `count` includes it.
   *
   * A stage fires on exact equality, so each crossing produces one message: the
   * window slides, an exempted measure stops moving entirely, and a measure that
   * sits above the gate does not keep re-announcing itself. When several
   * measures cross at once, the strongest stage wins and ties go to the highest
   * count.
   * @param agent - the calling agent.
   * @param fps - the call's fingerprints.
   * @returns the advisory message, or `null`.
   */
  const stageAdvisory = (agent, fps) => {
    const counts = tracker.tallyOf(agent)
    let chosen = null
    for (const fp of fps) {
      // A measure with NO CAP has no gate, so it must have no escalation either: the
      // stages live BELOW the cap, not beside it. Without this guard the disabled
      // volume budgets (`site:`, `family:*`, `verb:*` are all `null` by default) still
      // fire advisories — reintroducing, through the advisory channel, exactly the
      // signal 0.3.2 and 0.3.3 deliberately turned off. One `curl` emits several of
      // those measures at once, so the omission produced up to four near-identical
      // messages about a single action.
      if (!Number.isFinite(limitFor(fp, cfg.limits))) continue
      const next = (counts.get(fp) ?? 0) + 1
      let stage = 0
      if (cfg.summarizeAt !== null && next === cfg.summarizeAt) stage = 2
      else if (cfg.warnAt !== null && next === cfg.warnAt) stage = 1
      if (stage === 0) continue
      const rank = measureRank(fp)
      const better =
        chosen === null ||
        stage > chosen.stage ||
        (stage === chosen.stage && (next > chosen.next || (next === chosen.next && rank < chosen.rank)))
      if (better) chosen = { stage, fp, next, rank }
    }
    if (chosen === null) return null
    const message =
      chosen.stage === 2
        ? summarizeMessage(chosen.fp, chosen.next, cfg)
        : warnMessage(chosen.fp, chosen.next, cfg)
    return noticeMessage(message, `${chosen.fp} × ${chosen.next}`)
  }

  /**
   * Offer the operator the choice when a call is about to be gated, once per
   * measure per turn. Runs before the guard, because a guard can only deny — it
   * has no way to ask.
   */
  const onPre = ctx.on('tools/pre-execute', async (exec, next) => {
    refresh()
    if (cfg.onLimit !== 'ask') return next()
    const { name, agent } = parts(exec)
    if (agent === null || !tracked(name)) return next()
    const { fps, hits, blocking } = evaluate(exec, agent)
    if (blocking.length === 0) return next()
    // If ANY blocking measure was already declined this turn, an approval could
    // not unblock this call anyway — so do not ask, just deny.
    if (blocking.some((hit) => tracker.isRefused(agent, hit.fp))) return next()
    pendingAsk.set(exec, { fps, hits: blocking })
    return { kind: 'ask', reason: askMessage(blocking, cfg) }
  })
  teardown.push(onPre)

  /**
   * The synchronous monotonic guard — the one and only counter. It must never
   * await, resolve DNS, or touch the disk.
   */
  const guard = (exec) => {
    refresh()
    const { name, agent } = parts(exec)
    if (agent === null || !tracked(name)) return undefined

    // The HTTP block is a flat refusal, not an escalation: it fires on the FIRST
    // fetch, it never asks, and it does not depend on a count. Asking would defeat
    // the purpose -- the point is that this class of call cannot happen, so that
    // every fetch goes through a tool whose status is a fact.
    if (isShell(name)) {
      const { fps: blockFps, local } = fingerprints(exec, cfg)
      const { args } = parts(exec)
      if (isBlockedShellHttp(blockFps, local, typeof args?.command === 'string' ? args.command : '')) {
        deniedByUs.add(exec)
        return shellHttpBlockedMessage({ name, localAllowed: cfg.blockLocalHttp !== true })
      }
    }

    // Reaching the guard with a pending ask means the operator approved it.
    const approved = pendingAsk.get(exec)
    if (approved !== undefined) {
      pendingAsk.delete(exec)
      tracker.exemptFingerprints(
        agent,
        approved.hits.map((hit) => hit.fp),
      )
    }

    const { fps, blocking } = evaluate(exec, agent)

    if (blocking.length > 0) {
      deniedByUs.add(exec)
      tracker.commit(agent, fps, blocking)
      // A denial that is simply repeated is the one failure mode every other measure is blind
      // to: the call produces no result (so the failure track sees nothing) and the denial
      // resets the occurrence window (so the cap never accumulates). Counting the refusals is
      // what makes the loop visible, and the count is carried on the tracker so the pre-step
      // hook can act on it.
      const blockedFps = blocking.map((hit) => hit.fp)
      const reached = tracker.refuseFingerprints(agent, blockedFps)
      if (reached.length > 0) {
        // Queue the WHOLE group, not just the fingerprint that tripped. One refused call carries
        // several views of the same action (`exact:` and `cmd:` here), and every one of them is
        // counted by the loop above. Closing only the first left the others accumulating toward
        // their own thresholds, so they fired in alternation and the window never tightened —
        // measured as refusals-between-compactions of 1, 4, 1, 4 instead of 10, 5, 3, 2.
        convergenceQueue.push({
          agent,
          fps: blockedFps,
          fp: reached[0].fp,
          streak: reached[0].streak,
        })
      }
      return denyMessage({
        name,
        hits: blocking,
        lastResult: tracker.slot(agent).lastResult,
        cfg,
        refused: blocking.every((hit) => tracker.isRefused(agent, hit.fp)),
        // A model told only "no" retries; a model told "that history is gone and the next window
        // is narrower" has something to act on. Only reported once this target has been through
        // a convergence round, so an ordinary first denial stays short.
        convergence: convergenceNotice(agent, blocking),
      })
    }

    // Allowed. The advisory is computed BEFORE the commit, so this call is
    // counted in the number it reports.
    const advisory = stageAdvisory(agent, fps)
    if (advisory !== null) advisoryFor.set(exec, advisory)
    tracker.commit(agent, fps, [])
    // Deliberately NOT clearing the refusal run here.
    //
    // Letting one call through does not mean the model changed course — a model that wriggles past
    // the denial with a cosmetic change and then comes straight back is the exact behaviour this
    // measure exists to catch, and it is what a backend/model evaluation needs to see. Clearing on
    // release made the count restart constantly (measured: 7, 1, 4, 1, 4 refusals between
    // compactions instead of a tightening 10, 5, 3, 2), so the throttle never tightened at all.
    // The run now ends in exactly one place: after an intervention has been performed on it.
    return undefined
  }

  // The settings box, when the profile has a settings provider. The resolved value is
  // written back onto `cfg`, which is what makes it LIVE: `stageAdvisory` and the
  // tracker both read `cfg` at call time, so a change in the UI applies to the next
  // call without touching either of them.
  // `web_fetch_file` is the replacement a denial points at, so the guard must know whether it
  // can actually FETCH -- naming a tool a profile does not have is worse than naming nothing. The
  // tool registers either way, but the flag the guard reads means capability: true when curl is
  // the backend, and set when the web service arrives for the default backend.
  if (cfg.embedFetchFile === true) {
    // A STANDALONE mount: the operator asked this row to carry the tool, which means no
    // `web-fetch-file` row is mounted. Start from the fetch-file defaults and overlay whatever
    // this row's config actually carries — it may carry none, since the fetch-file keys live in
    // that component's `Config`. Passing `cfg` fields straight through (as this did) handed the
    // tool nine `undefined`s: an output directory literally named `undefined`, and
    // `--max-filesize undefined`, which curl rejects before it fetches anything.
    const unregisterTool = registerFetchFileTool(
      ctx,
      {
        ...FETCH_FILE_DEFAULTS,
        ...(typeof cfg.fetchWithCurl === 'boolean' ? { fetchWithCurl: cfg.fetchWithCurl } : {}),
        ...(typeof cfg.outputDir === 'string' ? { outputDir: cfg.outputDir } : {}),
        ...(Number.isInteger(cfg.maxBytes) ? { maxBytes: cfg.maxBytes } : {}),
        ...(Number.isInteger(cfg.timeoutMs) ? { timeoutMs: cfg.timeoutMs } : {}),
        ...(Number.isInteger(cfg.maxRedirects) ? { maxRedirects: cfg.maxRedirects } : {}),
        ...(typeof cfg.userAgent === 'string' ? { userAgent: cfg.userAgent } : {}),
        ...(typeof cfg.allowPrivateHosts === 'boolean' ? { allowPrivateHosts: cfg.allowPrivateHosts } : {}),
        ...(typeof cfg.cookieJar === 'boolean' ? { cookieJar: cfg.cookieJar } : {}),
        ...(typeof cfg.curlPath === 'string' ? { curlPath: cfg.curlPath } : {}),
      },
      fetchFile,
    )
    if (typeof unregisterTool === 'function') teardown.push(unregisterTool)
  }

  const disposeGuard = ctx.tools.guard(guard)
  if (typeof disposeGuard === 'function') teardown.push(disposeGuard)

  // Records the settled result text quoted by a later denial, settles the fate of
  // a declined ask, and attaches any advisory the guard computed.
  //
  // No counting here: denied calls also reach this waterfall, so counting would
  // double-count. The guard is the only counter.
  //
  // The advisory merge requires awaiting `next()` rather than returning it, so a
  // downstream block's decision is preserved and the context composes with it
  // instead of replacing it.
  const onPost = ctx.on('tools/post-execute', async (exec, result, next) => {
    refresh()
    const { name, agent } = parts(exec)
    let failureAdvisory
    if (agent !== null && tracked(name)) {
      const pending = pendingAsk.get(exec)
      if (pending !== undefined) {
        // A rejected ask never reached the guard, so a surviving entry means the
        // operator declined: spend the budget anyway, so the next identical call
        // is denied outright instead of re-asking, and remember the refusal.
        // The call did not run, so it is not a failure either.
        deniedByUs.add(exec)
        pendingAsk.delete(exec)
        tracker.refuseFingerprints(
          agent,
          pending.hits.map((hit) => hit.fp),
        )
        tracker.commit(agent, pending.fps, pending.hits)
      } else if (!deniedByUs.has(exec)) {
        // The failure track is settled HERE and only here: the outcome is not known
        // before the call runs, which is also why the gate for it can only ever
        // fire on a LATER call.
        const { fps } = fingerprints(exec, cfg)
        // `shell` gates the text fallback: a shell's exit code is masked by
        // pipelines, so its text is the only remaining evidence; other tools answer
        // through their structured value and must not be guessed at from prose.
        const failure = classifyFailure(result, { shell: isShell(name) })
        const warned = tracker.noteOutcome(agent, fps, failure)
        if (warned.length > 0) {
          // Name the longest streak. A tie is broken by `measureRank` for the same
          // reason the occurrence stages do it: identical calls cross `exact:`,
          // `cmd:`, `net:` and `host:` together, and naming `exact:` quotes a
          // truncated command line instead of the target the model can act on.
          const top = warned.reduce((best, entry) =>
            entry.streak > best.streak ||
            (entry.streak === best.streak && measureRank(entry.fp) < measureRank(best.fp))
              ? entry
              : best,
          )
          failureAdvisory = noticeMessage(
            failWarnMessage(top.fp, top.streak, failure, cfg),
            `${top.fp} failed x${top.streak}`,
          )
        }
        const text = renderResult(result)
        if (text) tracker.slot(agent).lastResult = text.slice(0, cfg.resultPreviewChars)
      }
    }

    const downstream = await next()
    const advisory = advisoryFor.get(exec)
    advisoryFor.delete(exec)
    // At most one message per track. Both may fire on the same call -- a repeated
    // call that also failed -- and the failure one goes first because it is the
    // more actionable of the two.
    const owed = [failureAdvisory, advisory].filter((entry) => entry !== undefined)
    if (owed.length === 0) return downstream
    const existing = Array.isArray(downstream?.additionalContexts) ? downstream.additionalContexts : []
    return { ...downstream, additionalContexts: [...owed, ...existing] }
  })
  teardown.push(onPost)

  // A real human turn clears that agent's window — and with it the exemptions and
  // refusals. Plugin notices and tool results do not, so the breaker's own
  // messages never reset the budget they are trying to enforce.
  const onPreStep = ctx.on('agent/pre-step', async (input, next) => {
    refresh()
    const agent = input?.agent ?? null
    if (agent !== null && hasUserMessage(input?.messages)) tracker.reset(agent)
    if (agent !== null) await converge(agent, input?.signal)
    return next()
  })
  teardown.push(onPreStep)

  /**
   * Perform a pending convergence intervention: summarise and replace the span containing the
   * refusal loop, so the model stops retrying a target that is no longer on the surface.
   *
   * This is the one measure a denial cannot be argued with. Every softer move has been measured
   * failing: the model ignored the denial (92 and 321 consecutive refusals in two recorded
   * sessions), and a hint in the denial text is just another message it can re-read. Compaction
   * removes the loop itself — after it, the model sees a checkpoint instead of "I tried this 40
   * times", and there is nothing left to retry.
   *
   * Availability is checked, never assumed: the engine is a service (`ctx.get('compaction')`)
   * and a profile may run none. When it is absent the intervention is skipped silently — a
   * breaker that throws because an unrelated plugin is missing would be worse than the loop.
   *
   * `context-overflow` is the trigger, and deliberately so: it is the branch that compacts
   * WITHOUT consulting a token threshold (`compactNow` would refuse mid-turn — "the session
   * already has an open turn" — and the `pressure` branch only fires on context size, which a
   * loop does not grow). Verified in an isolated instance: a third-party plugin calling this
   * mid-turn produced `compaction/start` → `summary` → `end` and `replaceGeneration: 0 → 1`.
   *
   * @param agent - the agent whose loop crossed the threshold.
   * @param signal - the live turn signal, forwarded to summarisation.
   */
  async function converge(agent, signal) {
    if (convergenceQueue.length === 0) return
    // Only this agent's entries, and only the first: one compaction per step is enough, and a
    // second one would race the first (the engine asserts no active compaction).
    const index = convergenceQueue.findIndex((entry) => entry.agent === agent)
    if (index === -1) return
    const [pending] = convergenceQueue.splice(index, 1)
    const service = ctx.get?.('compaction')
    if (service === undefined || service === null) return
    if (typeof service.compactIfNeeded !== 'function') return
    try {
      const result = await service.compactIfNeeded(agent, 'context-overflow', signal)
      // Close the round: reset the count so the NEXT window can accumulate, and tighten it.
      //
      // The reset is deliberate, not a bug being papered over. Compaction cannot change a model's
      // mind — measured, a scripted model rebuilt the same loop 1076 times while every compaction
      // succeeded — so the useful thing this can do is throttle: give the model a fresh window to
      // demonstrate it has moved on, and make each successive window narrower so a model that has
      // not moved on is reined in sooner. Counting the next attempt against the old total would
      // deny it that room and turn the measure into an immediate permanent lock.
      const round = tracker.recordConvergence(agent, pending.fps ?? [pending.fp])
      if (typeof ctx.logger?.info === 'function') {
        ctx.logger.info(
          `repeat-tool-breaker: convergence round ${round.rounds} after ${pending.streak} refusals of ${pending.fp}` +
            (result === null ? ' (nothing compactable)' : ` (shadowed ${result.shadowedSeqs?.length ?? 0} nodes)`) +
            `; next window ${round.nextThreshold}`,
        )
      }
    } catch (error) {
      // A failed compaction must not take the turn down: the denial still stands, and the model
      // may yet recover on its own.
      if (typeof ctx.logger?.warn === 'function') {
        ctx.logger.warn(`repeat-tool-breaker: convergence compaction failed: ${String(error?.message ?? error)}`)
      }
    }
  }

  /**
   * What to tell the model when a convergence round has already happened for one of the targets
   * it is being denied on.
   *
   * Returns `undefined` unless this target has been through at least one round: a first denial
   * should stay short, and the notice only means something once the surface has actually been
   * rewritten. The numbers come from the tracker, so the message cannot drift from the policy
   * that produced it.
   *
   * @param agent - the agent being denied.
   * @param blocking - the hits that stopped the call.
   * @returns `{ streak, nextThreshold }`, or `undefined` when no round has happened.
   */
  function convergenceNotice(agent, blocking) {
    for (const hit of blocking) {
      const rounds = tracker.convergeRoundsOf(agent, hit.fp)
      if (rounds > 0) {
        return {
          streak: tracker.refusalStreakOf(agent, hit.fp),
          nextThreshold: tracker.convergeThresholdFor(agent, hit.fp),
        }
      }
    }
    return undefined
  }

  return () => {
    for (const fn of teardown) {
      try {
        if (typeof fn === 'function') fn()
      } catch {
        /* best-effort teardown */
      }
    }
  }
}

export { fetchFileToolState, isTracked }

/**
 * The object the loader hands to cordis — and therefore the ONLY place the platform looks
 * for the settings schema.
 *
 * `Config` must be on this object, not merely exported by the module. The loader normalizes
 * a module's exports to ONE plugin object (`unwrapExports`: `exports.default ?? exports`),
 * and cordis copies the schema off that object (`runtime = { …, Config: plugin.Config }`),
 * caching the runtime per apply-callback. With a default export that omitted `Config`, the
 * runtime was built with `Config: undefined`: the plugin ran perfectly, but the settings
 * service found no schema for the entry, never served `repeat-tool-breaker` as a namespace,
 * and the browser card — gated on `configForms.whileServed` — never mounted. Measured on
 * dsh 0.1.7: `runtimeKeys=["name","callback","fibers","Config"] runtimeHasConfig=false`
 * while the module's own schema was valid (`localConfigHasToJSON=true`).
 *
 * The named exports above are kept: tests and the documented module face import them.
 */
export default { name, inject, apply, Config }
