# Changelog

All notable changes to this project are documented here. This project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.11.1] - 2026-10-03

### Changed

- **Settings Page Partitioning by Row**: Partitioned plugin settings into their respective component rows (`repeat-tool-breaker` and `web-fetch-file`) on the DSH Settings → Plugins page instead of dumping all fields into a single bundle card.
- **Row Configuration Slot Support**: Registered `plugins.row.config` slots with row-specific field slicing (`FIELD_LAYOUT` for loop breaker controls and `FETCH_FILE_FIELD_LAYOUT` for file fetch controls) and distinct summary descriptions for each component row in both English and Chinese.

## [0.11.0] - 2026-10-02

### Added

- **Independent `web-fetch-file` Component**: Extracted `web_fetch_file` tool into an independent Cordis component (`dsh-repeat-tool-breaker/fetch-file`, component id `web-fetch-file`), declared alongside `repeat-tool-breaker` in `cordis.patch.yml`. Allows operators to toggle the file download tool on/off independently in DSH Settings → Plugins without affecting loop breaker governance.
- **Fail-Safe Component Coordination**: When `web-fetch-file` is toggled off, `repeat-tool-breaker`'s fail-safe automatically permits shell HTTP downloads, preventing capability dead-ends.
- **DSH Settings Page i18n Row Metadata**: Added `locale/en.json` and `locale/zh.json` for the root breaker component, and `locale/fetch-file/en.json` and `locale/fetch-file/zh.json` for the fetch-file component. Exported via `package.json` (`./locale/*.json` and `./fetch-file/locale/*.json`).
- **Client Bundle Modularization**: Split monolithic 640-line `lib/client.js` into modular source files in `src/client/` (`constants.js`, `locales.js`, `store.js`, `specs.js`, `form.js`, `card.js`, `lifecycle.js`), managed via `scripts/build-client.js` (`npm run build:client`).


## [0.10.0] - 2026-09-29

### Changed — curl is the DEFAULT fetch backend

`web_fetch_file` now retrieves with `curl` unless `fetchWithCurl` is turned off. The switch and its
label stay; only the default moves.

It moves because the platform backend is not merely stricter, it dead-ends: it classifies the
response and cancels the body of anything that is not text, so a PDF is unfetchable rather than
merely discouraged, and this plugin's own block refuses the shell route at the same time. Measured
in session `b623d414`: three calls, nothing produced. A fetch tool whose default cannot download is
a fetch tool that lies about what it is for.

What the default now allows, stated plainly because it is a posture and not a preference: any
content type, redirects followed cross-origin, a per-session cookie jar (0600, under the OS temp
directory), and whatever the shell can reach — loopback and RFC1918 included. Set
`fetchWithCurl: false` to put the tool back behind the platform's SSRF guard: text only,
same-origin redirects only, no private addresses.

Unchanged either way: http and https are the only schemes (no `file://`), the subprocess gets a
fixed argv with `--` before the URL and no shell, `--max-filesize` / `--max-time` / `--max-redirs`
caps apply, a failed transfer leaves no half file, and `allowPrivateHosts: false` still refuses
loopback, link-local and RFC1918 after resolving the host.

### Tests

- The five seam-backend sites say `fetchWithCurl: false` explicitly. They were built from the
  defaults, so flipping the default had silently moved them onto curl — where they fetched real
  URLs and passed for the wrong reason. Explicitness, not a looser assertion.
- T50 is now about CAPABILITY rather than about which service a profile mounts: a bare profile has
  the curl default and therefore blocks shell HTTP, while `fetchWithCurl: false` with no web
  service still keeps it.
- The compat suite's SSRF-guard scenario asks for the platform backend by name (with curl it would
  fetch the loopback URL), and the public-PDF scenario carries NO patch — it is the assertion that
  the default can download a PDF, and it fails if a later release flips the default back.


## [0.9.0] - 2026-09-29

### Added — `web_fetch_file` can download binaries, behind a switch that states the risk

The tool retrieved with `ctx.web`, the platform's web service, which is built for reading: it
classifies the response and **cancels the body** of anything that is not text
(`text/html`, `text/*`, `application/json|xml`, `*+json`, `*+xml` — everything else becomes
`WEB_UNSUPPORTED_CONTENT_TYPE`), and it refuses a cross-origin redirect. Measured on session
`b623d414`, where the model needed two public PDFs: this tool answered `unsupported content type
"application/pdf"` twice, the shell was refused by this plugin's own block, and a text extractor
had nothing to extract. Three calls, nothing produced — a steering block that leads to a dead end
is worse than no block.

`fetchWithCurl` (Settings → Plugins, and the patch layer) now selects the retrieval backend:

- **off (default)** — unchanged: the platform service, its SSRF guard, its redirect policy, its
  caps, text only.
- **on** — a `curl` subprocess: ANY content type, redirects followed cross-origin, a per-session
  cookie jar (0600, under the OS temp directory), and whatever the shell can reach, loopback and
  RFC1918 included.

The boundaries that stay, whatever the backend: http and https only (`curl` speaks `file:` and
`scp:`, and a fetch tool that reads local files is not a fetch tool), a fixed argv with `--` before
the URL and no shell anywhere, `--max-filesize` / `--max-time` / `--max-redirs` caps, no half file
left behind when a transfer fails, and an optional `allowPrivateHosts: false` that resolves the
host and refuses loopback, link-local and RFC1918 answers.

### Changed — the guard's fail-safe now means CAPABILITY, not "a tool definition exists"

`web_fetch_file` registers in every profile (the curl backend needs no web service), so the flag
the guard reads before blocking shell HTTP is set by what can actually fetch: true when curl is the
backend, and set when the `web` service arrives for the default backend. A profile with neither
keeps its shell HTTP, because pointing a denial at a tool that cannot fetch is a lost capability,
not a redirect.

### Verified

- 129 unit tests, including six that drive a real local HTTP server through a real curl: bytes
  identical on disk for a binary body, a cookie carried inside one session and not across
  sessions, a redirect followed with the effective URL reported, a 404 reported as a status with
  the body saved, an oversized transfer refused with nothing left behind, `file://` and a private
  host both refused before curl runs.
- The compat suite gained a seventh scenario that downloads a **real public PDF** with the curl
  backend on, and asserts a `.pdf` on disk with a byte count — the case that motivated the
  feature, reproducible.
- The suite itself was fixed on the way: it wrote the home `settings.yaml` once, and dsh imports
  and RENAMES that file, so the mock provider existed for the first scenario only and every later
  one died on `NO_ADAPTER`. Both the settings and the patch are now restored per scenario.


## [0.8.7] - 2026-09-29

### Fixed — two false positives while verifying the relay against the LOCAL dsh API

Measured on session `74d52304` (dsh 0.1.7): three curls to the local API were refused twice, by
two defects that were each harmless alone. The third refusal in that session was correct and
stays — a remote curl to the relay's public hostname, which is what `web_fetch_file` is for.

- **A URL inside a request body is data, not a target.** The address scan read
  `-d '{"publicOrigin":"https://…"}'` as an address, so an all-local command looked remote and
  the whole-command local exemption never fired. `stripDataValues` now blanks the value of the
  flags that carry data — request bodies, headers, write-out formats, forms, credentials,
  cookies — before addresses are extracted. That also removes the candidate a
  `-w "  http=%{http_code}"` format string used to produce, whose verb was `http`.
- **A target held in a variable is still a target.** The real target was
  `$B/remote/provider`, with `B=http://127.0.0.1:3080/api/mobile-access` assigned earlier in the
  same command, so the per-candidate exemption had nothing to test and a named verb with no
  visible address was refused. `resolveAssignments` substitutes simple `NAME=value` assignments
  and `$NAME` / `${NAME}` references — shallow on purpose: one pass, no recursion, arrays left
  alone, and a value containing `$` is not re-expanded.

Both run per **candidate, by verb**, and that is not a detail. A short flag's meaning belongs to
its verb: `-c` is a cookie jar for a fetcher and "execute this" for a shell, `-e` is a referer
for a fetcher and "evaluate this" for node, perl or php. A flat, verb-blind flag table deleted
the inline program out of an inline shell fetch and an inline interpreter fetch, letting both
through — the suite caught it in five places. `CODE_VERBS` names the shells and interpreters
whose flags carry code, and the table is skipped for them; their inner commands still arrive as
their own candidates and are judged on their own verbs.

Not a hole, and pinned by tests: a REMOTE target behind the same variable is still refused, an
unresolvable target is still a refusal, and inline interpreter fetches stay refused.

Verified: 123 unit tests, the 25-case probe at zero disagreement, the 0.1.7-rc.2 compat suite,
and a replay in which the two false positives are allowed and the true positive is still refused.

### Added

- `test/fixtures/session-74d52304-shell-http-refusals.json` — the session's three refusals with
  each one's verdict and reason. Two were false positives and one was right; pinning only the
  first kind would invite a rule that allows everything.


## [0.8.6] - 2026-09-29

### Added — the dsh compatibility range is machine-readable

The supported range was prose only: the description and the README said "requires dsh >=
0.1.7" while nothing a resolver reads said so. It is now an `optional` **peer dependency** on
`@deepseek-ai/dsh`:

```
^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.1-0
```

Two details are load-bearing. The lower bound is `0.2.0-rc.1` and not `0.2.0`, because semver
admits a prerelease only when a comparator in the same set names one — `>=0.2.0` would reject
every 0.2.0 rc, including the build this plugin was just verified against. And the peer is
`optional`, because dsh is provided by the host at runtime: npm 7+ and pnpm 8+ install
non-optional peers automatically, which would pull a second copy of dsh into a consumer's tree
and pin it in their lockfile.

A test pins both the range and the optionality.

### Documentation — the README now says what 0.8.5 does

Three statements had gone stale, one of them wrong: the card is on the **package** page in
**Installed** (not a list item to expand, and deliberately not in **Official**, whose list is
built from the `plugins.item` slot where dsh's own plugins live); the slot is the keyed
`plugins.bundle.config` keyed by the **package** name; and a saved value lands in the
**profile's patch layer**, which is where it was measured, not in the managed settings
document.

## [0.8.5] - 2026-09-29

### Changed — the card no longer appears under Official

The Plugins page builds its item list from `ctx.slots.entries("plugins.item")` — the same slot
dsh's own plugins register into, which is where Shell, Agent loop, Subagent and Web search come
from. Claiming it made this third-party plugin show up under **Official**, beside shipped ones.
After 0.8.4 moved the form to the keyed `plugins.bundle.config` slot, that entry was left
holding only a label and a one-liner: an item that announced an official plugin and led to a
page with no settings on it.

The list registration is gone. The card claims `plugins.bundle.config` only, so the plugin
appears where every other non-dsh plugin does — in **Installed**, with the package description
and the configuration form. Nothing serves a summary view any more, and the component answers
only the view its slot asks for, so a stray view renders nothing rather than a half-card.

Verified on dsh 0.1.7-rc.2 and 0.2.0-rc.2: absent from Official, present in Installed, form with
all seven fields and Save on the package page.

## [0.8.4] - 2026-09-29

### Changed — the card renders on the bundle's configuration page

The Plugins page serves three configuration slots and they are keyed differently:
`plugins.item` is a **list** slot (entries matched by `id`, filtered with `{only}`) that feeds
the page's item list and each row's one-liner, while `plugins.bundle.config` is a **keyed**
slot (entries matched by `key`, filtered with `{entryKey: pkg.name}`) that renders a package's
configuration form. The card claimed the list slot for both jobs, which put the same settings
in two homes — the item's detail page and the package's page.

The form now lives on the bundle slot, keyed by the **package** name (not the settings
namespace), and the list slot keeps the label and the one-liner. A wrong keyed option is
silent rather than loud: the page's "configured" ledger is `keysOf('plugins.bundle.config')`,
so an entry whose key is not the package name simply leaves the package un-configurable. The
name is therefore a pinned constant, asserted against `package.json` by the suite.

Verified on dsh 0.1.7-rc.2 and 0.2.0-rc.2 in isolated instances: the form renders with all
seven fields on the package page, the item's detail page keeps its summary and shows no empty
gap, and a Save from the new home lands in the profile patch.

### Added

- `test/compat`: a sixth scenario that calls `web_fetch_file` end to end — the tool every
  denial points at had never been exercised. The mock gains `MOCK_TOOL` / `MOCK_TOOL_ARGS` so
  a scenario can emit any tool call, and the harness gains `EXPECT_TEXT` / `EXPECT_FILE` /
  `EXPECT_ANY_ERROR`. One half asserts the inherited SSRF guard (loopback is refused BY
  DESIGN); the other fetches a public page and asserts a non-empty file, skipped with a
  printed note when DNS is unavailable so the suite never fails merely for lack of network.
- `tools/compare-rtb-surfaces.sh` — file-identity and invariant comparison across two
  installed dsh lines, for this plugin's surfaces. Run when a dsh release lands.

## [Unreleased]

## [0.11.8] - 2026-11-04

### Fixed — `allowPrivateHosts: false` was ignored on the platform backend

The private-host check sat inside the CURL branch only, because the platform backend inherited
dsh's own SSRF guard. **dsh 0.2.2 removed that guard**: 0.2.1's HTTP provider resolved the
hostname and refused non-public addresses (`isPublicIpAddress`, "URL hostname … resolves to a
non-public IP address"), while 0.2.2's `requestOnce` calls `undici.fetch(url)` directly with no
resolution check and no connection pinning — the guard is absent from every published package
(`isPublicIpAddress`: 1 package in 0.2.1, 0 in 0.2.2).

So on 0.2.2 `fetchWithCurl: false` + `allowPrivateHosts: false` still fetched `127.0.0.1`, and the
failure surfaced as `TypeError: fetch failed` from undici. The check now runs BEFORE the backend
branch, so both backends honour the setting:

    web_fetch_file: 127.0.0.1 is a local address and `allowPrivateHosts` is false

Operationally: the curl backend always applied this plugin's own policy; on dsh 0.2.2 the platform
backend does too, which is the only policy left now that dsh has none.

### Compatibility — dsh 0.2.2-rc.1

- **The peer range admits 0.2.2**: `^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.3-0`. The previous bound
  (`<0.2.2-0`) is exactly the line 0.2.2 falls outside, so the plugin would have been SKIPPED by
  the compatibility gate — the same silent failure as 0.2.1. Checked with 0.2.2's own
  `evaluatePluginCompatibility`: `<0.2.3-0` admits 0.2.2-alpha.3 and 0.2.2-rc.1 and still rejects
  0.2.3; 0.2.1-rc.2/rc.5 stay admitted.
- **The contracts the plugin depends on are unchanged in 0.2.2**, read from the shipped sources:
  `tools.guard()` still appends a synchronous guard whose return value is the denial
  (`checkGuards` → `const reason = guard(exec)`); `register` still refuses a duplicate name; the
  `compaction` service is still `super(ctx, "compaction")` with its `context-overflow` arm; the
  `plugins.row.config` slot and its `${bundle}#${rowId}` key are byte-identical; and
  `web.fetch({ url }, signal)` keeps its signature.
- **The seven-scenario compat suite passes on 0.2.2-rc.1**, and an isolated 0.2.2 instance reports
  `v0.11.8`, `2 total · 2 running`, with both settings cards rendering and each carrying its own
  Save.
- The compat scenario that used to assert dsh's SSRF wording now asserts this plugin's OWN policy,
  so it measures the plugin on every dsh line instead of measuring dsh.

## [0.11.7] - 2026-10-23

### Fixed — a crawl of one site's pages was denied as a "repeat", and it cost real data

Reported from a real session (`session-97bb0007`, a weather-data task): six **distinct** pages of
one dataset on `climate.weather.gc.ca` reached `host: 6/6` and the sixth was denied as
`REPEAT_TOOL_BLOCKED: repeated web_fetch_file (semantic match)`. The five counted pages were a
search form, a station search and three monthly data pages; the denied one was the next month. The
run ended with eight of thirteen months missing, because the denial left no route: shell HTTP is
blocked by design (redirected to `web_fetch_file`), and `web_fetch_file` was then blocked by its own
breadth cap.

The cause is a design-level conflation, not a bad threshold. `host:` discards the URL path on
purpose, so "many different pages of one dataset" and "one broken endpoint, hit again and again"
are the same shape to it. 0.4.1 had already recorded this ("it discards the URL path, so installing
many packages from one mirror and re-fetching one broken URL look identical to it") and answered it
by loosening the cap to 16 — the window itself. That moves the collision, it does not remove it.

The two jobs are now separated:

- **Identity** fingerprints (`exact:`, `cmd:`, `net:`, `sink:`) still count every call. An identical
  action is repetition whether or not it worked.
- **Breadth** fingerprints (`host:`, `site:`, `family:`, `verb:`) are recorded at guard time, when
  the outcome is unknown, and **taken back when the call settles with a result**. A call that
  produced something is work, not repetition. Failures keep their count, so the shape the measure
  exists for still accumulates.

The failure track is untouched. "A different script each time, same host, all failing" (T42) still
fires, because a run of failures is a run of failures no matter how the action is spelled.

`host: 6` no longer needs raising in the profile that reported this: productive pages stop counting,
and an unproductive run still gates at the sixth call.

### Fixed — the stage-2 advisory asserted an outcome it could not know

The summarise demand said "has now come up N times this turn **without producing a result**" for a
count that ignored outcomes. In the reporting session four of the five counted calls had returned
HTTP 200 and written files. The claim is removed; the count and the demand stay.

### Tests

139 unit tests (was 138). T52 replays the measured window — the six real URLs, then the same six
with nothing produced — and asserts that the productive run is never denied while the unproductive
one is denied on the sixth call. T14c now proves both halves of the breadth rule (fourteen
productive pages accumulate nothing; unproductive ones gate), and T28/T29 drive unproductive calls,
which is the only shape in which a volume measure speaks.

The seven-scenario compat suite passes on dsh 0.2.1-rc.2.

## [0.11.6] - 2026-10-12

### Fixed — the peer range was wider than what was verified

0.11.5 widened the dsh peer range to `<0.3.0-0`, which admits every 0.2.x release. That is
wider than the evidence: the compat suite and the card render were exercised against
**0.2.0-rc.2 and 0.2.1-rc.2** only. A peer range is a claim about what has been tested, so the
upper bound is now

    ^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.2-0

— the 0.2.1 line including its final release, and nothing beyond it. 0.2.2 is NOT admitted: when
it arrives, the suite runs against it and the bound is widened on the evidence.

Checked with dsh's own evaluator (the `evaluatePluginCompatibility` the compatibility gate itself
uses), not with a re-implementation of semver:

    ^0.1.7-rc.2 || >=0.2.0-rc.1 <0.3.0-0   0.2.1-rc.2 OK  0.2.1 OK  0.2.2-rc.1 OK  0.3.0-rc.1 REJECT
    ^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.2-0   0.2.1-rc.2 OK  0.2.1 OK  0.2.2-rc.1 REJECT  0.3.0-rc.1 REJECT

138 unit tests pass. The two peer assertions in `test/fetch-file.test.js` follow the range.

## [0.11.5] - 2026-10-12

### Fixed — `sink:` was noise in 85% of its cases, and it told a model it was looping when it was not

An advisory in a real session read

    CONVERGENCE_CHECK: you are repeating yourself — sink:StrictHostKeyChecking=accept-new
    has come up 7 times this turn.

It is not a loop. `-o StrictHostKeyChecking=accept-new` is the connection option every `scp` in
that session carried. Measuring every recorded session (127 sessions, 57,261 bash commands) showed
12.2% of commands produced a `sink:` and roughly **85% of those were noise**, from three
independent causes:

- **`-o key=value` was read as an output path.** For `ssh`, `scp`, `sftp`, `rsync`, `mosh`,
  `sshpass` (and `mount`, `docker`, `ffmpeg`, `git`, …) `-o` is ALWAYS an option, and no real
  destination is spelled `key=value`. Removed: `BatchMode=yes` (197), `StrictHostKeyChecking=accept-new`
  (176), `IdentitiesOnly=yes` (21), `ConnectTimeout=10` (20).
- **`> /dev/null` was kept as a sink** — 1,833 occurrences, 26% of all. Discarding output is the
  ABSENCE of a destination; keeping it gave every silent command one identity.
- **the sink was credited to the line's first verb**, so `cd /tmp && echo hi > out.txt` recorded
  `sink:out.txt` owned by `cd` — 3,679 occurrences, 53% of all. Only verbs that produce a payload
  may own a sink now, and `sinkVerb()` finds the writing command in the chain.

Measured with the same harness over the same corpus, sinks fall from **6,966 (12.2%) to 1,102
(1.9%)**, and what remains is dominated by the commands that really write (cat 833, echo 141, curl
69). `cd`, `ssh`, `scp`, `docker`, `git` and `/dev/null` are gone entirely.

Known residual, recorded rather than guessed at: a `>` inside a regex or a quoted string still
yields a sink-shaped token, and `=` appears as a value. Those are tokenizer-level (quote and regex
awareness), not sink semantics.

### Fixed — the plugin did not mount on dsh 0.2.1, because the peer range excluded it

dsh 0.2.1 added a compatibility gate: a plugin whose peer range does not admit the running runtime
is **skipped**, not crashed — the profile boots and the plugin is simply absent. The plugin
manager says so plainly:

    Problem: dsh-repeat-tool-breaker@0.11.4 is incompatible with DSH 0.2.1-rc.2
    (requires @deepseek-ai/dsh ^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.1-0)
    This plugin pack contains no components.

The old upper bound `<0.2.1-0` excluded every 0.2.1 release, so the plugin was silently absent on
the current dsh. The range is now

    ^0.1.7-rc.2 || >=0.2.0-rc.1 <0.3.0-0

— the whole 0.2.x line, 0.1.7 kept (production still runs it), 0.3.0 still excluded. The range was
checked with dsh's OWN evaluator (`evaluatePluginCompatibility` from the 0.2.1 app-boot), not with
a re-implementation of semver:

    ^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.1-0   0.1.7-rc.2 OK  0.2.0-rc.2 OK  0.2.1-rc.2 REJECT
    ^0.1.7-rc.2 || >=0.2.0-rc.1 <0.3.0-0   0.1.7-rc.2 OK  0.2.0-rc.2 OK  0.2.1-rc.2 OK  0.3.0 REJECT

Compatibility was verified rather than assumed, because the gate only says a plugin is refused —
never why it would have worked:

- the four contracts this plugin depends on are unchanged in 0.2.1: the tool guard still returns a
  denial string synchronously, a duplicate tool registration still raises, the `compaction` service
  is still `super(ctx, "compaction")` with `compactIfNeeded` and its `context-overflow` branch (the
  forced compaction), and the row-config slot key is still `${bundle}#${rowId}` with the same
  `entryKey` filtering;
- the seven-scenario compat suite PASSES on 0.2.1-rc.2;
- an isolated 0.2.1 instance with no exemption shows `2 total · 2 running` and BOTH settings cards
  render with their own Save.

The compat suite gained a `COMPAT_EXEMPT` hook: dsh 0.2.1 refuses to mount a plugin whose peer
range does not admit the runtime, so running the suite against such a dsh would fail at "the bundle
did not mount" for a reason unrelated to the behaviour under test. The hook writes the
profile-local exact-version grant, so the suite measures BEHAVIOUR and the peer range is judged
separately.

### Tests

- 138 unit tests (was 138). The two peer assertions in `test/fetch-file.test.js` were updated to
  the new range; they exist precisely to stop the peer range being changed silently.
- Nine sink shapes covering the three causes were verified by hand against the real extractor.

## [0.11.4] - 2026-10-12

### Added — a convergence throttle: compaction as a last resort against "the model keeps calling it"

Every other measure assumes a denial ends the matter. It does not. Two recorded sessions show a
model calling one target **92** and **321** times after it was first refused, and each denial is
invisible to the counters: a denied call produces no result to classify (the failure track sees
nothing) and a denial resets the occurrence window (the cap never accumulates). The refusal itself
is the only signal left.

Three knobs implement the response, and the semantics are the point:

- **`convergeAfter` (10)** — accumulated refusals of one target before the span that keeps retrying
  it is summarised and REPLACED. The engine is called through the public service
  (`ctx.compaction.compactIfNeeded(agent, 'context-overflow', signal)`), which is the only path
  that compacts mid-turn: `compactNow` refuses inside an open turn, and the pressure branch only
  fires on context size, which a loop does not grow. Nothing private is touched and no official
  file is modified.
- **`convergeRelief` (0.5)** — each round NARROWS the next window: 10, 5, 3, 2, 2. One compaction
  is not a cure — a compaction removes the loop from the surface but cannot change a model's mind,
  and the first version of this produced **1076 compactions in one run without breaking the loop**.
  So the intervention is a throttle: it resets the count and tightens what comes next, giving the
  model room to rejoin the right path and reining it in sooner when it does not.
- **`convergeFloor` (2)** — the window never shrinks below this, so the escalation stays
  predictable.

When a round closes, the denial says so: that the history it kept retrying has been replaced, that
this is a fresh start rather than a permanent ban, and what the next threshold is.

### Fixed — two defects the first implementation had, both found by measurement

- **A released call no longer resets the run.** Treating a call that got through as a fresh start
  let the count restart forever: measured 7, 1, 4, 1, 4 refusals between compactions, with the
  tightening never taking effect. Whether a model comes BACK after being let through is exactly the
  signal a backend/model evaluation wants, so the run is ACCUMULATED and ends only when an
  intervention has been performed for it.
- **A round closes the whole fingerprint group.** One refused call carries several views of the
  same action (`exact:` and `cmd:` here) and every view is counted. Closing only the first left the
  others accumulating toward their own thresholds, so they fired in alternation instead of
  tightening.

### Verified

- 138 unit tests (was 135): T60 pins accumulation across releases and the 10 → 5 → 3 → 2 window;
  T61 pins `convergeAfter: null` as a full off-switch; T62 pins the human-turn reset.
- End to end in an isolated dsh 0.2.0-rc.2 instance, driven by a scripted model that never stops
  calling one failing target: the refusals between interventions go 7 → 2 → 1 and stay there,
  i.e. the window really does tighten.
- The seven-scenario compat suite passes on dsh `0.2.0-rc.2`.

### Note for anyone testing this

An install is only an install when the VERSION changes. Three rounds of end-to-end testing here
measured a stale build — `pnpm add` saw the same version on the tarball and left the old copy in
place, so the new semantics were never exercised while the unit tests (which import the source
directly) passed. Bump the version before measuring behaviour, and confirm the new code is present
in `node_modules`.

## [0.11.3] - 2026-10-11

### Fixed — the shell-HTTP block refused scripts that merely NAMED a request API

A retest session (`a3_snowfall_retest`) was refused **126 times**, 102 of them for one command: a
`python3` heredoc scanning an already-downloaded local file for keywords.

```python
for kw in ['DATA_URL','ajax','fetch(','axios']:
    hits = [m.start() for m in re.finditer(re.escape(kw), src)]
```

It makes no request. The keyword list contains the *spelling* of a request API, and the
interpreter arm's pattern matched it. `echo 'fetch('`, `grep -rn 'fetch(' src/`,
`printf '%s' 'urlopen('` and `re.escape('axios')` were refused too — every one a NAME, not a call,
which is the distinction the blacklist already draws with `command -v curl`.

`stripStringLiterals` now blanks the CONTENT of every string literal before the API pattern runs,
so mentions stop reading as calls. Four boundaries decided the implementation, and each was found
by a test or a measurement rather than by reasoning:

- **A quote is shell syntax; its content is what the interpreter receives.** Blanking is right for
  a mention and wrong for the program a `-c` / `-e` argument or a heredoc body carries: blanking
  those deleted real calls and let requests through (`node -e "fetch(URL)"`, then a single-quoted
  `python3 -c` program — the second caught by the T48g regression test).
- **A heredoc delimiter is syntax; its body is a program.** The delimiter is always blanked, and
  bodies are located from the PRISTINE text, once: the delimiter rewrite erased the marker a later
  rescan needed, which silently resurrected the original false positive.
- **A segment is not a unit of meaning.** `unwrapCommands` splits inside quotes, so
  `python3 -c "print('uses fetch(')"` arrives as three fragments, the middle one with a
  nonsense verb that is not a `CODE_VERB`. Stripping per segment then read the program's inner
  quotes as shell strings and blanked them the wrong way round. The whole command is stripped as
  one text.
- **Some evidence IS a string literal.** `require('axios').get(…)` is identified BY the module
  name, so blanking removes what the pattern looks for. That family reads the unblanked text, while
  the invocation family (`fetch(`, `urlopen(`) reads the blanked one.

Also asserted in both directions: importing a module is still free (`import urllib.request` is
allowed — it performs no request), and an all-local command keeps its exemption.

### Tests

- `B7a` pins seven mentions that must be allowed — the retest session's heredoc, `echo`, `grep`,
  `printf`, an inline `print`, and a bare import — against six calls that must still be refused,
  including the single-quoted-program and heredoc-program shapes that blanking first broke.
- 135 unit tests (was 134) and the seven-scenario compat suite on dsh `0.2.0-rc.2`.

## [0.11.2] - 2026-10-03

### Fixed — the two-row split collided with any profile patch that reconfigured the breaker row

`web-fetch-file` failed to activate, in an isolated 0.1.7 instance and in exactly the way the
production profile is configured:

```
dsh: warning: 1 entry did not activate
web-fetch-file (dsh-repeat-tool-breaker/fetch-file): Error: tool "web_fetch_file" is already
registered
    at registerFetchFileTool (lib/fetch-file.js:510)
    at new apply (lib/fetch-file-component.js:72)
```

The bundle's breaker row sets `embedFetchFile: false` so the dedicated row owns the tool, but a
profile patch that reconfigures that row (`warnAt: 8`, say — the normal way to tune it) REPLACES
the whole key set, so the flag falls back to its default `true` and the breaker registers the tool
too. The second registration throws, and the entry it takes down is the one whose settings card the
operator needed. Two changes, because either alone leaves a trap:

- **Registration is idempotent.** A second caller stands down when the name is taken and reports
  the capability it can see, instead of throwing. A collision can no longer cost a row.
- **`embedFetchFile` defaults to `false`.** The bundle always declares the dedicated row, so that
  is the design; the flag survives as the explicit opt-in for a profile that mounts the breaker
  ALONE. With `true` as the default, the recovery from a dropped key WAS the collision.

The standalone path is repaired too: it read nine keys off the breaker's own `cfg`, but those keys
moved to the fetch-file component's `Config`, so every one was `undefined` — an output directory
literally named `undefined`, and `--max-filesize undefined`, which curl rejects. It now starts from
the fetch-file defaults and overlays whatever that row carries.

### Tests

- A duplicate registration stands down: no throw, one definition, capability reported.
- The DEFAULT breaker config does not register the tool, and mounting both rows leaves exactly one
  registration with the block running — while an explicit standalone mount plus the row still
  cannot collide.
- The component test's fake `ctx.tools` grew a `get`, mirroring the real registry. Without it the
  collision was inexpressible, and the first version of the test passed while proving nothing.
- The compat harness's SSRF-guard scenario patches the `web-fetch-file` row now, because that is
  where the fetch-file settings live; the old patch on `repeat-tool-breaker` selected nothing and
  the scenario would have fetched the loopback URL it asserts to be refused.

Verified in an isolated dsh 0.1.7: both components running (was `1 failed`), both cards rendering
with their own Save, and a Save on the fetch-file card landing in the `web-fetch-file` row of the
profile patch.


## [0.8.3] - 2026-09-27

### Fixed — the shell-HTTP block refused ordinary work in a second session

Measured on session `12b8bd5b` (dsh 0.1.7, 174 tool calls): **eight refusals, seven of them
legitimate**. The agent was installing software on another machine over `ssh`, and the block
was judging the words *inside* that remote payload as if they had been typed here.

- **A remote payload is judged only when it runs HERE.** `ssh localhost '…'` is a local fetch
  wearing a costume and is still refused — with `sshpass` and `mosh` counted as shells for the
  same reason. An `ssh` to another machine fetches over there, where `web_fetch_file` cannot
  act, so judging it refused remote administration and nothing else, down to "does the target
  even have these tools?". A target that cannot be resolved from the text (a variable, a
  command substitution) is treated as elsewhere: a false refusal costs a whole tool call, which
  is this project's standing trade.
- **Splitting is quote-aware.** A quoted `;` or `|` no longer cuts a command apart. That is
  what made a remote payload unrecognisable, and it also turned a quoted regex such as
  `grep -iE "^(wget|curl)$"` into a candidate starting with a fetch verb.
- **A name list is data**: `command -v X`, `command -V X`, `which X` and `type X` look names
  up. `command X` without a lookup flag still executes, and is still judged.
- **A named verb needs an argument.** A bare `curl` prints usage and fetches nothing, so a lone
  word inside a regex, a label or a banner is no longer a refusal.
- **A heredoc written to a file is not run by this call.** `cat > f <<EOF … curl … EOF` authors
  a script; the fetch happens when something else runs that file. A body handed to an
  interpreter (`python3 - <<PY`, `bash <<EOF`) still runs here and is judged exactly as before.

Known limit, stated rather than hidden: the target check reads the TEXT, so an `ssh` alias in
`~/.ssh/config` that points at this machine is still a hole. Closing it means parsing the ssh
configuration, which is a different size of change.

Verified: 121 unit tests — three new groups plus the two assertions that encoded the previous
behaviour — the 25-case probe at zero disagreement, the session replay (seven of the eight now
allowed, the remaining refusal being the local fetch that *should* be refused), and the 0.1.7
compat suite.

### Added

- `test/fixtures/session-12b8bd5b-shell-http-refusals.json` — the eight real commands with
  identities, hosts, addresses, key paths and repository names removed and the command shapes
  kept verbatim, so the next retune can replay what actually happened.

## [0.8.2] - 2026-09-26

### Fixed — the shell-HTTP block refused ordinary work

Measured on session `face7ffb-0f53-46a6-aa86-94a3b98346be` (dsh 0.1.7): **four of 164 tool
calls were stopped and every one of them was legitimate** — three python scripts talking to a
**local** endpoint, and one that fetched nothing at all. Three separate causes, all fixed:

- **The short HTTPie name left the default blacklist.** As a segment's first token that word
  is overwhelmingly *data* — a status write-out format string, a JSON scheme value, a list of
  schemes — and a refusal there has no address to exempt it. `httpie` is spelled out instead.
  An operator who wants the short name can add it back to `shellHttpBlock`.
- **The local exemption is now evaluated over the whole command, not per segment.** The
  command splitter breaks a heredoc on newlines and commas, so a script's request API and its
  address arrive in **different** segments; the per-segment test saw "an API with no address"
  and refused it, while the per-segment exemption could never fire. A command whose every
  address is local is now never a remote fetch, whatever mechanism it uses.
- **`FETCH_API` names a call, not a module.** Matching the bare module name refused scripts
  that merely **imported** a request library — including one that made no request at all. Each
  alternative now requires the invocation itself (`urlopen(`, `requests.get(`, `httpx.get(`,
  `fetch(`, `Invoke-WebRequest`, a require-style client call, …).

Unchanged on purpose: `blockLocalHttp: true` still blocks the local cases, and an empty
`shellHttpBlock` remains the documented off-switch. Remote fetches are refused exactly as
before — eight mechanisms are pinned in the new test.

### Added

- `test/shell-http-block.test.js` — ten cases built from the commands that were refused.
- `tools/shell-http-fp-probe.mjs` — the false-positive probe that found them (25 must-allow
  and must-block cases), plus `test/fixtures/session-face7ffb-shell-http-refusals.json`, the
  corpus the commands came from.

### Note on the earlier coverage claim

The previous "0 false positives over 28,471 recorded calls" was a **corpus blind spot**:
neither a status write-out format string nor a python script against a local endpoint occurs
in that corpus. Both shapes are pinned now, so the claim has a test behind it instead of a
corpus assumption.

## [0.8.1] - 2026-09-26

**No behaviour change since 0.8.0.** This release exists to move the `latest` dist-tag onto
the dsh 0.1.7 line, which is the only way this project can move a tag: npm's Trusted
Publishing covers `npm publish` and nothing else (a `npm dist-tag add` run under the same
OIDC setup fails `E401 Unable to authenticate`, measured), npm's website exposes no dist-tag
UI, and published versions are immutable — so the tag follows a new version instead of being
moved in place.

`latest` therefore resolves to **0.8.1**, which targets **dsh >= 0.1.7**. On dsh 0.1.5 install
**0.7.x**: a fresh install of the 0.8 line there loses the **settings page** (everything else —
repeat detection, denial, the shell-HTTP block and the advisories — works, verified on
0.1.5-rc.2).

## [0.8.0] - 2026-09-25

**BREAKING: this release targets dsh 0.1.7 (session format 4) only.** 0.1.7 removed the
imperative settings API and changed the message-source shape, and the two source shapes are
**mutually exclusive** — one of them throws on each host — so the generations are served by
two lines: **0.8.x for dsh >= 0.1.7**, **0.7.x for dsh 0.1.5**. No configuration key changed;
`shellHttpBlock` and the rest keep their names and semantics.

### Changed — the settings page, rebuilt for 0.1.7

- **The exported `Config` IS the settings schema now, and it must ride the DEFAULT EXPORT.**
  0.1.7 deleted `ctx.settings.register`: `SettingsForms.schema(entry)` reads
  `entry.fiber.runtime.Config`, and the namespace is the **loader entry id**. The loader
  normalizes a module's exports to ONE object (`unwrapExports`: `exports.default ?? exports`)
  and cordis copies the schema off that object, caching the runtime per callback — so a module
  whose default export omitted `Config` ran perfectly while its settings page never appeared.
  Measured: `runtimeKeys=["name","callback","fibers","Config"] runtimeHasConfig=false` against
  `localConfigHasToJSON=true`.
- **Every settings field is `.volatile()`.** `volatileForm()` keeps only volatile fields and
  `describe()` drops an entry whose form is empty, so a schema without them has no form at all.
  The fields are delivered as **live handles** and are read with `.get()`; the config is
  refreshed in place before every hook, so an edit takes effect without a remount. A documented
  `null` off-switch needs `z.union([z.number(), z.const(null)])`, and an **unset** volatile
  union resolves to `undefined` rather than `null`, which is normalized so the off-switch
  behaves the same whether it was set or defaulted.
- **The card is built from the platform's own components.** It registers into the 0.1.7 slot
  **`plugins.item`** (`{ name, id, order, label, locale, inject }`) behind
  `ctx.configForms.whileServed([entryId])`, injects `['slots', 'locale', 'configForms']`, and
  renders `SettingsForm` + `SettingsValueField` from `@deepseek-ai/dsh-client-ui-primitives`.
  It previously rendered its own card frame, which in 0.1.7 doubled the chrome, mis-styled it,
  and put a header button over the platform's that swallowed clicks.
- **`view === 'summary'` is implemented.** The page renders a card's summary as the row's
  description; without it the list falls back to this package's npm description.
- `@deepseek-ai/schemastery` is now `^3.18.4` — `.volatile()` does not exist in 3.18.2 — and
  `dsh.client.inject` names the 0.1.7 packages (`-client-locale`, `-ui-settings`,
  `-ui-plugin-manager`).
- **The message `source.kind` is `plugin:dsh-repeat-tool-breaker`.** Session format 4 rejects
  the retired `{ kind: 'plugin' }` wrapper that format 3 *requires*.

### Changed — the compatibility harness

- **It reads both session-format payload shapes.** Format 4 flattened `tool/result` (the
  message IS the result) where format 3 nested it (`content[] -> type: 'tool-result'`); the
  old parser silently found ZERO results on 0.1.7 and reported it as "the run hung or died".
- The mock model's log is kept at a stable path instead of a `mktemp -d` that is gone by the
  time anyone asks why a scenario failed, and a result-count mismatch now **names the cause**
  (provider failures recorded in the session vs. a run that died early) instead of guessing.

### Added

- **T54**, the failure gate's pivot contract, measured with `web_fetch_file` and 404 results:
  after five consecutive failures the failing endpoint and another path on the **same host**
  stay blocked, while a different website, a different subdomain of the same registrable
  domain, and unrelated tools are all allowed — and a `200` clears the streak. It also
  records that `site:` does not participate in the failure track, which is what lets a
  subdomain through.

### Notes

- **Card artwork is not available to a third-party plugin.** The Plugins page looks the icon
  up in a map hard-coded in the official plugin-manager bundle, and the `plugins.item` slot
  schema has no icon option, so this card shows the platform's default artwork. Written down
  here so it is not mistaken for a defect.
- `socat` remains deliberately absent from `shellHttpBlock`: the coverage scan's only misses
  are `socat -V`, `socat -h` and a local relay, none of which fetch anything.

## [0.7.0] - 2026-09-24

**BREAKING: the block is a BLACKLIST, and the setting is the list itself.** `shellHttpAllow`
is gone; `shellHttpBlock` replaces it and holds the COMMANDS TO REFUSE. A profile still
carrying the old key fails the load with a pointer at the new one rather than silently
losing its configuration.

**Why.** The old rule fired on any non-local URL, so a command was refused for merely
CONTAINING an address — a grep pattern, a heredoc writing a README, a commit message quoting
a link — and the refusal then asserted that the call "fetches over HTTP", which was false,
and pointed at `web_fetch_file`, which cannot help with a grep. Measured over the corpus,
the worst of that has been the most-complained-about behaviour in production.

**How it works now.** `unwrapCommands()` traverses every place the command line can run
something — split on the separators, then open the shells: command substitution, a shell
host (`sh -c`, `ssh`, `xargs`, `sudo`, `timeout`, …), `find -exec`, and a quoted
sub-command — and each candidate is judged on ITS OWN verb. A verb on the blacklist, or an
interpreter program naming a request API (`urllib`, `requests.`, `fetch(`, …), makes the
call refuse. Coverage is deliberately extensible: another shell to open is another entry in
`SHELL_HOSTS`, another command to filter is another list entry, and neither requires the
rule to model where a mechanism appears.

**Measured** with `tools/block-coverage.mjs` over 28,471 shell calls:

| | |
|---|---|
| calls that really fetch | 4042 |
| refused | 4022 |
| **coverage** | **99.5%** |
| **refused that fetch nothing** | **0** |

The 20 misses are `socat` invocations — `socat -V`, `socat -h`, and a local TLS relay —
none of which fetch anything, so they are evidence of nothing rather than a gap. `socat` is
therefore NOT on the blacklist.

### Fixed

- **A URL whose port is a shell variable no longer loses its locality.**
  `http://127.0.0.1:$PORT/health` made `new URL` throw, and a throw read as "there is no
  address at all" — so a LOCAL endpoint written that way was classified as remote and
  refused. It is an ordinary way to write a health check, and it dominated the
  false-positive set (316 corpus calls) rather than being a curiosity. A non-numeric port is
  now dropped before parsing: it is part of no fingerprint. The port separator is found
  after an IPv6 literal's closing bracket, so `[fe80::1]` is not truncated to `[fe80:`.

## [0.6.2] - 2026-09-24

### Fixed

- **`grep` is no longer refused when its PATTERN contains a URL.** `shellHttpAllow` gains
  `grep` and `rg`. A grep command containing an address is searching text *for* that
  address — grep has no network stack, so no amount of it can fetch anything. Refusing it
  did not redirect a fetch; it blocked a read. Worse, the refusal message then asserted
  that the call "fetches over HTTP", which is simply false, and told the model to use
  `web_fetch_file` for an operation that tool cannot perform. A guard that lies about why
  it fired is worse than one that is narrow.

  The line is **pattern-position tools**, not "any verb without a network stack": `echo`,
  `head`, `cat`, `sed` and `awk` stay out, because the corpus contains commands where one
  of those merely PRINTS a URL that a later segment then downloads, and there the
  exemption would swallow a real fetch. `tools/allowlist-candidate-scan.mjs` reports
  exactly that split: exempting `echo`/`head` flips 3 refusals and all 3 name a downloader;
  exempting `grep` flips none.

  **New residual, asserted in T48f rather than pretended:** `grep -oE '<url>' f | xargs curl`
  is now allowed, because the only segment carrying an address is the exempt grep and
  `xargs` is not an HTTP verb — so the no-URL clause does not fire either. It is narrow,
  and the block is a steering mechanism rather than a containment boundary, but it is new
  and it is written down. The neighbouring variable form
  (`U=$(grep -oE '<url>' f); curl -s "$U"`) is still refused, by the no-URL clause, which
  falls back to the string's own first verb.

  Over the corpus this changes **no** decision: whenever grep carried a remote URL, another
  verb in the same command was refused anyway. The fix is about the rule being *correct*,
  and about not issuing a denial whose stated reason is untrue.

## [0.6.1] - 2026-09-24

Two locality bugs, both of which made the 0.6.0 shell-HTTP block refuse a call it had
promised to leave alone. No configuration change; upgrading is a drop-in.

### Fixed

- **A regex-escaped URL was read as a different address.** The URL pattern stops at a
  backslash — it cannot appear in a URL — so a loopback address spelled as a grep pattern
  was truncated before parsing:

  | written | extracted | host | judged |
  |---|---|---|---|
  | `http://127.0.0.1:3080/` | full | `127.0.0.1` | local |
  | `http://127\.0\.0\.1:3080/` | `http://127` | `0.0.0.127` | **remote** |

  WHATWG reads a bare `127` as the IPv4 *number* `0.0.0.127`, which is not loopback — so a
  local address was classified as remote and refused. A regex escape before any character
  a URL can contain (`.:/?&=#%~-`) is now removed from the copy the pattern reads, so the
  address is extracted whole. Found on this plugin's own maintainer: a post-restart
  verification command that grepped for a loopback token URL was **blocked by this plugin's
  own rule**, and the shape is exactly what a verification command looks like.

- **A bracketed IPv6 literal was judged by its brackets.** `URL.hostname` keeps them, and
  the locality test compared `[::1]` against `::1` — so `curl http://[::1]:8080/` was
  refused while the refusal message told the operator that `::1` is exempt. Every IPv6 URL
  carries brackets, so the only spelling that reached the classifier was the one spelling
  that failed. The brackets are now dropped in `normUrl` (so the `host:` and `site:`
  fingerprints cannot see two spellings of one address) and again defensively in
  `isLocalHost`.

Measured over the same 28,333-call corpus, the block's cost — calls that carry a URL
without fetching anything, and are refused because a command-level rule cannot tell them
from a real fetch — falls from 52 of 4,081 refused (1.3%) to 37 of 4,056 (0.9%).

### Also in this release

`tools/allowlist-candidate-scan.mjs` answers the question these bugs keep raising: should
verb X be exempt? It reports, for each non-fetching verb, how many refused calls would
flip to allowed if that verb were exempted — and how many of those name a downloader
elsewhere in the command, which would make the exemption a bypass rather than a fix.

The answer for `grep` came back as **zero**. The 0.6.1 fix reduced the corpus's
grep-with-a-remote-URL calls from 38 to 3, and all 3 are refused for a different verb
anyway — so exempting `grep` would change no decision at all. The only verbs that flip
are `echo` (2) and `head` (1), and all three of those commands also name a real
downloader. **0.6.2 exempts `grep`/`rg` anyway** — not because the corpus demanded it, but
because the rule was wrong: see the 0.6.2 entry above. `echo` and `head` remain out, and
for them the measurement is the reason.

## [0.6.0] - 2026-09-24

**One thing to know before upgrading.** `blockShellHttp` defaults to **on**, so a shell
command that fetches a remote URL is now refused and the model is sent to `web_fetch_file`
instead. That is the point of the release, but it changes what a session can do: a
workflow that pipes `curl` into another command must become two steps, and a profile with
no `ctx.web` is unaffected (the block is fail-safe). Two deliberate exceptions keep
capabilities that would otherwise be lost: local addresses stay in the shell, and
`shellHttpAllow` (default `['git', 'docker']`) leaves verbs alone whose network use is
incidental. Add to that list from the new settings box when a real workflow needs it.

No configuration key was removed. `warnAt`, `summarizeAt`, `failWarnAt`, `failLimit`,
`limits`, `ignoreArgs` and the rest keep their names and semantics.

### Added

- **Shell HTTP is refused, and the model is sent to `web_fetch_file`.** Detection is
  SEMANTIC and destination-based, not by command name: a shell call is refused when it
  targets a non-local URL. Measured on the shapes that matter, that covers `curl`,
  `wget`, `/usr/bin/curl`, a `python3 -c` one-liner, a `node -e`, and any command
  carrying the literal destination. Enumerating downloader names would have missed the
  interpreters and been defeated by an absolute path in one step.

  It is **fail-safe**: the block engages only when `web_fetch_file` is actually
  registered. Refusing a fetch while the replacement is absent is not a redirect, it is
  a lost capability — the network, gone — so a profile with no `ctx.web` keeps shell
  HTTP. The registration is asynchronous, so early calls in a boot are allowed until the
  tool exists; that is the intended direction for this particular race.

  The refusal is flat — it fires on the FIRST fetch and never asks — and it is the
  reason the `-w` detection below could be deleted: once this class of call cannot
  happen, the failure track's input is a tool's structured `statusCode` rather than an
  inference from shell text.

  Two deliberate exceptions, both because blocking them would remove a capability
  rather than redirect one:

  - **Local addresses** (`blockLocalHttp`, default off). `web_fetch_file` reuses dsh's
    own retrieval and inherits its SSRF guard, so it CANNOT reach loopback or RFC1918.
    Refusing local fetches would leave no way to do them at all.
  - **Verbs whose network use is incidental** (`shellHttpAllow`), default `['git',
    'docker']`. That default is EVIDENCE-LED, not guessed. `tools/shell-http-allowlist-scan.mjs`
    replays the whole recorded corpus through the plugin's own detector, so the claim is
    reproducible rather than asserted. Over 225 logs / 27,539 shell calls / 4,457 calls
    carrying a remote URL, the only verbs that ever appear are `curl` (3424 segments),
    `git` (370) and `docker` (12) — plus `wget` (7), which is deliberately NOT exempt
    because it has the same fetch-to-file equivalent `curl` does. `npm`, `pip`, `uv`,
    `apt`, `go`, `cargo`, `npx`, `gh` and the rest never carried a remote URL at all, and
    their URL-less forms are not blocked anyway — only a URL/VCS-carrying form is, so
    exempting them would be speculation. Add one from the settings box when a real
    workflow needs it. Set the list to `[]` to refuse all.

    The same scan measures what the block COSTS. Of the 4,081 refused calls, 4,029 name a
    downloader or an interpreter fetch — refusing those is the feature. The other 52
    (1.3%) merely carry a URL without fetching anything, and are refused because a
    command-level rule cannot tell `curl https://…` from a heredoc rewriting a README
    full of links. That is the honest price of the rule, and it is the reason the
    per-segment attribution below reports nonsense "verbs" like `old` and `new` on those
    calls: they are Python variable names inside a `python3 - <<'PY'` script.

  The exemption is attributed PER COMMAND SEGMENT, not per string: `cd /x && git clone
  https://…` otherwise reads as `cd`, and a fetch hidden behind a prefix verb would be
  refused or exempted by accident.

- **A settings namespace, so the policy is editable without editing YAML.** The plugin
  registers its namespace through `ctx.settings.register`, so `dsh-settings` layers the
  patch config under a stored section, and the default `applies: 'live'` means a change
  takes effect on the next call. The schema's defaults are built FROM the live config, so
  the box and `lib/defaults.js` cannot drift. Registration is non-blocking, and a failure
  is recorded in `settingsState` rather than swallowed.

  A namespace alone renders NOTHING. The Plugins page shows the INTERSECTION of the
  settings namespaces a live Host plugin registered and the cards a browser bundle
  claimed under the same key, and `dsh-client-ui-settings-plugins` hard-codes its own
  four cards — so a third-party plugin must ship the other half. That half is below.

- **The browser half: a card under Settings → Plugins, hand-written in plain JS.**
  `lib/client.js` claims `settings.plugin.item` for this namespace and reproduces the
  built-in card's look from its own stylesheet, so the card is indistinguishable from a
  shipped one. All seven namespace fields render — the block policy and the four stage
  thresholds — with staged edits, per-field `Overridden`/`Reset`, and Save as the single
  point where a draft becomes a document mutation. A refused write keeps the draft and
  says so instead of dropping the edit.

  It is hand-written rather than built because the contract is small: a client bundle is
  a lazy-CJS factory behind `window.__ModuleLoader__.load`, and CSS injection is just
  part of the module body. `react` is the ONLY entry in the module table this needs —
  `slots`, `locale` and `settingsScope` all arrive by injection. So the plugin stays
  build-free: no TypeScript, no bundler, no generated artifact to keep in sync.

  Two agreements between the halves are asserted by the test suite rather than trusted,
  because neither is checked by any compiler and a drift renders NOTHING at all: the
  slot key must equal the Host's namespace (C4), and the card must edit exactly the
  fields the Host schema declares (C5). Verified end-to-end in an isolated preview — a
  save landed `repeat-tool-breaker: warnAt: 9` in `settings.yaml`, and `Reset` removed
  it again.

  The known hole is asserted rather than pretended, in T47b: a guard sees the command
  text and nothing else, so a fetch inside a file invoked by a NON-http verb
  (`bash /tmp/fetch.sh`) is invisible. Closing that needs the capability removed, not a
  better rule. The hole is narrower than it looks — an HTTP verb blocks even with no URL
  in sight, and an inline literal is visible even after a variable assignment.

- **`web_fetch_file`: fetch a URL to a FILE, returning the path instead of the body.**
  It lives in this plugin rather than beside it because the refusal above names it, and
  a message naming a tool the profile does not have is worse than no message.

  It solves two problems, both measured:

  - **Context.** `web_fetch` returns the body to the model. A reported run died on
    context size after fetching a handful of weather pages, and the pages were the
    reason. Here only `{ path, statusCode, bytes, kind, truncated }` travels back.
  - **Failure.** Shell HTTP hides its own outcome. A tool call cannot be masked the way
    a shell command can, so a 404 comes back as `statusCode: 404` — a fact.

  Over 3367 measured shell fetches, 70% piped the body into another command and 23%
  wrote it to a file. This replaces those two as two steps, which is how the pipeline
  worked anyway: `web_fetch_file(url)` then `bash: jq '.items' <path>`.

  Retrieval goes through dsh's own `ctx.web`, so it reuses the built-in provider and
  inherits the SSRF guard unchanged. It registers through `ctx.inject(['web'], …)`, so
  the breaker still loads with no web service, and is verified to appear in a real
  headless boot. The definition is plain JSON Schema rather than `defineTool`'s output,
  because a symlink-installed plugin resolves a bare specifier from its real path,
  where `@deepseek-ai/dsh-tools` is absent — that import failed SILENTLY.

### Removed

- **The `-w` write-out detection, added in 0.5.3 and generalised afterwards.** With shell
  HTTP refused, a `curl -w "%{http_code}"` can no longer run, so the whole rule — the
  format-string parsing, the tail match, the status-line marker and the `command`
  argument to `classifyFailure` — is unreachable. It is deleted rather than left in
  place: dead detection code is what produced the 0.4.0 misdiagnosis, where a
  measurement tool counted messages production could no longer deliver.

## [0.5.3] - 2026-09-22

### Fixed

- **A 404 printed by the model's own `curl -w "%{http_code}"` is now a failure.** Reported
  from a live session that ran **322 tool calls and was blocked by nothing**. The guard
  warned once (at `warnAt`, on one host) and the model then continued for another ~300
  calls; the failure track saw exactly **one** failure in the whole run.

  The shape: `curl -sL "URL" -o /dev/null -w "%{http_code}"`. curl exits **0** — a 404 is a
  successful transaction unless `--fail` was given — and the output is a bare number
  (`404 https://…`), which none of the existing markers match. 211 of that session's 322
  commands used the write-out, and 207 of their outputs led with a 4xx/5xx.

  The COMMAND is the evidence, so it is now passed to the classifier: when a shell command
  asked curl for `%{http_code}` (or `%{response_code}`), a **leading** 4xx/5xx in the output
  is the status by construction. Anchored to the start, which is where `-w` puts it — the
  same output often carries a byte count (`153226 /tmp/…`) whose digits contain something
  like `532`, and a `wc -c`-style number without the write-out request is not a status.

  Measured on the same 140 sessions: the rule takes the ≥3-failure sessions from 13 to 15
  and the ≥5 from 5 to 6, with **zero known-good runs caught**. It adds exactly two
  sessions, one of which is the reported one — whose longest failure streak goes from 1 to
  **101 consecutive 404s** on one host.

### Notes

- The occurrence track could not have caught that session, and this is structural rather
  than a threshold problem: the model rotated among four or five hosts, so with a 16-call
  window no single fingerprint stayed long enough to reach the cap of 12. Its peaks were
  8, 6, 6, 6. Rotating targets are what the failure track is for — and it needs to be able
  to see the failures, which is what this release fixes.


## [0.5.2] - 2026-09-22

### Fixed

- **No doubled space in the failure descriptions.** `suffix` carried its own leading space
  and was prefixed with another, so a Python crash read as `the script raised 
  urllib.error.URLError` and a curl failure as `curl failed (code  6)`. The same shape was
  already present in the timeout branch (`the call timed out ( 30000ms)`) and had gone
  unnoticed because that wording is rarely seen. `describeFailure` now builds each string
  explicitly, and a test checks every reason with and without a detail for doubled spaces
  and stray parenthesis spacing — the bug hid in the branches nobody read.


## [0.5.1] - 2026-09-22

### Fixed

- **The failure track was blind to the shapes a real spin produces.** Reported from a live
  run: seven calls against one host, five of them failing, and `failWarnAt: 3` never fired.
  Every one of those five had `isError: false` **and exit code 0** — `curl … | python3 … |
  head` exits with `head`'s status, and a script that catches its own `HTTP Error 400` exits
  0 as well — so the structured value said "success" and the text fallback did not recognise
  what was in the text.

  `lib/failure.js` now also recognises, in a shell result's text: `Traceback (most recent
  call last)`, a line-anchored Python exception (`SyntaxError:`, `urllib.error.URLError:`, …),
  `HTTP Error nnn`, and `curl: (n)`. On the reported run the failure streak is now 4 on
  `host:archive-api.open-meteo.com`, so the advisory fires at the third failure. Measured
  across 96 sessions, the markers raise the ≥3 sessions from 9 to 16 and the ≥5 from 5 to 6,
  with zero known-good runs caught.

### Changed

- **A status code is now definitive in both directions.** A fetch reporting `200` is a
  success and its text is never consulted, so a page that happens to contain the words
  "HTTP Error 400" or a traceback is no longer read as a failure. Previously the text
  fallback ran even after a successful status.
- **The text fallback is restricted to shell tools.** A shell's `exitCode: 0` proves
  nothing, so its text is the remaining evidence. Every other tool answers through its
  structured value; guessing from an arbitrary tool's prose is how a `read` of a Python file
  containing `ValueError:` becomes a failure.


## [0.5.0] - 2026-09-22

### Added

- **A second escalation track, on consecutive FAILURES of one fingerprint.** The
  occurrence track is unchanged (7 / 11 / 12, `host` 16). The new track exists because
  failure is a much stronger signal than repetition: repeating a call that WORKS is
  fixation, repeating one that FAILS is not learning. Its thresholds therefore sit well
  below the occurrence ones.

  | setting | default | what it does |
  | --- | --- | --- |
  | `failWarnAt` | 3 | after 3 consecutive failures of one fingerprint, deliver an advisory naming the target and the failure reason |
  | `failLimit` | 5 | after 5, a call carrying that fingerprint is blocked, subject to the existing `onLimit` policy (`ask`, fail-closed) |

- **A failure is not `result.isError`.** `isError` is true only when the CALL failed — a
  thrown error, an unknown tool, a sandbox denial — and is `false` for a non-zero exit
  code and for an HTTP 404, which are the two shapes that matter. Measured over 40
  recorded sessions, the thrown case covers 40 of 6765 bash results (0.6%); counting only
  it would have made the track blind. `lib/failure.js` reads the structured
  `result.value` each tool declares in its `output.schema` — non-zero `exitCode`,
  `statusCode >= 400`, `timedOut`, non-null `signal` — with a text-marker fallback.

### Notes

- **Only the fingerprints that hit are blocked.** A call that does not carry them —
  reading the error log, grepping the code, trying a different endpoint — is allowed.
  Blocking the recovery action is how a guard turns a stuck model into a wedged one.
- **A success clears that fingerprint's streak; a success of something else does not.**
  A read is not progress on the thing that keeps failing.
- **Both tracks share one measure set.** A fingerprint whose cap is `null` is disabled
  for both. This is load-bearing: measured over the corpus, the longest failure streaks
  sat on exactly those measures (9 on `family:http-fetch`, 8 on `verb:curl`, 7 on
  `verb:export`), so counting them would have reintroduced the 0.4.0 bug through a new
  channel.
- **The plugin never counts its own denial as a failure**, which would make the guard
  feed itself: deny a call, the streak grows, the next call is denied a step earlier.
- **The failure gate can only fire on a later call.** `ctx.tools.guard` is synchronous
  and runs before execution; the outcome is known only in `post-execute`. So after 5
  failures, the 6th call carrying that fingerprint is blocked.
- Both tracks feed the SAME gate, the same exemption prompt and the same refusal set. A
  second gate would have needed a second ask, a second refusal set and a second way to
  get stuck.
- Measured support (`tools/failure-run-measurement.mjs`, 107 sessions, enabled measures
  only): 3.6% of calls fail; 9 sessions reach a 3-failure streak, 5 reach 5, and **zero
  known-good runs reach 3**. The clearest real case was a session hitting
  `host:api.github.invalid` — a reserved, permanently nonexistent host — 8 times running.
- The compat suite gained a failure scenario, and its two occurrence scenarios now
  neutralise the exit status (`|| true`). Their commands cannot succeed, so without that
  they would have been testing the failure track instead of the one they name.


## [0.4.2] - 2026-09-22

### Changed

- **The three stages are retuned: `warnAt: 3 → 7`, `summarizeAt: 6 → 11`, and the caps
  `9 → 12` (with `host` at 16).** No behaviour changed and no setting was added or
  removed; only the numbers moved. The measurement is in `docs/issue-b-thresholds.md`.

  0.4.1's note deferred this until a wider corpus existed. That corpus is 109 recorded
  sessions with known or unknown outcomes, replayed through the plugin's own
  fingerprinting and validated against the real tool pipeline: the replay model and the
  genuine `dsh-tools` ToolRuntime agree exactly on every session and cap setting tried,
  including the two worst sessions (38/38 and 698/698 advisories and gate calls at the
  old caps; 15/15 and 246/246 at the new ones).

  What it showed:

  - **The old stages fired on runs that succeeded.** Two known-good runs peaked at 4 and
    6 repeats of one measure, and `warnAt: 3` sits below both. 10% of real sessions
    reach a peak of 13, which was above the old cap of 9.
  - **The old defaults cost a lot.** Over the 109 non-stuck sessions: 629 advisory
    messages, 49 sessions warned, 19 gated, 2296 calls blocked. The new defaults deliver
    158 messages, warn 26 and gate 10 — while still catching the known-stuck run.
  - **`host:` is deliberately looser (16) than action identity (12).** It discards the
    URL path, so installing many packages from one mirror and re-fetching one broken URL
    look identical to it; it accounted for 25 of the 48 (session, fingerprint) pairs
    that reached a cap at 9. 16 is the window itself — the whole window is one host.

### Notes

- **A stage above a cap can never be delivered.** The gate fires first, so a
  `summarizeAt` at or above every cap is dead code — which is why the stages and the caps
  move together. Nothing validates one setting against another (a `limits` entry below a
  stage remains a deliberate way to skip the advisory), but the *defaults* must not ship
  a stage that can never speak. For the same reason a threshold above the window (16) can
  never fire.
- **`tools/convergence-measurement.mjs` is superseded** by `tools/threshold-sweep.mjs`.
  The old tool tallied every fingerprint including the `null`-capped measures 0.4.1
  stopped escalating, and counted crossings rather than messages — which is how 0.4.0's
  over-trigger was first mistaken for a threshold problem.

## [0.4.1] - 2026-09-22

### Fixed

- **A measure with no cap no longer escalates.** The advisory stages were applied to
  EVERY fingerprint, ignoring `limits` — so the volume measures that ship DISABLED
  (`site:`, `family:*`, `verb:*` are all `null`) still warned, and still demanded
  summaries. One `curl` emits four of those measures at once, so a single action could
  produce up to four near-identical messages about one behaviour. Observed in
  production as `verb:cd has come up 3 times` followed by `verb:cd has now come up 6
  times`, and in a test-battery run as **5 messages in 7 tool calls** covering only 3
  distinct behaviours. The stages live BELOW the cap: a measure with no cap has no
  gate, so it must have no escalation either.
  Reported by the backend-test session in `GUARD-OVERTRIGGER-REPORT.md`.

- **The message now names the useful measure.** Identical calls cross `exact:`, `net:`,
  `site:` and `host:` at the same count, and the first in iteration order won — which
  usually meant a truncated command line (`exact:bash:{"command":"curl -s \"…`). A
  target-scoped measure is preferred: `host:` > `net:` > `site:` > `sink:` > `cmd:` >
  `exact:`.

### Notes

- **Thresholds are unchanged in this release.** The same report also argues that
  `warnAt: 3` and `summarizeAt: 6` sit low relative to a known-good run (which reached
  4–8 requests to one host). That needs the wider measurement the report itself asks
  for, and it should be judged only after the bug above is out of the way: the bug
  accounted for most of the observed message volume, because it multiplied one action
  into four measures.

## [0.4.0] - 2026-09-21

The escalation release. Repetition is no longer a wall you hit once: the same
measure now warns, then demands a summary, and only then gates — and the gate asks
the operator instead of silently blocking.

### Added

- **Two advisory stages under the cap.** Repeating one measure inside a turn now
  escalates: `warnAt` (3) says "you are repeating yourself, consider another
  route"; `summarizeAt` (6) demands a written progress summary and at least two
  approaches the model has not tried, plus an instruction to use a **larger
  per-batch amount** so there are fewer batches. Both are delivered as
  `additionalContexts` on `tools/post-execute` — the channel
  `@deepseek-ai/dsh-repeat-tool-reminder` uses — stamped `source.kind: 'plugin'`.
  A stage fires once per crossing, on exact equality, so the window sliding does
  not re-announce it.
  A stage is disabled by `0`, a negative number or `null`, silently: that is the
  documented off-switch, not a value to reject.

- **`onLimit`: what happens at the cap.** `ask` (default) offers the operator a
  turn-scoped exemption; `deny` blocks outright. `ask` is fail-closed — every
  unattended approval outcome is a denial, so a headless profile denies by itself
  and nothing stalls.

- **The `host:` measure.** `net:` keeps the query by design (that is what makes
  `?page=2` a different resource, fixed in 0.3.2), which means an agent grinding
  one API produces entirely distinct `net:` entries and nothing accumulates.
  `site:` collapses to the last two DNS labels, so `api.weather.gc.ca` and every
  other `*.gc.ca` host share one identity. The host is the level at which "the
  same target again" is both true and discriminating, and it is what makes a fixed
  strategy visible. Local hosts are excluded from it by default
  (`includeLocal: false`); `localHosts: allow` still emits no target fingerprints.

- **Per-fingerprint exemptions.** An approved exemption covers exactly the measures
  that hit, stops counting them for the rest of the turn, and says nothing about
  any other measure.

### Changed

- **The cap moves from 5 to 9** — `exact`, `cmd`, `net`, `sink` and the new
  `host`. Two escalations now sit underneath it, so the hard break moves later
  rather than staying at the first threshold.
- **`window` moves from 12 to 16.** Measured against a corpus with known outcomes
  and against the production sessions, the wider window changed no verdict: the
  failing sessions reached a host count of 18 either way, and the one successful
  session that grinds stayed at 5. It admits three more sessions at the gate stage
  in production. Adopted for margin, not because 12 was shown to miss.

### Removed

- **`localHosts: ask`.** Asking is no longer a local-only concern — it is what
  `onLimit` does for every measure — so `localHosts` keeps only `deny` and
  `allow`. A config still carrying `localHosts: ask` fails loud at load with the
  migration (`use `onLimit: ask``), the same way 0.2.0 handled a removed key.

### Fixed

- **The 0.3.2 changelog was wrong about `site:`.** It claimed "`site:` no longer
  merges unrelated services"; `siteOf` has not changed since v2 and still collapses
  to two labels. 0.3.2 turned the `site:` *cap* off — it never fixed the merge. The
  host measure is the fix.

### Notes

- **No setting is validated against another.** A `limits` entry below a stage means
  "no escalation for this measure", and inverted stages simply fire in the other
  order. Both are ways to express intent, and second-guessing them would be worse
  than accepting them.
- **Pagination is handled by the escalation, not by an exemption.** 0.3.2 made
  pagination stop colliding on `net:`; eight distinct pages of one host now reach
  `host: 8`, so the ninth request to that host is the cap-th. That is intended, not
  a leftover: stage 2 at 6 is where a model processing in batches is told to use a
  larger per-batch amount, and one that takes the advice finishes well under the gate
  at 9. The advice is deliberately backend-agnostic — the same shape appears when an
  agent reads a file line by line — and a test pins that it never names HTTP paging.
  `T14c` asserts the shape.

## [0.3.3] - 2026-09-15

### Changed

- **The action-identity caps are 5, not 3** — `exact`, `cmd`, `net` and `sink`.
  3 fixed the retry case that 2 broke, but it still tripped on *dense legitimate
  work*. The clearest instance was `sink:`: it is path-only **by design** — its
  whole job is to catch one destination being rewritten with ever-changing
  content — so a shell cycle that writes the same file several times while
  iterating is indistinguishable from a loop at 3. On the reference deployment a
  session building and re-running scaffolding was denied on its third write to the
  same path with three *different* payloads.

  Raising the cap is the right lever here rather than making `sink:`
  content-sensitive: a content hash would make it fire only on a byte-identical
  rewrite, which `exact:` already catches, and would therefore remove the one
  thing `sink:` exists to do. At 5 an ordinary edit/test cycle fits, and a real
  loop is still stopped — it reaches the cap because it never changes what it is
  doing.

  Net effect: two extra attempts per action before the hard break. The suite is
  expressed in terms of the cap (`const CAP = cfg.limits.exact`); six tests that
  had hard-coded the 3-call shape now derive it from `CAP` instead.

### Notes

- The gate is unchanged in kind and still **fail-closed**: an action repeated five
  times inside a 12-call window is denied exactly as before, and every unattended
  `localHosts: ask` outcome is still a denial.

## [0.3.2] - 2026-09-15

### Fixed

- **Pagination is no longer mistaken for repetition.** `net:` discarded the query
  string, so `...commits?per_page=100` and `...commits?per_page=100&page=2` were
  the same resource. The query is now part of the fingerprint — sorted, with
  tracking parameters (`utm_*`, `fbclid`, `gclid`, …) removed, so a page number
  distinguishes one page of results from the next while a cosmetic parameter still
  cannot launder a repeat.
- **`site:` no longer merges unrelated services.** `siteOf()` collapses a host to
  its last two labels, so `api.github.com` and `github.com` shared one budget; a
  session paginating a GitHub commit list tripped `site:github.com 6/3`.

### Changed

- **The volume budgets are off by default**: `site`, `family:http-fetch`,
  `verb:curl`, `verb:wget` are now `null`. A budget on how much one site or one
  verb may be used cannot tell a crawl from a session making progress, and every
  value tried produced a false positive on a real session — four different URLs
  blocked by `family:http-fetch: 4`, a development loop blocked by
  `site:127.0.0.1`, and the commit crawl above. The worst part was the shape of
  the failure: the agent's own comment in that session read
  `# Fetch page 2 of openvino commits using a script file to avoid repeat
  detection` — an agent working *around* the breaker instead of changing
  approach is the opposite of the intent.

  Repetition is what this plugin detects, and `exact`, `cmd`, `net` and `sink`
  still do it. Anyone who wants a crawl budget can set one back:
  `limits: { site: 30, 'family:http-fetch': 60 }`.

### Notes

- The local-address policy is unaffected in principle but changes shape in
  practice: with `site:` gone, a local loop only accumulates when it hits the
  SAME host+path, which is exactly what `localHosts` relaxes.

## [0.3.1] - 2026-09-15

### Changed

- **`localHosts` now defaults to `ask`**, so installing the plugin is enough: no
  profile needs a hand-written patch to get the prompt. This is safe because
  `ask` is **fail-closed** — every unattended outcome of an approval is a denial
  (`rejected` when the session policy is `never`, `cancelled` when the turn is
  aborted, and `unavailable`, the value the registry falls back to when no
  answerer is registered) — so a headless profile degrades to `deny` by itself
  instead of stalling.

  The one visible difference in an unattended profile: the model's *first* blocked
  local call of a turn receives the registry's "requires approval, but no approval
  channel is available" instead of `REPEAT_TOOL_BLOCKED`. From the second one on —
  the refusal is remembered for the turn — the breaker's own message applies
  again. Set `localHosts: deny` to avoid even that.

### Fixed

- The refusal note no longer claims the operator declined: with no approval
  channel the request was never shown to anyone, so it now says the exemption was
  not granted "either because the request was declined, or because no approval
  channel was available to answer it".

## [0.3.0] - 2026-09-15

### Added

- **`localHosts`: `deny` | `ask` | `allow`** — local addresses (`localhost`,
  loopback, RFC1918, link-local) are now their own class instead of being counted
  as an ordinary web site. The `site:` budget was blocking ordinary development
  loops: on the reference deployment a handful of calls that merely *mentioned* a
  loopback URL tripped `site:127.0.0.1` while nothing was being crawled.

  - `deny` (default) keeps today's behaviour and names the knob in the message.
  - `ask` offers the operator a prompt, **once per turn**; approving exempts local
    targets for the rest of that turn, declining stops the asking until the next
    human message. It belongs in a profile with a UI — a headless profile should
    keep `deny`, where an open question would stall the turn. Hence: configure it
    per profile.
  - `allow` never fingerprints local traffic.

- `fingerprints()` now reports whether a call is **local** (it mentions at least
  one URL and every URL it mentions is local), which is what the policy acts on.

### Notes

- Only the target-scoped fingerprints (`net`, `site`, `sink`, `family`, `verb`)
  are ever relaxed: `exact` and `cmd` identify the ACTION, and a byte-identical
  repeat is a loop whether or not it points at localhost. A call mentioning even
  one public URL is not a local call.
- An ask is only made when local traffic is the *sole* reason for the block, so a
  genuine repeat is a straight denial rather than a prompt.
- `ask` had to be split across two hooks: `tools/pre-execute` can ask but cannot
  deny, and `ctx.tools.guard` can deny but cannot ask. The pipeline hands a
  rejected ask straight to `post-execute` and never runs the guard, so "the guard
  saw this execution" is exactly the approval signal.

## [0.2.4] - 2026-09-15

### Removed

- The `pathAliases` config key, and the `firstPathArg` helper it fed. Both became
  dead in 0.2.2, when the path-only `readpath`/`writepath` fingerprints were
  removed — the key has had no reader since, so the README was documenting a knob
  that did nothing. A config that still lists `pathAliases` is accepted and
  ignored, so no consumer has to change anything.

### Fixed

- The bundle patch's header comment still advertised the **original** v2 cap table
  (`exact`/`cmd`/`net`/`sink` 2, `family`/`verb` 4, plus `readpath`/`writepath`),
  three releases after those values changed. It now states the shipped table.

### Added

- `test/compat/` — a full-boot compatibility harness (scripted mock model + a
  real `dsh` of the version under test). Repository tooling only; `test/` is not
  published, so there is no npm release for it.

## [0.2.3] - 2026-09-15

### Changed

- **The action-identity caps are 3, not 2** — `exact`, `cmd`, `net` and `sink`.
  A cap of 2 has no room for the most common *non-loop* repeat: the first attempt
  fails for a reason unrelated to looping (a precondition the harness enforces, a
  DNS failure) and the correct response is to retry the same call. At 2 that
  retry is precisely what gets blocked, so the only way forward is to change the
  call cosmetically — the behaviour this plugin exists to stop.

  The alternative considered was refunding the budget of a guard-allowed call
  whose body failed. It was rejected: it makes the guard depend on how a failure
  is reported, and a call that fails *every* time would refund itself forever and
  never be blocked. Raising the cap is stateless, depends on nothing, and still
  stops a failing loop on the third attempt.

  Net effect: one extra attempt per action before the hard break. `T2b` pins the
  retry case; the rest of the suite now expresses its expectations in terms of the
  cap (`const CAP = cfg.limits.exact`) instead of hard-coding 2.

## [0.2.2] - 2026-09-15

### Changed

- **File operations are no longer counted by path.** `read`/`write`/`edit` are
  identified by **position** through `exact:` — the same file at the same offset,
  or the same replacement string, is the same action and is denied; a different
  offset or a different region is a different action and is never blocked. The
  `readpath` and `writepath` limits and their fingerprints were removed.

  Both were introduced in 0.2.0 to give a per-file budget, and both had to go
  after live use: `writepath: 3` denied the third consecutive edit of a single
  document (0.2.1 disabled it), and `readpath: 2` denied the *second read of a
  file that was being edited* — a step dsh's own fs-observation policy requires
  before every edit, so the plugin was blocking the workflow it exists to protect.

  Nothing is lost: an identical re-read or re-edit still collides on `exact:`.

### Removed

- Limits `readpath` and `writepath`, and the `readpath:`/`writepath:`
  fingerprints. A config that still lists them is accepted but inert.

## [0.2.1] - 2026-09-15

### Fixed

- **`writepath` is disabled by default** — `null` instead of `3`. Editing one file
  repeatedly is ordinary work, not a loop: the reference deployment hit the cap of
  3 on the **third consecutive edit of a single document** within minutes of
  installing 0.2.0, while writing a SKILL.md. The loop the cap was meant to catch
  — rewriting a file with the same content — is already covered by `exact`
  (cap 2). Set `limits.writepath` to a number to restore a per-file write budget.

### Notes

- Not a breaking change: `null` was already a valid value for a limit, so this
  only moves a default. Nothing in the configuration schema or public API changed.

## [0.2.0] - 2026-09-13

The semantic-rewrite release. v1 counted *byte-identical consecutive* calls, so a
model could stay in a loop simply by varying a presentation field or the host
spelling; v2 strips decoys first and then counts semantic fingerprints over a
sliding window.

### Fixed

- **`description: '1st'/'2nd'/'3rd'` (plus a churning `timeoutMs`) no longer
  launders a repeat.** Decoy arguments are deleted *before* any fingerprint string
  is built, so those calls become byte-identical and collide on `exact:`. The
  suite asserts that no fingerprint of such a call contains the decoy text or the
  timeout value.
- **Host ping-pong is now caught.** `curl --max-time 60 open-data.canada.ca` ↔
  `curl --max-time 30 open.canada.ca` previously alternated forever: the calls
  were not consecutive-equal and the command was never normalized. `net:` folds
  host aliases and strips the query, and `cmd:` strips volatile flags, so both
  spellings collide — as does the same fetch re-issued through `wget`.
- **A denied call no longer risks a free retry.** The guard commits a call on the
  deny path too, so hammering a blocked call cannot reset its own budget.

### Changed — breaking

- Counting moved from a **consecutive-run counter** to a **per-agent sliding
  window** (`window`, default 12 calls) over a *set* of fingerprints per call:
  `exact:`, `cmd:`, `net:`, `site:`, `sink:`, `readpath:`, `writepath:`,
  (the last two were removed again in 0.2.2 — see below)
  `family:http-fetch`, `verb:<cmd>`.
- Configuration is now `{ window, previewChars, resultPreviewChars, exclude,
  include, ignoreArgs, pathAliases, hostAliases, limits }`. The v1 keys
  `denyAfter`, `warnAfter`, `registerAdvisory`, `maxSamePath`, `readTools` and
  `matchReadBySubstring` are **removed**: passing one now throws at load with a
  pointer at its replacement instead of being silently ignored.
- The advisory tier (`warnAfter` / `registerAdvisory` / `additionalContexts`) was
  removed. The guard denies; there is no separate soft-notice path. The official
  `@deepseek-ai/dsh-repeat-tool-reminder` remains the soft tier.
- `limits`, `ignoreArgs` and `hostAliases` merge one level deep over the defaults;
  `exclude`, `include` and `pathAliases` **replace** the default arrays.
- The package is now `index.js` + `lib/` (`defaults`, `normalize`, `fingerprints`,
  `window`, `message`); the test entry point is
  `node --test test/breaker.test.js` (the old `test/logic.test.mjs` was
  superseded).

### Added

- A per-fingerprint **hit list** in the denial message, so the model is told
  exactly which identities collided and how many times, that cosmetic variation
  is not a new action, and what the previous result was.

### Deliberate deviations from the v2 specification

Four, each a consequence of running the plugin against a live model on the
reference deployment (Qwen3.8-27B via the `dsh-container` harness). All are
reversible from config alone.

- File reads and writes get separate counters (`readpath`, `writepath`) instead of
  sharing one `sink:`. The spec's single counter would deny the second half of the
  ordinary `read foo.ts` → `write foo.ts` pair, which is an edit, not a loop.
- `file_path` was added to `pathAliases`; the spec's list omitted the key dsh's own
  `read`/`write`/`edit` tools actually use, which would have left every file read
  ungated.
- **Generic sinks are not fingerprints.** A live run of "get the status code of
  these four URLs" fetched `https://example.com/` and then had every following
  call denied, because all four used `curl -s -o /dev/null` and therefore shared
  `sink:/dev/null`. `/dev/null` (and the other null devices, and `-`) say nothing
  about which resource was fetched.
- **The volume caps ship at 6, not 4**, and **a denied call commits only the
  fingerprints that hit.** The first was changed because the same four-URL run
  also tripped `family:http-fetch: 4` and `verb:curl: 4`; the second because a
  denied `curl https://example.org` was charging `net:example.org/` for a fetch
  that never happened, after which the model could not reach that URL through any
  tool for the rest of the turn. Hammering a denied call stays blocked either way,
  since the hitting fingerprint is already at its cap.

## [0.1.3] - 2026-09-12

### Fixed

- **The package now declares `dsh.bundle`, so the shipped `cordis.patch.yml` is
  actually reachable.** The file was already in `files`, but with no
  `"dsh": { "bundle": { "patch": "./cordis.patch.yml" } }` manifest, listing
  `dsh-repeat-tool-breaker` in a profile's `dsh.profile.bundles` failed the boot
  with `dsh: profile bundle "dsh-repeat-tool-breaker" declares no dsh.bundle in
  its package.json` — an unhandled throw from `loadProfile`, not a soft warning.
  The bundled patch was dead weight: unreachable through the bundle path and
  usable only as a copy-paste `--patch` overlay.

### Changed

- `cordis.patch.yml` is now a real bundle layer: it mounts the plugin row by its
  **package specifier** (`name: 'dsh-repeat-tool-breaker'`) instead of the
  `/ABS/PATH/index.js` placeholder, and it carries **no `config:`** — so the
  plugin's own fail-loud `DEFAULTS` apply and a profile that wants different
  values restates them in its own patch layer. The previous `warnAfter: 1` in the
  snippet was inert anyway (the advisory needs `2 <= warnAfter < denyAfter`), so
  behaviour for anyone who copy-pasted it is unchanged.
- `cordis.patch.yml` comments document both install paths (list as a bundle vs.
  mount by hand / `--patch`), including the fact that a patch *replaces* a row's
  whole `config` rather than merging, and that an absolute path is still the way
  to mount a checkout that is not installed into the profile.
- README: bundle-install path documented alongside the manual mount row.

## [0.1.2] - 2026-09-11

### Changed

- Publishing runs through the `Publish to npm` GitHub Actions workflow using
  **npm Trusted Publishing (OIDC)** — no long-lived npm token is required. The
  workflow upgrades the npm CLI first, because Trusted Publishing needs npm
  >= 11.5.1 while Node 22 bundles an older one. A repository `NPM_TOKEN` secret is
  still honoured as a fallback when trusted publishing is not configured.
- README: npm badge, install instructions for the published package, and the
  corrected advisory-tier documentation.

## [0.1.1] - 2026-09-11

### Fixed

- **The advisory no longer fires on ordinary calls.** The `warnAfter` notice was
  keyed only on `count === warnAfter`, and because every fresh tool call starts a
  new run at count 1, the default `warnAfter: 1` attached a misleading "you just
  ran X with identical arguments 1 time(s)" message to *every* tool call —
  polluting context for no reason. The advisory is now inert unless
  `2 <= warnAfter < denyAfter` (a repeat must have happened, and the block must
  not have happened yet), default `warnAfter` is raised from 1 to 2, and the
  wording now describes a real repeat ("N times in a row").
- Caller-provided config arrays (`exclude`, `include`, `readTools`, `pathAliases`)
  are copied before being frozen, so the plugin no longer freezes an array the
  caller still owns.
- Removed a dead `denyAfter` overflow check that `Number.isInteger` already made
  unreachable.

### Changed

- `tools/post-execute` computes the call signature once instead of twice.
- Test suite grown from 20 to 29 assertions (advisory reachability, no-advisory
  regressions, fail-loud config, caller-array ownership).

## [0.1.0] - 2026-09-11

### Added

- Initial release: a dependency-free DSH plugin that hard-blocks identical repeated
  tool calls through the synchronous monotonic `ctx.tools.guard` gate.
- Denies the **2nd** identical (tool name + canonical arguments, property order
  ignored) call per agent by default; the denied call never executes and the model
  receives a `REPEAT_TOOL_BLOCKED` result quoting the previous successful result.
- Same-path read cap (`maxSamePath`) bounding read-like tools called repeatedly on
  one file with *varying* arguments.
- Per-agent `WeakMap` state; user-message chain reset via `agent/pre-step`;
  transparent tool exclusion (default `todo_write`).
- Advisory `warnAfter` notice delivered through `tools/post-execute` — never a
  deny, and it never increments the chain.
- Deterministic guard-logic acceptance suite (`test/logic.test.mjs`) and GitHub
  Actions CI on Node 20 and 22.

[Unreleased]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.10.0...HEAD
[0.10.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.9.0...v0.10.0
[0.9.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.7...v0.9.0
[0.8.7]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.6...v0.8.7
[0.8.6]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.5...v0.8.6
[0.8.5]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.4...v0.8.5
[0.8.4]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.3...v0.8.4
[0.8.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.2...v0.8.3
[0.8.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.1...v0.8.2
[0.8.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.0...v0.8.1
[0.8.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.6.2...v0.7.0
[0.6.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.6.1...v0.6.2
[0.6.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.3...v0.6.0
[0.5.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.4.2...v0.5.0
[0.4.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.3...v0.4.0
[0.3.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.2...v0.3.3
[0.3.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.4...v0.3.0
[0.2.4]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.3...v0.2.4
[0.2.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.3...v0.2.0
[0.1.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/snailium/dsh-repeat-tool-breaker/releases/tag/v0.1.0
