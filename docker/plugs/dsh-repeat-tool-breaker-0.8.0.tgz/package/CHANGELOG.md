# Changelog

All notable changes to this project are documented here. This project adheres to
[Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.8.0] - 2026-09-25

**BREAKING: this release targets dsh 0.1.7 (session format 4) only.** 0.1.7 removed the
imperative settings API and changed the message-source shape, and the two source shapes are
**mutually exclusive** — one of them throws on each host — so the generations are served by
two lines: **0.8.x for dsh >= 0.1.7**, **0.7.x for dsh 0.1.5**. No configuration key changed;
`shellHttpBlock` and the rest keep their names and semantics.

### Changed — the settings page, rebuilt for 0.1.7

- **The exported `Config` IS the settings schema now, and it must ride the DEFAULT EXPORT.**
  0.1.7 deleted `ctx.settings.register`: `SettingsForms.schema(entry)` reads
  `entry.fiber.runtime.Config`, and the namespace is the **loader entry id**. The loader
  normalizes a module's exports to ONE object (`unwrapExports`: `exports.default ?? exports`)
  and cordis copies the schema off that object, caching the runtime per callback — so a module
  whose default export omitted `Config` ran perfectly while its settings page never appeared.
  Measured: `runtimeKeys=["name","callback","fibers","Config"] runtimeHasConfig=false` against
  `localConfigHasToJSON=true`.
- **Every settings field is `.volatile()`.** `volatileForm()` keeps only volatile fields and
  `describe()` drops an entry whose form is empty, so a schema without them has no form at all.
  The fields are delivered as **live handles** and are read with `.get()`; the config is
  refreshed in place before every hook, so an edit takes effect without a remount. A documented
  `null` off-switch needs `z.union([z.number(), z.const(null)])`, and an **unset** volatile
  union resolves to `undefined` rather than `null`, which is normalized so the off-switch
  behaves the same whether it was set or defaulted.
- **The card is built from the platform's own components.** It registers into the 0.1.7 slot
  **`plugins.item`** (`{ name, id, order, label, locale, inject }`) behind
  `ctx.configForms.whileServed([entryId])`, injects `['slots', 'locale', 'configForms']`, and
  renders `SettingsForm` + `SettingsValueField` from `@deepseek-ai/dsh-client-ui-primitives`.
  It previously rendered its own card frame, which in 0.1.7 doubled the chrome, mis-styled it,
  and put a header button over the platform's that swallowed clicks.
- **`view === 'summary'` is implemented.** The page renders a card's summary as the row's
  description; without it the list falls back to this package's npm description.
- `@deepseek-ai/schemastery` is now `^3.18.4` — `.volatile()` does not exist in 3.18.2 — and
  `dsh.client.inject` names the 0.1.7 packages (`-client-locale`, `-ui-settings`,
  `-ui-plugin-manager`).
- **The message `source.kind` is `plugin:dsh-repeat-tool-breaker`.** Session format 4 rejects
  the retired `{ kind: 'plugin' }` wrapper that format 3 *requires*.

### Changed — the compatibility harness

- **It reads both session-format payload shapes.** Format 4 flattened `tool/result` (the
  message IS the result) where format 3 nested it (`content[] -> type: 'tool-result'`); the
  old parser silently found ZERO results on 0.1.7 and reported it as "the run hung or died".
- The mock model's log is kept at a stable path instead of a `mktemp -d` that is gone by the
  time anyone asks why a scenario failed, and a result-count mismatch now **names the cause**
  (provider failures recorded in the session vs. a run that died early) instead of guessing.

### Added

- **T54**, the failure gate's pivot contract, measured with `web_fetch_file` and 404 results:
  after five consecutive failures the failing endpoint and another path on the **same host**
  stay blocked, while a different website, a different subdomain of the same registrable
  domain, and unrelated tools are all allowed — and a `200` clears the streak. It also
  records that `site:` does not participate in the failure track, which is what lets a
  subdomain through.

### Notes

- **Card artwork is not available to a third-party plugin.** The Plugins page looks the icon
  up in a map hard-coded in the official plugin-manager bundle, and the `plugins.item` slot
  schema has no icon option, so this card shows the platform's default artwork. Written down
  here so it is not mistaken for a defect.
- `socat` remains deliberately absent from `shellHttpBlock`: the coverage scan's only misses
  are `socat -V`, `socat -h` and a local relay, none of which fetch anything.

## [0.7.0] - 2026-09-24

**BREAKING: the block is a BLACKLIST, and the setting is the list itself.** `shellHttpAllow`
is gone; `shellHttpBlock` replaces it and holds the COMMANDS TO REFUSE. A profile still
carrying the old key fails the load with a pointer at the new one rather than silently
losing its configuration.

**Why.** The old rule fired on any non-local URL, so a command was refused for merely
CONTAINING an address — a grep pattern, a heredoc writing a README, a commit message quoting
a link — and the refusal then asserted that the call "fetches over HTTP", which was false,
and pointed at `web_fetch_file`, which cannot help with a grep. Measured over the corpus,
the worst of that has been the most-complained-about behaviour in production.

**How it works now.** `unwrapCommands()` traverses every place the command line can run
something — split on the separators, then open the shells: command substitution, a shell
host (`sh -c`, `ssh`, `xargs`, `sudo`, `timeout`, …), `find -exec`, and a quoted
sub-command — and each candidate is judged on ITS OWN verb. A verb on the blacklist, or an
interpreter program naming a request API (`urllib`, `requests.`, `fetch(`, …), makes the
call refuse. Coverage is deliberately extensible: another shell to open is another entry in
`SHELL_HOSTS`, another command to filter is another list entry, and neither requires the
rule to model where a mechanism appears.

**Measured** with `tools/block-coverage.mjs` over 28,471 shell calls:

| | |
|---|---|
| calls that really fetch | 4042 |
| refused | 4022 |
| **coverage** | **99.5%** |
| **refused that fetch nothing** | **0** |

The 20 misses are `socat` invocations — `socat -V`, `socat -h`, and a local TLS relay —
none of which fetch anything, so they are evidence of nothing rather than a gap. `socat` is
therefore NOT on the blacklist.

### Fixed

- **A URL whose port is a shell variable no longer loses its locality.**
  `http://127.0.0.1:$PORT/health` made `new URL` throw, and a throw read as "there is no
  address at all" — so a LOCAL endpoint written that way was classified as remote and
  refused. It is an ordinary way to write a health check, and it dominated the
  false-positive set (316 corpus calls) rather than being a curiosity. A non-numeric port is
  now dropped before parsing: it is part of no fingerprint. The port separator is found
  after an IPv6 literal's closing bracket, so `[fe80::1]` is not truncated to `[fe80:`.

## [0.6.2] - 2026-09-24

### Fixed

- **`grep` is no longer refused when its PATTERN contains a URL.** `shellHttpAllow` gains
  `grep` and `rg`. A grep command containing an address is searching text *for* that
  address — grep has no network stack, so no amount of it can fetch anything. Refusing it
  did not redirect a fetch; it blocked a read. Worse, the refusal message then asserted
  that the call "fetches over HTTP", which is simply false, and told the model to use
  `web_fetch_file` for an operation that tool cannot perform. A guard that lies about why
  it fired is worse than one that is narrow.

  The line is **pattern-position tools**, not "any verb without a network stack": `echo`,
  `head`, `cat`, `sed` and `awk` stay out, because the corpus contains commands where one
  of those merely PRINTS a URL that a later segment then downloads, and there the
  exemption would swallow a real fetch. `tools/allowlist-candidate-scan.mjs` reports
  exactly that split: exempting `echo`/`head` flips 3 refusals and all 3 name a downloader;
  exempting `grep` flips none.

  **New residual, asserted in T48f rather than pretended:** `grep -oE '<url>' f | xargs curl`
  is now allowed, because the only segment carrying an address is the exempt grep and
  `xargs` is not an HTTP verb — so the no-URL clause does not fire either. It is narrow,
  and the block is a steering mechanism rather than a containment boundary, but it is new
  and it is written down. The neighbouring variable form
  (`U=$(grep -oE '<url>' f); curl -s "$U"`) is still refused, by the no-URL clause, which
  falls back to the string's own first verb.

  Over the corpus this changes **no** decision: whenever grep carried a remote URL, another
  verb in the same command was refused anyway. The fix is about the rule being *correct*,
  and about not issuing a denial whose stated reason is untrue.

## [0.6.1] - 2026-09-24

Two locality bugs, both of which made the 0.6.0 shell-HTTP block refuse a call it had
promised to leave alone. No configuration change; upgrading is a drop-in.

### Fixed

- **A regex-escaped URL was read as a different address.** The URL pattern stops at a
  backslash — it cannot appear in a URL — so a loopback address spelled as a grep pattern
  was truncated before parsing:

  | written | extracted | host | judged |
  |---|---|---|---|
  | `http://127.0.0.1:3080/` | full | `127.0.0.1` | local |
  | `http://127\.0\.0\.1:3080/` | `http://127` | `0.0.0.127` | **remote** |

  WHATWG reads a bare `127` as the IPv4 *number* `0.0.0.127`, which is not loopback — so a
  local address was classified as remote and refused. A regex escape before any character
  a URL can contain (`.:/?&=#%~-`) is now removed from the copy the pattern reads, so the
  address is extracted whole. Found on this plugin's own maintainer: a post-restart
  verification command that grepped for a loopback token URL was **blocked by this plugin's
  own rule**, and the shape is exactly what a verification command looks like.

- **A bracketed IPv6 literal was judged by its brackets.** `URL.hostname` keeps them, and
  the locality test compared `[::1]` against `::1` — so `curl http://[::1]:8080/` was
  refused while the refusal message told the operator that `::1` is exempt. Every IPv6 URL
  carries brackets, so the only spelling that reached the classifier was the one spelling
  that failed. The brackets are now dropped in `normUrl` (so the `host:` and `site:`
  fingerprints cannot see two spellings of one address) and again defensively in
  `isLocalHost`.

Measured over the same 28,333-call corpus, the block's cost — calls that carry a URL
without fetching anything, and are refused because a command-level rule cannot tell them
from a real fetch — falls from 52 of 4,081 refused (1.3%) to 37 of 4,056 (0.9%).

### Also in this release

`tools/allowlist-candidate-scan.mjs` answers the question these bugs keep raising: should
verb X be exempt? It reports, for each non-fetching verb, how many refused calls would
flip to allowed if that verb were exempted — and how many of those name a downloader
elsewhere in the command, which would make the exemption a bypass rather than a fix.

The answer for `grep` came back as **zero**. The 0.6.1 fix reduced the corpus's
grep-with-a-remote-URL calls from 38 to 3, and all 3 are refused for a different verb
anyway — so exempting `grep` would change no decision at all. The only verbs that flip
are `echo` (2) and `head` (1), and all three of those commands also name a real
downloader. **0.6.2 exempts `grep`/`rg` anyway** — not because the corpus demanded it, but
because the rule was wrong: see the 0.6.2 entry above. `echo` and `head` remain out, and
for them the measurement is the reason.

## [0.6.0] - 2026-09-24

**One thing to know before upgrading.** `blockShellHttp` defaults to **on**, so a shell
command that fetches a remote URL is now refused and the model is sent to `web_fetch_file`
instead. That is the point of the release, but it changes what a session can do: a
workflow that pipes `curl` into another command must become two steps, and a profile with
no `ctx.web` is unaffected (the block is fail-safe). Two deliberate exceptions keep
capabilities that would otherwise be lost: local addresses stay in the shell, and
`shellHttpAllow` (default `['git', 'docker']`) leaves verbs alone whose network use is
incidental. Add to that list from the new settings box when a real workflow needs it.

No configuration key was removed. `warnAt`, `summarizeAt`, `failWarnAt`, `failLimit`,
`limits`, `ignoreArgs` and the rest keep their names and semantics.

### Added

- **Shell HTTP is refused, and the model is sent to `web_fetch_file`.** Detection is
  SEMANTIC and destination-based, not by command name: a shell call is refused when it
  targets a non-local URL. Measured on the shapes that matter, that covers `curl`,
  `wget`, `/usr/bin/curl`, a `python3 -c` one-liner, a `node -e`, and any command
  carrying the literal destination. Enumerating downloader names would have missed the
  interpreters and been defeated by an absolute path in one step.

  It is **fail-safe**: the block engages only when `web_fetch_file` is actually
  registered. Refusing a fetch while the replacement is absent is not a redirect, it is
  a lost capability — the network, gone — so a profile with no `ctx.web` keeps shell
  HTTP. The registration is asynchronous, so early calls in a boot are allowed until the
  tool exists; that is the intended direction for this particular race.

  The refusal is flat — it fires on the FIRST fetch and never asks — and it is the
  reason the `-w` detection below could be deleted: once this class of call cannot
  happen, the failure track's input is a tool's structured `statusCode` rather than an
  inference from shell text.

  Two deliberate exceptions, both because blocking them would remove a capability
  rather than redirect one:

  - **Local addresses** (`blockLocalHttp`, default off). `web_fetch_file` reuses dsh's
    own retrieval and inherits its SSRF guard, so it CANNOT reach loopback or RFC1918.
    Refusing local fetches would leave no way to do them at all.
  - **Verbs whose network use is incidental** (`shellHttpAllow`), default `['git',
    'docker']`. That default is EVIDENCE-LED, not guessed. `tools/shell-http-allowlist-scan.mjs`
    replays the whole recorded corpus through the plugin's own detector, so the claim is
    reproducible rather than asserted. Over 225 logs / 27,539 shell calls / 4,457 calls
    carrying a remote URL, the only verbs that ever appear are `curl` (3424 segments),
    `git` (370) and `docker` (12) — plus `wget` (7), which is deliberately NOT exempt
    because it has the same fetch-to-file equivalent `curl` does. `npm`, `pip`, `uv`,
    `apt`, `go`, `cargo`, `npx`, `gh` and the rest never carried a remote URL at all, and
    their URL-less forms are not blocked anyway — only a URL/VCS-carrying form is, so
    exempting them would be speculation. Add one from the settings box when a real
    workflow needs it. Set the list to `[]` to refuse all.

    The same scan measures what the block COSTS. Of the 4,081 refused calls, 4,029 name a
    downloader or an interpreter fetch — refusing those is the feature. The other 52
    (1.3%) merely carry a URL without fetching anything, and are refused because a
    command-level rule cannot tell `curl https://…` from a heredoc rewriting a README
    full of links. That is the honest price of the rule, and it is the reason the
    per-segment attribution below reports nonsense "verbs" like `old` and `new` on those
    calls: they are Python variable names inside a `python3 - <<'PY'` script.

  The exemption is attributed PER COMMAND SEGMENT, not per string: `cd /x && git clone
  https://…` otherwise reads as `cd`, and a fetch hidden behind a prefix verb would be
  refused or exempted by accident.

- **A settings namespace, so the policy is editable without editing YAML.** The plugin
  registers its namespace through `ctx.settings.register`, so `dsh-settings` layers the
  patch config under a stored section, and the default `applies: 'live'` means a change
  takes effect on the next call. The schema's defaults are built FROM the live config, so
  the box and `lib/defaults.js` cannot drift. Registration is non-blocking, and a failure
  is recorded in `settingsState` rather than swallowed.

  A namespace alone renders NOTHING. The Plugins page shows the INTERSECTION of the
  settings namespaces a live Host plugin registered and the cards a browser bundle
  claimed under the same key, and `dsh-client-ui-settings-plugins` hard-codes its own
  four cards — so a third-party plugin must ship the other half. That half is below.

- **The browser half: a card under Settings → Plugins, hand-written in plain JS.**
  `lib/client.js` claims `settings.plugin.item` for this namespace and reproduces the
  built-in card's look from its own stylesheet, so the card is indistinguishable from a
  shipped one. All seven namespace fields render — the block policy and the four stage
  thresholds — with staged edits, per-field `Overridden`/`Reset`, and Save as the single
  point where a draft becomes a document mutation. A refused write keeps the draft and
  says so instead of dropping the edit.

  It is hand-written rather than built because the contract is small: a client bundle is
  a lazy-CJS factory behind `window.__ModuleLoader__.load`, and CSS injection is just
  part of the module body. `react` is the ONLY entry in the module table this needs —
  `slots`, `locale` and `settingsScope` all arrive by injection. So the plugin stays
  build-free: no TypeScript, no bundler, no generated artifact to keep in sync.

  Two agreements between the halves are asserted by the test suite rather than trusted,
  because neither is checked by any compiler and a drift renders NOTHING at all: the
  slot key must equal the Host's namespace (C4), and the card must edit exactly the
  fields the Host schema declares (C5). Verified end-to-end in an isolated preview — a
  save landed `repeat-tool-breaker: warnAt: 9` in `settings.yaml`, and `Reset` removed
  it again.

  The known hole is asserted rather than pretended, in T47b: a guard sees the command
  text and nothing else, so a fetch inside a file invoked by a NON-http verb
  (`bash /tmp/fetch.sh`) is invisible. Closing that needs the capability removed, not a
  better rule. The hole is narrower than it looks — an HTTP verb blocks even with no URL
  in sight, and an inline literal is visible even after a variable assignment.

- **`web_fetch_file`: fetch a URL to a FILE, returning the path instead of the body.**
  It lives in this plugin rather than beside it because the refusal above names it, and
  a message naming a tool the profile does not have is worse than no message.

  It solves two problems, both measured:

  - **Context.** `web_fetch` returns the body to the model. A reported run died on
    context size after fetching a handful of weather pages, and the pages were the
    reason. Here only `{ path, statusCode, bytes, kind, truncated }` travels back.
  - **Failure.** Shell HTTP hides its own outcome. A tool call cannot be masked the way
    a shell command can, so a 404 comes back as `statusCode: 404` — a fact.

  Over 3367 measured shell fetches, 70% piped the body into another command and 23%
  wrote it to a file. This replaces those two as two steps, which is how the pipeline
  worked anyway: `web_fetch_file(url)` then `bash: jq '.items' <path>`.

  Retrieval goes through dsh's own `ctx.web`, so it reuses the built-in provider and
  inherits the SSRF guard unchanged. It registers through `ctx.inject(['web'], …)`, so
  the breaker still loads with no web service, and is verified to appear in a real
  headless boot. The definition is plain JSON Schema rather than `defineTool`'s output,
  because a symlink-installed plugin resolves a bare specifier from its real path,
  where `@deepseek-ai/dsh-tools` is absent — that import failed SILENTLY.

### Removed

- **The `-w` write-out detection, added in 0.5.3 and generalised afterwards.** With shell
  HTTP refused, a `curl -w "%{http_code}"` can no longer run, so the whole rule — the
  format-string parsing, the tail match, the status-line marker and the `command`
  argument to `classifyFailure` — is unreachable. It is deleted rather than left in
  place: dead detection code is what produced the 0.4.0 misdiagnosis, where a
  measurement tool counted messages production could no longer deliver.

## [0.5.3] - 2026-09-22

### Fixed

- **A 404 printed by the model's own `curl -w "%{http_code}"` is now a failure.** Reported
  from a live session that ran **322 tool calls and was blocked by nothing**. The guard
  warned once (at `warnAt`, on one host) and the model then continued for another ~300
  calls; the failure track saw exactly **one** failure in the whole run.

  The shape: `curl -sL "URL" -o /dev/null -w "%{http_code}"`. curl exits **0** — a 404 is a
  successful transaction unless `--fail` was given — and the output is a bare number
  (`404 https://…`), which none of the existing markers match. 211 of that session's 322
  commands used the write-out, and 207 of their outputs led with a 4xx/5xx.

  The COMMAND is the evidence, so it is now passed to the classifier: when a shell command
  asked curl for `%{http_code}` (or `%{response_code}`), a **leading** 4xx/5xx in the output
  is the status by construction. Anchored to the start, which is where `-w` puts it — the
  same output often carries a byte count (`153226 /tmp/…`) whose digits contain something
  like `532`, and a `wc -c`-style number without the write-out request is not a status.

  Measured on the same 140 sessions: the rule takes the ≥3-failure sessions from 13 to 15
  and the ≥5 from 5 to 6, with **zero known-good runs caught**. It adds exactly two
  sessions, one of which is the reported one — whose longest failure streak goes from 1 to
  **101 consecutive 404s** on one host.

### Notes

- The occurrence track could not have caught that session, and this is structural rather
  than a threshold problem: the model rotated among four or five hosts, so with a 16-call
  window no single fingerprint stayed long enough to reach the cap of 12. Its peaks were
  8, 6, 6, 6. Rotating targets are what the failure track is for — and it needs to be able
  to see the failures, which is what this release fixes.


## [0.5.2] - 2026-09-22

### Fixed

- **No doubled space in the failure descriptions.** `suffix` carried its own leading space
  and was prefixed with another, so a Python crash read as `the script raised 
  urllib.error.URLError` and a curl failure as `curl failed (code  6)`. The same shape was
  already present in the timeout branch (`the call timed out ( 30000ms)`) and had gone
  unnoticed because that wording is rarely seen. `describeFailure` now builds each string
  explicitly, and a test checks every reason with and without a detail for doubled spaces
  and stray parenthesis spacing — the bug hid in the branches nobody read.


## [0.5.1] - 2026-09-22

### Fixed

- **The failure track was blind to the shapes a real spin produces.** Reported from a live
  run: seven calls against one host, five of them failing, and `failWarnAt: 3` never fired.
  Every one of those five had `isError: false` **and exit code 0** — `curl … | python3 … |
  head` exits with `head`'s status, and a script that catches its own `HTTP Error 400` exits
  0 as well — so the structured value said "success" and the text fallback did not recognise
  what was in the text.

  `lib/failure.js` now also recognises, in a shell result's text: `Traceback (most recent
  call last)`, a line-anchored Python exception (`SyntaxError:`, `urllib.error.URLError:`, …),
  `HTTP Error nnn`, and `curl: (n)`. On the reported run the failure streak is now 4 on
  `host:archive-api.open-meteo.com`, so the advisory fires at the third failure. Measured
  across 96 sessions, the markers raise the ≥3 sessions from 9 to 16 and the ≥5 from 5 to 6,
  with zero known-good runs caught.

### Changed

- **A status code is now definitive in both directions.** A fetch reporting `200` is a
  success and its text is never consulted, so a page that happens to contain the words
  "HTTP Error 400" or a traceback is no longer read as a failure. Previously the text
  fallback ran even after a successful status.
- **The text fallback is restricted to shell tools.** A shell's `exitCode: 0` proves
  nothing, so its text is the remaining evidence. Every other tool answers through its
  structured value; guessing from an arbitrary tool's prose is how a `read` of a Python file
  containing `ValueError:` becomes a failure.


## [0.5.0] - 2026-09-22

### Added

- **A second escalation track, on consecutive FAILURES of one fingerprint.** The
  occurrence track is unchanged (7 / 11 / 12, `host` 16). The new track exists because
  failure is a much stronger signal than repetition: repeating a call that WORKS is
  fixation, repeating one that FAILS is not learning. Its thresholds therefore sit well
  below the occurrence ones.

  | setting | default | what it does |
  | --- | --- | --- |
  | `failWarnAt` | 3 | after 3 consecutive failures of one fingerprint, deliver an advisory naming the target and the failure reason |
  | `failLimit` | 5 | after 5, a call carrying that fingerprint is blocked, subject to the existing `onLimit` policy (`ask`, fail-closed) |

- **A failure is not `result.isError`.** `isError` is true only when the CALL failed — a
  thrown error, an unknown tool, a sandbox denial — and is `false` for a non-zero exit
  code and for an HTTP 404, which are the two shapes that matter. Measured over 40
  recorded sessions, the thrown case covers 40 of 6765 bash results (0.6%); counting only
  it would have made the track blind. `lib/failure.js` reads the structured
  `result.value` each tool declares in its `output.schema` — non-zero `exitCode`,
  `statusCode >= 400`, `timedOut`, non-null `signal` — with a text-marker fallback.

### Notes

- **Only the fingerprints that hit are blocked.** A call that does not carry them —
  reading the error log, grepping the code, trying a different endpoint — is allowed.
  Blocking the recovery action is how a guard turns a stuck model into a wedged one.
- **A success clears that fingerprint's streak; a success of something else does not.**
  A read is not progress on the thing that keeps failing.
- **Both tracks share one measure set.** A fingerprint whose cap is `null` is disabled
  for both. This is load-bearing: measured over the corpus, the longest failure streaks
  sat on exactly those measures (9 on `family:http-fetch`, 8 on `verb:curl`, 7 on
  `verb:export`), so counting them would have reintroduced the 0.4.0 bug through a new
  channel.
- **The plugin never counts its own denial as a failure**, which would make the guard
  feed itself: deny a call, the streak grows, the next call is denied a step earlier.
- **The failure gate can only fire on a later call.** `ctx.tools.guard` is synchronous
  and runs before execution; the outcome is known only in `post-execute`. So after 5
  failures, the 6th call carrying that fingerprint is blocked.
- Both tracks feed the SAME gate, the same exemption prompt and the same refusal set. A
  second gate would have needed a second ask, a second refusal set and a second way to
  get stuck.
- Measured support (`tools/failure-run-measurement.mjs`, 107 sessions, enabled measures
  only): 3.6% of calls fail; 9 sessions reach a 3-failure streak, 5 reach 5, and **zero
  known-good runs reach 3**. The clearest real case was a session hitting
  `host:api.github.invalid` — a reserved, permanently nonexistent host — 8 times running.
- The compat suite gained a failure scenario, and its two occurrence scenarios now
  neutralise the exit status (`|| true`). Their commands cannot succeed, so without that
  they would have been testing the failure track instead of the one they name.


## [0.4.2] - 2026-09-22

### Changed

- **The three stages are retuned: `warnAt: 3 → 7`, `summarizeAt: 6 → 11`, and the caps
  `9 → 12` (with `host` at 16).** No behaviour changed and no setting was added or
  removed; only the numbers moved. The measurement is in `docs/issue-b-thresholds.md`.

  0.4.1's note deferred this until a wider corpus existed. That corpus is 109 recorded
  sessions with known or unknown outcomes, replayed through the plugin's own
  fingerprinting and validated against the real tool pipeline: the replay model and the
  genuine `dsh-tools` ToolRuntime agree exactly on every session and cap setting tried,
  including the two worst sessions (38/38 and 698/698 advisories and gate calls at the
  old caps; 15/15 and 246/246 at the new ones).

  What it showed:

  - **The old stages fired on runs that succeeded.** Two known-good runs peaked at 4 and
    6 repeats of one measure, and `warnAt: 3` sits below both. 10% of real sessions
    reach a peak of 13, which was above the old cap of 9.
  - **The old defaults cost a lot.** Over the 109 non-stuck sessions: 629 advisory
    messages, 49 sessions warned, 19 gated, 2296 calls blocked. The new defaults deliver
    158 messages, warn 26 and gate 10 — while still catching the known-stuck run.
  - **`host:` is deliberately looser (16) than action identity (12).** It discards the
    URL path, so installing many packages from one mirror and re-fetching one broken URL
    look identical to it; it accounted for 25 of the 48 (session, fingerprint) pairs
    that reached a cap at 9. 16 is the window itself — the whole window is one host.

### Notes

- **A stage above a cap can never be delivered.** The gate fires first, so a
  `summarizeAt` at or above every cap is dead code — which is why the stages and the caps
  move together. Nothing validates one setting against another (a `limits` entry below a
  stage remains a deliberate way to skip the advisory), but the *defaults* must not ship
  a stage that can never speak. For the same reason a threshold above the window (16) can
  never fire.
- **`tools/convergence-measurement.mjs` is superseded** by `tools/threshold-sweep.mjs`.
  The old tool tallied every fingerprint including the `null`-capped measures 0.4.1
  stopped escalating, and counted crossings rather than messages — which is how 0.4.0's
  over-trigger was first mistaken for a threshold problem.

## [0.4.1] - 2026-09-22

### Fixed

- **A measure with no cap no longer escalates.** The advisory stages were applied to
  EVERY fingerprint, ignoring `limits` — so the volume measures that ship DISABLED
  (`site:`, `family:*`, `verb:*` are all `null`) still warned, and still demanded
  summaries. One `curl` emits four of those measures at once, so a single action could
  produce up to four near-identical messages about one behaviour. Observed in
  production as `verb:cd has come up 3 times` followed by `verb:cd has now come up 6
  times`, and in a test-battery run as **5 messages in 7 tool calls** covering only 3
  distinct behaviours. The stages live BELOW the cap: a measure with no cap has no
  gate, so it must have no escalation either.
  Reported by the backend-test session in `GUARD-OVERTRIGGER-REPORT.md`.

- **The message now names the useful measure.** Identical calls cross `exact:`, `net:`,
  `site:` and `host:` at the same count, and the first in iteration order won — which
  usually meant a truncated command line (`exact:bash:{"command":"curl -s \"…`). A
  target-scoped measure is preferred: `host:` > `net:` > `site:` > `sink:` > `cmd:` >
  `exact:`.

### Notes

- **Thresholds are unchanged in this release.** The same report also argues that
  `warnAt: 3` and `summarizeAt: 6` sit low relative to a known-good run (which reached
  4–8 requests to one host). That needs the wider measurement the report itself asks
  for, and it should be judged only after the bug above is out of the way: the bug
  accounted for most of the observed message volume, because it multiplied one action
  into four measures.

## [0.4.0] - 2026-09-21

The escalation release. Repetition is no longer a wall you hit once: the same
measure now warns, then demands a summary, and only then gates — and the gate asks
the operator instead of silently blocking.

### Added

- **Two advisory stages under the cap.** Repeating one measure inside a turn now
  escalates: `warnAt` (3) says "you are repeating yourself, consider another
  route"; `summarizeAt` (6) demands a written progress summary and at least two
  approaches the model has not tried, plus an instruction to use a **larger
  per-batch amount** so there are fewer batches. Both are delivered as
  `additionalContexts` on `tools/post-execute` — the channel
  `@deepseek-ai/dsh-repeat-tool-reminder` uses — stamped `source.kind: 'plugin'`.
  A stage fires once per crossing, on exact equality, so the window sliding does
  not re-announce it.
  A stage is disabled by `0`, a negative number or `null`, silently: that is the
  documented off-switch, not a value to reject.

- **`onLimit`: what happens at the cap.** `ask` (default) offers the operator a
  turn-scoped exemption; `deny` blocks outright. `ask` is fail-closed — every
  unattended approval outcome is a denial, so a headless profile denies by itself
  and nothing stalls.

- **The `host:` measure.** `net:` keeps the query by design (that is what makes
  `?page=2` a different resource, fixed in 0.3.2), which means an agent grinding
  one API produces entirely distinct `net:` entries and nothing accumulates.
  `site:` collapses to the last two DNS labels, so `api.weather.gc.ca` and every
  other `*.gc.ca` host share one identity. The host is the level at which "the
  same target again" is both true and discriminating, and it is what makes a fixed
  strategy visible. Local hosts are excluded from it by default
  (`includeLocal: false`); `localHosts: allow` still emits no target fingerprints.

- **Per-fingerprint exemptions.** An approved exemption covers exactly the measures
  that hit, stops counting them for the rest of the turn, and says nothing about
  any other measure.

### Changed

- **The cap moves from 5 to 9** — `exact`, `cmd`, `net`, `sink` and the new
  `host`. Two escalations now sit underneath it, so the hard break moves later
  rather than staying at the first threshold.
- **`window` moves from 12 to 16.** Measured against a corpus with known outcomes
  and against the production sessions, the wider window changed no verdict: the
  failing sessions reached a host count of 18 either way, and the one successful
  session that grinds stayed at 5. It admits three more sessions at the gate stage
  in production. Adopted for margin, not because 12 was shown to miss.

### Removed

- **`localHosts: ask`.** Asking is no longer a local-only concern — it is what
  `onLimit` does for every measure — so `localHosts` keeps only `deny` and
  `allow`. A config still carrying `localHosts: ask` fails loud at load with the
  migration (`use `onLimit: ask``), the same way 0.2.0 handled a removed key.

### Fixed

- **The 0.3.2 changelog was wrong about `site:`.** It claimed "`site:` no longer
  merges unrelated services"; `siteOf` has not changed since v2 and still collapses
  to two labels. 0.3.2 turned the `site:` *cap* off — it never fixed the merge. The
  host measure is the fix.

### Notes

- **No setting is validated against another.** A `limits` entry below a stage means
  "no escalation for this measure", and inverted stages simply fire in the other
  order. Both are ways to express intent, and second-guessing them would be worse
  than accepting them.
- **Pagination is handled by the escalation, not by an exemption.** 0.3.2 made
  pagination stop colliding on `net:`; eight distinct pages of one host now reach
  `host: 8`, so the ninth request to that host is the cap-th. That is intended, not
  a leftover: stage 2 at 6 is where a model processing in batches is told to use a
  larger per-batch amount, and one that takes the advice finishes well under the gate
  at 9. The advice is deliberately backend-agnostic — the same shape appears when an
  agent reads a file line by line — and a test pins that it never names HTTP paging.
  `T14c` asserts the shape.

## [0.3.3] - 2026-09-15

### Changed

- **The action-identity caps are 5, not 3** — `exact`, `cmd`, `net` and `sink`.
  3 fixed the retry case that 2 broke, but it still tripped on *dense legitimate
  work*. The clearest instance was `sink:`: it is path-only **by design** — its
  whole job is to catch one destination being rewritten with ever-changing
  content — so a shell cycle that writes the same file several times while
  iterating is indistinguishable from a loop at 3. On the reference deployment a
  session building and re-running scaffolding was denied on its third write to the
  same path with three *different* payloads.

  Raising the cap is the right lever here rather than making `sink:`
  content-sensitive: a content hash would make it fire only on a byte-identical
  rewrite, which `exact:` already catches, and would therefore remove the one
  thing `sink:` exists to do. At 5 an ordinary edit/test cycle fits, and a real
  loop is still stopped — it reaches the cap because it never changes what it is
  doing.

  Net effect: two extra attempts per action before the hard break. The suite is
  expressed in terms of the cap (`const CAP = cfg.limits.exact`); six tests that
  had hard-coded the 3-call shape now derive it from `CAP` instead.

### Notes

- The gate is unchanged in kind and still **fail-closed**: an action repeated five
  times inside a 12-call window is denied exactly as before, and every unattended
  `localHosts: ask` outcome is still a denial.

## [0.3.2] - 2026-09-15

### Fixed

- **Pagination is no longer mistaken for repetition.** `net:` discarded the query
  string, so `...commits?per_page=100` and `...commits?per_page=100&page=2` were
  the same resource. The query is now part of the fingerprint — sorted, with
  tracking parameters (`utm_*`, `fbclid`, `gclid`, …) removed, so a page number
  distinguishes one page of results from the next while a cosmetic parameter still
  cannot launder a repeat.
- **`site:` no longer merges unrelated services.** `siteOf()` collapses a host to
  its last two labels, so `api.github.com` and `github.com` shared one budget; a
  session paginating a GitHub commit list tripped `site:github.com 6/3`.

### Changed

- **The volume budgets are off by default**: `site`, `family:http-fetch`,
  `verb:curl`, `verb:wget` are now `null`. A budget on how much one site or one
  verb may be used cannot tell a crawl from a session making progress, and every
  value tried produced a false positive on a real session — four different URLs
  blocked by `family:http-fetch: 4`, a development loop blocked by
  `site:127.0.0.1`, and the commit crawl above. The worst part was the shape of
  the failure: the agent's own comment in that session read
  `# Fetch page 2 of openvino commits using a script file to avoid repeat
  detection` — an agent working *around* the breaker instead of changing
  approach is the opposite of the intent.

  Repetition is what this plugin detects, and `exact`, `cmd`, `net` and `sink`
  still do it. Anyone who wants a crawl budget can set one back:
  `limits: { site: 30, 'family:http-fetch': 60 }`.

### Notes

- The local-address policy is unaffected in principle but changes shape in
  practice: with `site:` gone, a local loop only accumulates when it hits the
  SAME host+path, which is exactly what `localHosts` relaxes.

## [0.3.1] - 2026-09-15

### Changed

- **`localHosts` now defaults to `ask`**, so installing the plugin is enough: no
  profile needs a hand-written patch to get the prompt. This is safe because
  `ask` is **fail-closed** — every unattended outcome of an approval is a denial
  (`rejected` when the session policy is `never`, `cancelled` when the turn is
  aborted, and `unavailable`, the value the registry falls back to when no
  answerer is registered) — so a headless profile degrades to `deny` by itself
  instead of stalling.

  The one visible difference in an unattended profile: the model's *first* blocked
  local call of a turn receives the registry's "requires approval, but no approval
  channel is available" instead of `REPEAT_TOOL_BLOCKED`. From the second one on —
  the refusal is remembered for the turn — the breaker's own message applies
  again. Set `localHosts: deny` to avoid even that.

### Fixed

- The refusal note no longer claims the operator declined: with no approval
  channel the request was never shown to anyone, so it now says the exemption was
  not granted "either because the request was declined, or because no approval
  channel was available to answer it".

## [0.3.0] - 2026-09-15

### Added

- **`localHosts`: `deny` | `ask` | `allow`** — local addresses (`localhost`,
  loopback, RFC1918, link-local) are now their own class instead of being counted
  as an ordinary web site. The `site:` budget was blocking ordinary development
  loops: on the reference deployment a handful of calls that merely *mentioned* a
  loopback URL tripped `site:127.0.0.1` while nothing was being crawled.

  - `deny` (default) keeps today's behaviour and names the knob in the message.
  - `ask` offers the operator a prompt, **once per turn**; approving exempts local
    targets for the rest of that turn, declining stops the asking until the next
    human message. It belongs in a profile with a UI — a headless profile should
    keep `deny`, where an open question would stall the turn. Hence: configure it
    per profile.
  - `allow` never fingerprints local traffic.

- `fingerprints()` now reports whether a call is **local** (it mentions at least
  one URL and every URL it mentions is local), which is what the policy acts on.

### Notes

- Only the target-scoped fingerprints (`net`, `site`, `sink`, `family`, `verb`)
  are ever relaxed: `exact` and `cmd` identify the ACTION, and a byte-identical
  repeat is a loop whether or not it points at localhost. A call mentioning even
  one public URL is not a local call.
- An ask is only made when local traffic is the *sole* reason for the block, so a
  genuine repeat is a straight denial rather than a prompt.
- `ask` had to be split across two hooks: `tools/pre-execute` can ask but cannot
  deny, and `ctx.tools.guard` can deny but cannot ask. The pipeline hands a
  rejected ask straight to `post-execute` and never runs the guard, so "the guard
  saw this execution" is exactly the approval signal.

## [0.2.4] - 2026-09-15

### Removed

- The `pathAliases` config key, and the `firstPathArg` helper it fed. Both became
  dead in 0.2.2, when the path-only `readpath`/`writepath` fingerprints were
  removed — the key has had no reader since, so the README was documenting a knob
  that did nothing. A config that still lists `pathAliases` is accepted and
  ignored, so no consumer has to change anything.

### Fixed

- The bundle patch's header comment still advertised the **original** v2 cap table
  (`exact`/`cmd`/`net`/`sink` 2, `family`/`verb` 4, plus `readpath`/`writepath`),
  three releases after those values changed. It now states the shipped table.

### Added

- `test/compat/` — a full-boot compatibility harness (scripted mock model + a
  real `dsh` of the version under test). Repository tooling only; `test/` is not
  published, so there is no npm release for it.

## [0.2.3] - 2026-09-15

### Changed

- **The action-identity caps are 3, not 2** — `exact`, `cmd`, `net` and `sink`.
  A cap of 2 has no room for the most common *non-loop* repeat: the first attempt
  fails for a reason unrelated to looping (a precondition the harness enforces, a
  DNS failure) and the correct response is to retry the same call. At 2 that
  retry is precisely what gets blocked, so the only way forward is to change the
  call cosmetically — the behaviour this plugin exists to stop.

  The alternative considered was refunding the budget of a guard-allowed call
  whose body failed. It was rejected: it makes the guard depend on how a failure
  is reported, and a call that fails *every* time would refund itself forever and
  never be blocked. Raising the cap is stateless, depends on nothing, and still
  stops a failing loop on the third attempt.

  Net effect: one extra attempt per action before the hard break. `T2b` pins the
  retry case; the rest of the suite now expresses its expectations in terms of the
  cap (`const CAP = cfg.limits.exact`) instead of hard-coding 2.

## [0.2.2] - 2026-09-15

### Changed

- **File operations are no longer counted by path.** `read`/`write`/`edit` are
  identified by **position** through `exact:` — the same file at the same offset,
  or the same replacement string, is the same action and is denied; a different
  offset or a different region is a different action and is never blocked. The
  `readpath` and `writepath` limits and their fingerprints were removed.

  Both were introduced in 0.2.0 to give a per-file budget, and both had to go
  after live use: `writepath: 3` denied the third consecutive edit of a single
  document (0.2.1 disabled it), and `readpath: 2` denied the *second read of a
  file that was being edited* — a step dsh's own fs-observation policy requires
  before every edit, so the plugin was blocking the workflow it exists to protect.

  Nothing is lost: an identical re-read or re-edit still collides on `exact:`.

### Removed

- Limits `readpath` and `writepath`, and the `readpath:`/`writepath:`
  fingerprints. A config that still lists them is accepted but inert.

## [0.2.1] - 2026-09-15

### Fixed

- **`writepath` is disabled by default** — `null` instead of `3`. Editing one file
  repeatedly is ordinary work, not a loop: the reference deployment hit the cap of
  3 on the **third consecutive edit of a single document** within minutes of
  installing 0.2.0, while writing a SKILL.md. The loop the cap was meant to catch
  — rewriting a file with the same content — is already covered by `exact`
  (cap 2). Set `limits.writepath` to a number to restore a per-file write budget.

### Notes

- Not a breaking change: `null` was already a valid value for a limit, so this
  only moves a default. Nothing in the configuration schema or public API changed.

## [0.2.0] - 2026-09-13

The semantic-rewrite release. v1 counted *byte-identical consecutive* calls, so a
model could stay in a loop simply by varying a presentation field or the host
spelling; v2 strips decoys first and then counts semantic fingerprints over a
sliding window.

### Fixed

- **`description: '1st'/'2nd'/'3rd'` (plus a churning `timeoutMs`) no longer
  launders a repeat.** Decoy arguments are deleted *before* any fingerprint string
  is built, so those calls become byte-identical and collide on `exact:`. The
  suite asserts that no fingerprint of such a call contains the decoy text or the
  timeout value.
- **Host ping-pong is now caught.** `curl --max-time 60 open-data.canada.ca` ↔
  `curl --max-time 30 open.canada.ca` previously alternated forever: the calls
  were not consecutive-equal and the command was never normalized. `net:` folds
  host aliases and strips the query, and `cmd:` strips volatile flags, so both
  spellings collide — as does the same fetch re-issued through `wget`.
- **A denied call no longer risks a free retry.** The guard commits a call on the
  deny path too, so hammering a blocked call cannot reset its own budget.

### Changed — breaking

- Counting moved from a **consecutive-run counter** to a **per-agent sliding
  window** (`window`, default 12 calls) over a *set* of fingerprints per call:
  `exact:`, `cmd:`, `net:`, `site:`, `sink:`, `readpath:`, `writepath:`,
  (the last two were removed again in 0.2.2 — see below)
  `family:http-fetch`, `verb:<cmd>`.
- Configuration is now `{ window, previewChars, resultPreviewChars, exclude,
  include, ignoreArgs, pathAliases, hostAliases, limits }`. The v1 keys
  `denyAfter`, `warnAfter`, `registerAdvisory`, `maxSamePath`, `readTools` and
  `matchReadBySubstring` are **removed**: passing one now throws at load with a
  pointer at its replacement instead of being silently ignored.
- The advisory tier (`warnAfter` / `registerAdvisory` / `additionalContexts`) was
  removed. The guard denies; there is no separate soft-notice path. The official
  `@deepseek-ai/dsh-repeat-tool-reminder` remains the soft tier.
- `limits`, `ignoreArgs` and `hostAliases` merge one level deep over the defaults;
  `exclude`, `include` and `pathAliases` **replace** the default arrays.
- The package is now `index.js` + `lib/` (`defaults`, `normalize`, `fingerprints`,
  `window`, `message`); the test entry point is
  `node --test test/breaker.test.js` (the old `test/logic.test.mjs` was
  superseded).

### Added

- A per-fingerprint **hit list** in the denial message, so the model is told
  exactly which identities collided and how many times, that cosmetic variation
  is not a new action, and what the previous result was.

### Deliberate deviations from the v2 specification

Four, each a consequence of running the plugin against a live model on the
reference deployment (Qwen3.8-27B via the `dsh-container` harness). All are
reversible from config alone.

- File reads and writes get separate counters (`readpath`, `writepath`) instead of
  sharing one `sink:`. The spec's single counter would deny the second half of the
  ordinary `read foo.ts` → `write foo.ts` pair, which is an edit, not a loop.
- `file_path` was added to `pathAliases`; the spec's list omitted the key dsh's own
  `read`/`write`/`edit` tools actually use, which would have left every file read
  ungated.
- **Generic sinks are not fingerprints.** A live run of "get the status code of
  these four URLs" fetched `https://example.com/` and then had every following
  call denied, because all four used `curl -s -o /dev/null` and therefore shared
  `sink:/dev/null`. `/dev/null` (and the other null devices, and `-`) say nothing
  about which resource was fetched.
- **The volume caps ship at 6, not 4**, and **a denied call commits only the
  fingerprints that hit.** The first was changed because the same four-URL run
  also tripped `family:http-fetch: 4` and `verb:curl: 4`; the second because a
  denied `curl https://example.org` was charging `net:example.org/` for a fetch
  that never happened, after which the model could not reach that URL through any
  tool for the rest of the turn. Hammering a denied call stays blocked either way,
  since the hitting fingerprint is already at its cap.

## [0.1.3] - 2026-09-12

### Fixed

- **The package now declares `dsh.bundle`, so the shipped `cordis.patch.yml` is
  actually reachable.** The file was already in `files`, but with no
  `"dsh": { "bundle": { "patch": "./cordis.patch.yml" } }` manifest, listing
  `dsh-repeat-tool-breaker` in a profile's `dsh.profile.bundles` failed the boot
  with `dsh: profile bundle "dsh-repeat-tool-breaker" declares no dsh.bundle in
  its package.json` — an unhandled throw from `loadProfile`, not a soft warning.
  The bundled patch was dead weight: unreachable through the bundle path and
  usable only as a copy-paste `--patch` overlay.

### Changed

- `cordis.patch.yml` is now a real bundle layer: it mounts the plugin row by its
  **package specifier** (`name: 'dsh-repeat-tool-breaker'`) instead of the
  `/ABS/PATH/index.js` placeholder, and it carries **no `config:`** — so the
  plugin's own fail-loud `DEFAULTS` apply and a profile that wants different
  values restates them in its own patch layer. The previous `warnAfter: 1` in the
  snippet was inert anyway (the advisory needs `2 <= warnAfter < denyAfter`), so
  behaviour for anyone who copy-pasted it is unchanged.
- `cordis.patch.yml` comments document both install paths (list as a bundle vs.
  mount by hand / `--patch`), including the fact that a patch *replaces* a row's
  whole `config` rather than merging, and that an absolute path is still the way
  to mount a checkout that is not installed into the profile.
- README: bundle-install path documented alongside the manual mount row.

## [0.1.2] - 2026-09-11

### Changed

- Publishing runs through the `Publish to npm` GitHub Actions workflow using
  **npm Trusted Publishing (OIDC)** — no long-lived npm token is required. The
  workflow upgrades the npm CLI first, because Trusted Publishing needs npm
  >= 11.5.1 while Node 22 bundles an older one. A repository `NPM_TOKEN` secret is
  still honoured as a fallback when trusted publishing is not configured.
- README: npm badge, install instructions for the published package, and the
  corrected advisory-tier documentation.

## [0.1.1] - 2026-09-11

### Fixed

- **The advisory no longer fires on ordinary calls.** The `warnAfter` notice was
  keyed only on `count === warnAfter`, and because every fresh tool call starts a
  new run at count 1, the default `warnAfter: 1` attached a misleading "you just
  ran X with identical arguments 1 time(s)" message to *every* tool call —
  polluting context for no reason. The advisory is now inert unless
  `2 <= warnAfter < denyAfter` (a repeat must have happened, and the block must
  not have happened yet), default `warnAfter` is raised from 1 to 2, and the
  wording now describes a real repeat ("N times in a row").
- Caller-provided config arrays (`exclude`, `include`, `readTools`, `pathAliases`)
  are copied before being frozen, so the plugin no longer freezes an array the
  caller still owns.
- Removed a dead `denyAfter` overflow check that `Number.isInteger` already made
  unreachable.

### Changed

- `tools/post-execute` computes the call signature once instead of twice.
- Test suite grown from 20 to 29 assertions (advisory reachability, no-advisory
  regressions, fail-loud config, caller-array ownership).

## [0.1.0] - 2026-09-11

### Added

- Initial release: a dependency-free DSH plugin that hard-blocks identical repeated
  tool calls through the synchronous monotonic `ctx.tools.guard` gate.
- Denies the **2nd** identical (tool name + canonical arguments, property order
  ignored) call per agent by default; the denied call never executes and the model
  receives a `REPEAT_TOOL_BLOCKED` result quoting the previous successful result.
- Same-path read cap (`maxSamePath`) bounding read-like tools called repeatedly on
  one file with *varying* arguments.
- Per-agent `WeakMap` state; user-message chain reset via `agent/pre-step`;
  transparent tool exclusion (default `todo_write`).
- Advisory `warnAfter` notice delivered through `tools/post-execute` — never a
  deny, and it never increments the chain.
- Deterministic guard-logic acceptance suite (`test/logic.test.mjs`) and GitHub
  Actions CI on Node 20 and 22.

[Unreleased]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.8.0...HEAD
[0.8.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.7.0...v0.8.0
[0.7.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.6.2...v0.7.0
[0.6.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.6.1...v0.6.2
[0.6.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.6.0...v0.6.1
[0.6.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.3...v0.6.0
[0.5.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.2...v0.5.3
[0.5.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.1...v0.5.2
[0.5.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.5.0...v0.5.1
[0.5.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.4.2...v0.5.0
[0.4.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.3...v0.4.0
[0.3.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.2...v0.3.3
[0.3.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.1...v0.3.2
[0.3.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.3.0...v0.3.1
[0.3.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.4...v0.3.0
[0.2.4]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.3...v0.2.4
[0.2.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.2...v0.2.3
[0.2.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.1...v0.2.2
[0.2.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.2.0...v0.2.1
[0.2.0]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.3...v0.2.0
[0.1.3]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.2...v0.1.3
[0.1.2]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.1...v0.1.2
[0.1.1]: https://github.com/snailium/dsh-repeat-tool-breaker/compare/v0.1.0...v0.1.1
[0.1.0]: https://github.com/snailium/dsh-repeat-tool-breaker/releases/tag/v0.1.0
