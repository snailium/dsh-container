/**
 * The harness browser session the relay presents upstream.
 *
 * From harness 0.1.2 the harness authenticates its complete `/api` surface —
 * every Remote call, the `/api/remote.mux` upgrade, and the session-log
 * download — against a signed, authority-bound cookie, and answers 401 without
 * one. The relay strips the client's own `Cookie` before forwarding (that
 * header authenticates the phone to the *relay* and means nothing upstream),
 * so without a session of its own every proxied request is refused.
 *
 * The relay cannot obtain one the way a browser does: the launch token is
 * printed once per harness process, is only accepted on the index route, and is
 * never persisted. What it can do is what the harness itself does — read the
 * durable signing secret from the credential store it shares and mint a cookie
 * directly. That is not a bypass. The relay already runs inside the harness
 * process with the operator's authority; a plugin that can read `ctx.credentials`
 * could call any harness API in-process without a cookie at all. Minting one
 * only lets it speak the same HTTP contract as the browser.
 *
 * @module dsh-relay/harness-session
 */
import type { Context } from '@deepseek-ai/cordis';
/** Mints harness browser-session cookies for proxied requests. */
export declare class HarnessSession {
    private readonly secret;
    private constructor();
    /**
     * The signing secret, for the resolver's rotation check.
     *
     * Package-internal by convention: it exists so {@link HarnessSessionResolver}
     * can tell a rotated secret from the one it memoized, and nothing outside
     * this module has a reason to read it.
     * @returns the 32-byte signing secret.
     */
    get signingSecret(): Buffer;
    /**
     * Mint a session over a known secret, for callers that already read it.
     * @param secret - a 32-byte signing secret.
     * @returns a minter over that secret.
     */
    static over(secret: Buffer): HarnessSession;
    /**
     * Load the harness's cookie-signing secret.
     *
     * @param ctx - plugin context; `ctx.credentials` is the harness's own store.
     * @returns a minter, or undefined when this harness keeps no such secret —
     *   which is every release before 0.1.2, where nothing needed one.
     */
    static load(ctx: Context): Promise<HarnessSession | undefined>;
    /**
     * A minter that reads the secret **on every request**, so a harness that had
     * not written it yet at plugin-mount time still gets one.
     *
     * This exists because {@link load} alone is not enough, and the failure it
     * leaves behind is invisible from the phone: on a cold start the relay mounts
     * before `dsh-client-connection` has created its signing secret, `load`
     * returns `undefined`, and the relay then forwards **unauthenticated for the
     * rest of the process's life**. Every proxied request is answered 401 while
     * the relay's own pages keep working, so it reads as "the stream would not
     * open" rather than as a missing credential. Production carried a
     * `relay-hotreload.sh` workaround that edited the config after boot purely to
     * force this plugin to re-run `load`.
     *
     * The credentials provider's own contract is the reason this is a read
     * rather than a race to patch: "Resolution is per call: consumers re-resolve
     * at each operation and must not cache across operations." Reading it per
     * request is the documented usage, and it also picks up a secret rotated
     * under a running process.
     *
     * @param ctx - plugin context; `ctx.credentials` is the harness's own store.
     * @returns a resolver that yields a minter once the secret exists.
     */
    static lazy(ctx: Context): HarnessSessionResolver;
    /**
     * A minter backed by a secret of the caller's choosing. Tests only.
     * @param secret - a 32-byte signing secret.
     * @returns a minter over that secret.
     */
    static forTesting(secret?: Buffer): HarnessSession;
    /**
     * The `Cookie` header value proving a browser session for [authority].
     * @param authority - the upstream `host:port` this request will carry.
     * @returns one `name=value` pair, ready to send as `Cookie`.
     */
    cookieFor(authority: string): string;
}
/**
 * Resolves the harness browser session per request, retrying until it exists.
 *
 * Once the secret has been seen it is memoized: the read is cheap, but this
 * sits on the path of every proxied request and every WebSocket upgrade, and a
 * disk read per request for a value that does not change is waste. The
 * memoized value is dropped only if the store later stops answering, so a
 * rotated or removed secret is picked up rather than frozen.
 *
 * A *missing* secret is never memoized — that is the whole point. The negative
 * result is what a cold start produces, and caching it is precisely the bug
 * this class exists to fix.
 */
export declare class HarnessSessionResolver {
    #private;
    private readonly ctx;
    /**
     * @param ctx - plugin context; `ctx.credentials` is the harness's own store.
     */
    constructor(ctx: Context);
    /**
     * The current minter, reading the store when it is not already known.
     * @returns a minter, or undefined while the harness has no such secret —
     *   which is every release before 0.1.2, and the first moments of a cold
     *   start on 0.1.2 or later.
     */
    current(): Promise<HarnessSession | undefined>;
    /**
     * The current minter without touching the store.
     *
     * The request path cannot await: it builds headers synchronously for every
     * proxied call and every WebSocket upgrade. This returns whatever the last
     * {@link current} read resolved, which {@link HarnessSessionResolver} keeps
     * fresh in the background.
     * @returns the memoized minter, or undefined while none has been read.
     */
    sync(): HarnessSession | undefined;
    /**
     * Whether this resolver has ever produced a session.
     * @returns true once the harness's secret has been read successfully.
     */
    get ready(): boolean;
    /**
     * Note the first successful read, so a cold start can be reported as
     * recovered rather than passed over in silence.
     * @returns true the first time it is called after a miss, false afterwards.
     */
    markRecovered(): boolean;
}
//# sourceMappingURL=harness-session.d.ts.map