/**
 * dsh-relay — authenticated remote access to a DeepSeek Harness web profile.
 *
 * The harness serves its browser API on loopback and says plainly that its
 * `/api` trust fence "is not an auth layer", that its configuration plane
 * stays loopback-only "until a real authentication layer exists", and that
 * `--host 0.0.0.0` is refused because it "would expose remote code execution
 * to the network". This plugin is that missing layer, mounted beside the
 * harness rather than inside it.
 *
 * It starts its own listener, authenticates, and reverse-proxies to the
 * untouched loopback web server. The harness keeps its shipped bind, so a
 * failed or misconfigured relay leaves the harness unreachable from the
 * network rather than open to it.
 *
 * Everything registered here is an effect, so `dsh plugin remove`, a config
 * edit, or a hot reload closes the listeners, withdraws the mDNS record, and
 * stops the throttles without leaving a port bound.
 * @module dsh-relay
 */
import type { Context } from '@deepseek-ai/cordis';
import { type ConfigSchema } from './config.ts';
export { Config, plainConfig } from './config.ts';
export type { CompatConfig, ConfigSchema, PrivilegedPolicy, TlsMode } from './config.ts';
/** Stable Cordis plugin name. */
export declare const name = "relay";
/** The harness web server this relay fronts. */
export declare const inject: string[];
/**
 * The plugin object the Cordis loader registers, and the only reason this
 * module has a default export.
 *
 * The loader normalizes a module's exports down to a single plugin object —
 * `unwrapExports` is `exports.default ?? exports` — and then caches the
 * configuration schema off **that** object, as `{ name, callback, fibers,
 * Config: plugin.Config }`. The harness's settings plane reads it back with
 * `entry.fiber.runtime.Config` to decide whether an entry is an editable
 * namespace at all.
 *
 * A module that exports a bare `apply` **function** therefore has no `.Config`
 * for anyone to find, and its entry is invisible to the Plugins page no matter
 * how correct the rest is: the Host serves no namespace, and the browser card
 * has nothing to attach to. Verified against dsh 0.1.7-rc.2, where this plugin
 * with only the named exports contributes **zero** namespaces to
 * `settings/describe`.
 */
declare const _default: {
    name: string;
    inject: string[];
    apply: typeof apply;
    Config: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
        bind: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        port: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        stateDir: import("@deepseek-ai/schemastery").default<string, string, "defined">;
        trustedHosts: import("@deepseek-ai/schemastery").default<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        publicHostnames: import("@deepseek-ai/schemastery").default<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        tls: import("@deepseek-ai/schemastery").default<"self-signed" | "files" | "off", "self-signed" | "files" | "off", "volatile-defined">;
        tlsCertPath: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        tlsKeyPath: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        auth: import("@deepseek-ai/schemastery").default<"password" | "device-token" | "both", "password" | "device-token" | "both", "volatile-defined">;
        sessionTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        deviceTokenTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        pairingWindowMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        pairingCodeLength: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        maxFailedAttempts: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        lockoutMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        rateLimitPerMinute: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        privilegedMethods: import("@deepseek-ai/schemastery").default<"allow-authenticated" | "loopback-only", "allow-authenticated" | "loopback-only", "volatile-defined">;
        extraProxyPaths: import("@deepseek-ai/schemastery").default<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        proxyTimeoutMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        compat: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
            addressGrants: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
            addressGrantTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
            plainPort: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            addressGrants: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
            addressGrantTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
            plainPort: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        }>>, "plain">;
        uiLink: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
        mdns: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
        mdnsName: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    }>>, Schemastery.ObjectT<NoInfer<{
        bind: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        port: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        stateDir: import("@deepseek-ai/schemastery").default<string, string, "defined">;
        trustedHosts: import("@deepseek-ai/schemastery").default<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        publicHostnames: import("@deepseek-ai/schemastery").default<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        tls: import("@deepseek-ai/schemastery").default<"self-signed" | "files" | "off", "self-signed" | "files" | "off", "volatile-defined">;
        tlsCertPath: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        tlsKeyPath: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
        auth: import("@deepseek-ai/schemastery").default<"password" | "device-token" | "both", "password" | "device-token" | "both", "volatile-defined">;
        sessionTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        deviceTokenTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        pairingWindowMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        pairingCodeLength: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        maxFailedAttempts: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        lockoutMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        rateLimitPerMinute: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        privilegedMethods: import("@deepseek-ai/schemastery").default<"allow-authenticated" | "loopback-only", "allow-authenticated" | "loopback-only", "volatile-defined">;
        extraProxyPaths: import("@deepseek-ai/schemastery").default<NoInfer<string[]>, NoInfer<string[]>, "volatile-defined">;
        proxyTimeoutMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        compat: import("@deepseek-ai/schemastery").default<Schemastery.ObjectS<NoInfer<{
            addressGrants: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
            addressGrantTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
            plainPort: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        }>>, Schemastery.ObjectT<NoInfer<{
            addressGrants: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
            addressGrantTtlMs: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
            plainPort: import("@deepseek-ai/schemastery").default<number, number, "volatile-defined">;
        }>>, "plain">;
        uiLink: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
        mdns: import("@deepseek-ai/schemastery").default<boolean, boolean, "volatile-defined">;
        mdnsName: import("@deepseek-ai/schemastery").default<string, string, "volatile-defined">;
    }>>, "plain">;
};
export default _default;
/**
 * Mount the relay.
 * @param ctx - plugin context; `ctx.webServer` is the harness listener to front.
 * @param config - resolved configuration.
 */
export declare function apply(ctx: Context, config: ConfigSchema): void;
//# sourceMappingURL=index.d.ts.map