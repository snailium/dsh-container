/**
 * The relay's card on the harness's **Plugins** page.
 *
 * What belongs here and what does not: pairing, revocation, and the
 * certificate pin live on the relay's own pages, because they must work before
 * a person is signed in and from a device that is not this one. This card is
 * the configuration surface — the switches that change how the relay behaves —
 * plus the way in to those pages.
 *
 * **The platform draws the card.** On dsh 0.1.7 the Plugins page supplies the
 * title button, the disclosure chevron, and the frame, and asks this component
 * for two things only: a one-liner when `view` is `summary`, and the form body
 * when it is `page` — which is `SettingsForm` plus the fields. Drawing an outer
 * `<li>` with its own header here, as the 0.1.5 card did, produces a doubled
 * card whose inner button sits over the platform's and swallows its clicks.
 *
 * The card is only ever rendered on loopback. The harness decides whether a
 * settings namespace is writable from `connection.isLoopback`, computed in the
 * browser from the page address, so a remote browser is served no namespaces
 * and this page dispatches no cards at all. The snapshot's `writable` flag is
 * what that looks like from in here.
 *
 * Edits are staged and written on save, as the neighbouring cards do. That is
 * not only for consistency: saving a relay field rebinds the listeners and
 * drops the connections in flight, so a control that committed as it settled
 * turned one change of mind into several disconnections.
 * @module dsh-relay/client/RelayCard
 */
/** The relay configuration this card reads. */
export interface RelayValue {
    readonly bind?: string;
    readonly port?: number;
    readonly tls?: string;
    readonly privilegedMethods?: string;
    readonly uiLink?: boolean;
    readonly mdns?: boolean;
    readonly compat?: {
        readonly addressGrants?: boolean;
        readonly plainPort?: number;
    };
}
/** One staged field, as the shared form model reports it. */
export interface FieldState {
    readonly text: string;
    readonly overridden: boolean;
    readonly invalid: boolean;
}
/** The card-level state the shared form model reports. */
export interface Shell {
    readonly available: boolean;
    readonly writable: boolean;
    readonly dirty: boolean;
    readonly invalid: boolean;
    readonly saving: boolean;
    readonly failed: boolean;
}
/** The projection the renderer's bound hook returns. */
export interface RelayCardState extends Shell {
    readonly value: RelayValue | undefined;
    readonly bind: FieldState;
    readonly port: FieldState;
    readonly proxyTimeoutMs: FieldState;
    readonly rateLimitPerMinute: FieldState;
}
/** Props the renderer composes for this card. */
export interface RelayCardProps {
    /** Which part of the card the platform is asking for. */
    view?: 'summary' | 'page';
    /** Bound from the injected `hooks` compartment. */
    useRelayCard: <T>(select: (state: RelayCardState) => T) => T;
    /** Stage draft text for one section field. */
    edit: (field: string, text: string) => void;
    /** Stage a clear, so saving lets the field re-inherit the composition layer. */
    resetField: (field: string) => void;
    /** Write every staged edit. */
    save: () => void;
    /** Drop every staged edit. */
    discard: () => void;
}
/**
 * Render the relay's configuration card.
 * @param props - the bound snapshot hook and the form actions.
 * @returns the one-liner or the form; the platform supplies the frame.
 */
export declare function RelayCard(props: RelayCardProps): "Authenticated remote access: TLS, device pairing, and per-device revocation." | import("react").JSX.Element;
//# sourceMappingURL=RelayCard.d.ts.map