/**
 * The relay's browser half: one card on the harness's Plugins page.
 *
 * Deliberately small. The card is the only thing this bundle contributes, and
 * everything operational — pairing, the device list, the certificate pin, the
 * password — stays on the relay's own pages, which work before a person is
 * signed in and from a device other than this one. A card cannot do either.
 *
 * **What changed for dsh 0.1.7.** Three things, and each one fails silently:
 *
 * - The client service is `configForms`, not `settingsScope`. The old name
 *   appears in no 0.1.7 client bundle, and a service that never arrives leaves
 *   this bundle unloaded with no error anywhere.
 * - The card registers into the Plugins page's `plugins.item` slot. The 0.1.5
 *   seat, `settings.plugin.item`, is not in the 0.1.7 slot map.
 * - The key is the **Host entry id** (`relay`) — the same string the node
 *   half's row declares and the settings plane serves as the namespace. It is
 *   the join between the two halves, so all three names are one value.
 *
 * Types here are declared structurally rather than imported from the harness's
 * client packages. This plugin is installed beside a harness it does not
 * control the version of, and the alternative is four `@deepseek-ai/dsh-*`
 * type dependencies that pin it to one release for no behaviour of their own —
 * the same trade the node half makes by reaching everything through `ctx`.
 *
 * The one exception is `SettingsFormModel`. It is a **value** the shell shares
 * into its frozen module table, and re-implementing its staging, revision
 * fencing, and read-back would be several hundred lines of exactly the logic
 * the harness already ships for every settings card. It stays external in the
 * bundle (see the module table in `tsdown.config.ts`) so the harness's copy is
 * the only one.
 * @module dsh-relay/client
 */
/** A reactive settings scope, as `ctx.configForms.get` returns one. */
interface SettingsScopeLike {
    getSnapshot: () => unknown;
    subscribe: (listener: () => void) => () => void;
    mutate: (ops: readonly unknown[], expectedRevision?: number) => Promise<boolean>;
}
/** The slice of the client context this plugin uses. */
interface RelayClientContext {
    configForms: {
        get: (entryId: string) => SettingsScopeLike;
        whileServed: (namespaces: readonly string[], register: (served: ReadonlySet<string>) => () => void) => () => void;
    };
    slots: {
        inject: (name: string, register: () => void) => void;
        register: (spec: {
            name: string;
            id?: string;
            order?: number;
            label?: () => string;
            inject?: () => object;
        }, component: unknown) => () => void;
    };
    effect: (callback: () => unknown, label?: string) => void;
    logger?: {
        warn?: (message: string) => void;
    };
}
/** Services the renderer must have before this bundle registers anything. */
export declare const inject: string[];
/**
 * Stage the card's edits over the relay namespace and register the page.
 * @param ctx - the browser plugin context.
 */
export declare function apply(ctx: RelayClientContext): void;
export {};
//# sourceMappingURL=index.d.ts.map