# Changelog

All notable changes to this project are documented here. The format loosely
follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/), and this
project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

## [0.4.2] — 2026-11-04

### Fixed

- **Widened the `@deepseek-ai/dsh-llm` peer range to cover dsh 0.2.2.** The previous
  `^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.2-0` stops one patch-line short, and dsh 0.2.2 turns
  that into a **hard load failure** rather than a warning: the profile reports
  `skipping profile bundle "dsh-llm-session-header"` and refuses to mount the plugin at
  all.

  ```
  dsh: skipping profile bundle "dsh-llm-session-header": Error: Plugin
  dsh-llm-session-header@0.4.1 is incompatible with dsh 0.2.2-rc.1:
  requirements {"@deepseek-ai/dsh-llm":"^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.2-0"}.
  ```

  The new range is `^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.3-0` — the 0.1.7 line plus the whole
  0.2.x line (including 0.2.2), still excluding 0.3+.

  No code changed, because nothing needed to: verified on a real 0.2.2-rc.1 instance that
  the plugin activates, the card renders its full form, a route picked from the dropdown
  saves to the profile patch, and the injected header reaches the wire. All invariants a
  third-party plugin keys on are unchanged between 0.2.1 and 0.2.2 (session format version,
  token estimation constants, compact-spec arity, pruner allowed keys, error-string counts).

## [0.4.1] — 2026-10-20

### Fixed

- **Widened the `@deepseek-ai/dsh-llm` peer range to cover dsh 0.2.1.** The previous
  `^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.1-0` stops one patch-line short, and dsh 0.2.1 turns
  that into a **hard load failure** rather than a warning: the profile reports
  `skipping profile bundle "dsh-llm-session-header"` and refuses to mount the plugin at
  all.

  ```
  dsh: skipping profile bundle "dsh-llm-session-header": Error: Plugin
  dsh-llm-session-header@0.4.0 is incompatible with dsh 0.2.1-rc.2:
  requirements {"@deepseek-ai/dsh-llm":"^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.1-0"}.
  ```

  The new range is `^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.2-0` — the 0.1.7 line plus the whole
  0.2.x line, still excluding 0.2.2+ and 0.3+.

  No code changed, because nothing needed to: verified on a real 0.2.1-rc.2 instance that
  the plugin activates, the card renders its full form, a route picked from the dropdown
  saves to the profile patch, and the injected header reaches the wire.

  One upstream change worth recording, since it looks alarming in a dependency diff:
  `@deepseek-ai/dsh-client-ui-primitives` is **no longer installed as its own package** in
  0.2.1 (it was in 0.2.0, pulled in transitively). It is still available to client bundles,
  because the Web frontend inlines it and seeds the module table. A card that
  `require`s it by name keeps working; only tooling that looked for the package on disk
  would notice.

## [0.4.0] — 2026-10-01

### Added

- **Per-row DSH Settings Page Metadata (i18n)**: Added `locale/en.json` and `locale/zh.json` providing localized titles (`LLM session header` / `LLM 会话路由请求头`) and descriptions for DSH's Plugins page (`readPluginMeta`).
- **Locale Exports**: Exported `./locale/*.json` in `package.json` `exports` and added `locale` to `files`.
- **Schemastery Schema Metadata**: Enriched `Config` with `.default(...)` and `.description(...)` across all fields (`headerName`, `providers`, `mode`, `debug`, `debugFile`).
- **Bounded UUID Cache**: Introduced `BoundedMap` for `uuidBySession` in `mode: 'uuid'` to prevent unbounded memory accumulation in long-running instances.
- **Client Bundle Modularization**: Split monolithic `lib/client.js` into modular source files in `src/client/` (`constants.js`, `locales.js`, `store.js`, `controller.js`, `card.js`, `lifecycle.js`), managed via `scripts/build-client.js` (`npm run build:client`).
- **Selectable Provider Routes Dropdown**: In the settings card (`Routes → header names`), routes are now selectable from a dropdown populated dynamically from currently available provider routes (discovering routes from `llm-pi-ai`, `agent-default-model`, and `llm-*` namespaces). Includes fallback to custom text input (`+ 自定义路由…` / `+ Custom route…`) with seamless toggle back to list (`从列表选择` / `Select from list`).
- **Async Disposable Stream Support**: Added `[Symbol.asyncDispose]` support to `withStore()`.
- **A test for the BUILT bundle** (`tests/client-bundle.test.mjs`). The controller
  tests import `src/client/controller.js` directly, so nothing checked the
  concatenated `lib/client.js` the browser actually loads. It now goes through a stub
  `window.__ModuleLoader__.load`, runs `apply`, and renders the registered card with
  stub React — catching a concatenation that parses but fails at runtime.

### Changed

- **ALS Context Preservation on Stream Teardown**: `withStore` now wraps `iterator.return(value)` within `als.run(store, ...)` to ensure context remains active during downstream cleanup.
- **Fast-path Header Inspection**: `hasHeader` now uses fast-paths for native `Headers` instances and plain objects to avoid redundant `new Headers()` allocations on the hot request path.
- **CI and the publish workflow now rebuild and diff `lib/client.js`.** The build
  artifact is committed and the browser only loads that file, so editing
  `src/client/` without rebuilding shipped a stale card while every existing check
  stayed green. Drift now fails the build instead of reaching npm.
- **The CI tarball check also asserts `locale/en.json`**, so a `files` gap in the
  display metadata fails there rather than silently falling back to the package name.

## [0.3.1] — 2026-09-29

### Changed

- **First release published through CI, with provenance.** 0.3.0 was uploaded with a
  long-lived token, so it carries no sigstore attestation; 0.3.1 and later are published by
  the `Publish to npm` GitHub Actions workflow over npm Trusted Publishing (OIDC) and are
  signed. No runtime change from 0.3.0 — the tree is identical, so this is a patch purely to
  hand the release process over to CI.

## [0.3.0] — 2026-09-29

### Added

- **Declared the supported harness generations** as a peer dependency on
  `@deepseek-ai/dsh-llm` — the package that provides the `llm` service this plugin
  `inject`s, and the one whose version tracks the harness release exactly:

  ```json
  "@deepseek-ai/dsh-llm": "^0.1.7-rc.2 || >=0.2.0-rc.1 <0.2.1-0"
  ```

  That is `>=0.1.7-rc.2 <0.2.0-0 || >=0.2.0-rc.1 <0.2.1-0`: the 0.1.7 line and the whole
  0.2.0 line (rc.1, rc.2 and the final), and **not** 0.2.1+ or 0.3+. Both ends are
  versions this plugin was actually verified against. Marked `optional`, so mounting
  it never depends on npm resolving the harness family — dsh provides these itself.

### Fixed

- **The settings card moved off `plugins.item` onto `plugins.row.config`**, keyed
  `dsh-llm-session-header#llm-session-header`. The page's slot contract marks
  `plugins.item` as *"OCCUPIED by the official settings pages, one companion
  package per host-plane namespace; a bundle's configuration belongs in
  `plugins.bundle.config` or `plugins.row.config` instead"*. As a third-party
  bundle we were squatting the official list — the card showed up under
  **Official**, which mislabelled it. It now appears where it belongs: the
  `llm-session-header` component on our own bundle's page gains a **Configure**
  button. (`plugins.row.config` rather than the `plugins.bundle.config` that was
  suggested: the latter is keyed by package name for a *bundle-level* config and
  is rendered with `view: 'page'` and **no `form`**, whereas our settings
  namespace is the row id, so the row is the true owner.)
  Verified rendering and a save-to-disk round trip on both dsh **0.1.7-rc.2** and
  **0.2.0-rc.2**, whose slot contracts are byte-identical.
- Dropped the now-dead `title` dictionary key: a keyed slot takes its heading
  from the bundle patch, not from a slot `label`.

### Verified

- **dsh `0.2.0-rc.2` compatibility — no changes required.** Audited every surface this plugin
  depends on. Byte-identical between 0.1.7-rc.2 and 0.2.0-rc.2: `dsh-llm` (the `llm/stream`
  waterfall contract), `dsh-settings`, `dsh-api-settings-controller`, `dsh-client-ui-settings`,
  `dsh-client-locale`. Only `dsh-client-ui-primitives` and `dsh-client-ui-plugin-manager`
  moved, and the card renders correctly on the new ones.
- Confirmed in an isolated 0.2.0 instance: the card renders every control, a save **persists to
  the profile patch**, and a route added through the card *after* activation injects its header
  on the next model call — verified on the wire at a header-recording mock.
- Added `tests/compat-0.2.mjs`: validates the schema against a 0.2.0 install's schemastery,
  asserts every field is a live volatile handle, asserts the write seam accepts a real boolean
  and rejects a string, and proves an in-place save reaches the next resolve. Run it against a
  specific install with `DSH_020=<prefix> npm run test:0.2`.

## [0.2.0] — 2026-09-28

Verified against **dsh 0.1.7-rc.2** (session format 4).

### Added

- **A settings card on the Plugins page** (`Plugins → Session Header
  Injection`), which makes the whole route table editable without YAML:
  the default header name, the value mode, the debug flag, and the route
  rows themselves (add, edit, remove). The card is the browser half
  (`lib/client.js`), registered into the `plugins.item` slot behind
  `configForms.whileServed(["llm-session-header"])`.
- **Live config updates without a restart.** Every schema field is declared
  `.volatile()`, so the Host rewrites the existing config reference in place
  rather than remounting the plugin fiber; the route table is re-resolved on
  every `llm/stream` call. A route added in the UI starts receiving its header
  on the very next model call.
- `tests/config-update.test.mjs` covering the volatile read path.
- `test/compat/mock-llm.py`, a dependency-free mock model server used to prove
  end-to-end injection over real HTTP.

### Changed

- **Packaging aligned with the dsh client-bundle contract**: the client half
  now lives at `lib/client.js` and is exported as `exports["./client"]`, which
  is how the Host discovers and serves it. Previously it sat at `client/ui.js`
  with no export entry and could never have been served.
- `@deepseek-ai/schemastery` is now a declared (optional) peer dependency and a
  dev dependency, mirroring the working reference plugins. The Host identifies
  a plugin's schema by its `~standard.vendor` string, not by object identity,
  so a plugin-local copy is safe.
- The host half imports schemastery statically instead of through a guarded
  dynamic import that silently degraded to "no settings card".
- `engines.node` is now `^22.19 || >=24`, matching the dsh runtime.

### Fixed

- The host half no longer reads a non-existent `ctx.onConfigUpdate`, which threw
  `cannot get property "onConfigUpdate" without inject` during activation and
  prevented the plugin from loading at all.
- A route row left with a blank header is written as the configured default
  header instead of an empty string, so saving the list form no longer pins
  routes to `""`.
- `providers` schema is wrapped in a single volatile field: schemastery rejects
  a volatile field nested inside another (`volatile fields require a fixed
  object path without an enclosing volatile field`).

## [0.1.0] — 2026-09-27

### Added

- Initial release: a host plugin that attaches a stable per-conversation session
  header to model requests routed to configured providers, generalised from
  `dsh-opencode-session` to a configurable header name so one plugin serves
  OpenCode (`x-opencode-session`), SMG (`X-SMG-Routing-Key`) and any other
  header-based affinity router.
- `providers` accepts a list (one header for all routes) or a map (a header per
  route).
- `mode`: `session-id` reuses the DSH session id; `uuid` derives a
  process-stable random uuid per session.
- `debug` / `debugFile` diagnostics.

[0.4.2]: https://github.com/snailium/dsh-llm-session-header/compare/v0.4.1...v0.4.2
[0.4.1]: https://github.com/snailium/dsh-llm-session-header/compare/v0.4.0...v0.4.1
[0.4.0]: https://github.com/snailium/dsh-llm-session-header/releases/tag/v0.4.0
[0.3.1]: https://github.com/snailium/dsh-llm-session-header/releases/tag/v0.3.1
[0.3.0]: https://github.com/snailium/dsh-llm-session-header/releases/tag/v0.3.0
[0.2.0]: https://github.com/snailium/dsh-llm-session-header/releases/tag/v0.2.0
[0.1.0]: https://github.com/snailium/dsh-llm-session-header/releases/tag/v0.1.0
